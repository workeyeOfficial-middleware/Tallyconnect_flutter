// Alerts state: read/unread tracking, All/Unread filter, mark-all-read, and
// the default filter selection (jsx:2.4 / 8.13).
library;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/models/notification_model.dart';
import 'app_providers.dart';

enum NotifFilter { all, unread }

class NotificationState {
  const NotificationState({
    this.items = const <TCNotification>[],
    this.filter = NotifFilter.all,
  });

  final List<TCNotification> items;
  final NotifFilter filter;

  int get unreadCount => items.where((TCNotification n) => n.unread).length;

  bool get hasUnread => unreadCount > 0;

  /// Sub-header text under the H1 (jsx:2.4).
  String get unreadTxt {
    final int n = unreadCount;
    if (n == 0) return 'You have read everything.';
    return n == 1 ? '1 unread alert' : '$n unread alerts';
  }

  List<TCNotification> get visible => filter == NotifFilter.unread
      ? items.where((TCNotification n) => n.unread).toList(growable: false)
      : items;

  NotificationState copyWith({
    List<TCNotification>? items,
    NotifFilter? filter,
  }) => NotificationState(
    items: items ?? this.items,
    filter: filter ?? this.filter,
  );
}

class NotificationNotifier extends Notifier<NotificationState> {
  @override
  NotificationState build() => NotificationState(
    items: ref.watch(repositoryProvider).notifications(),
  );

  void setFilter(NotifFilter f) => state = state.copyWith(filter: f);

  /// Tapping a row marks it read, then returns the nav target for the caller.
  TCNavTarget? markRead(String id) {
    TCNotification? hit;
    final List<TCNotification> next = <TCNotification>[
      for (final TCNotification n in state.items)
        if (n.id == id)
          () {
            hit = n;
            return n.copyWith(unread: false);
          }()
        else
          n,
    ];
    state = state.copyWith(items: next);
    return hit?.target;
  }

  void markAllRead() => state = state.copyWith(
    items: <TCNotification>[
      for (final TCNotification n in state.items)
        if (n.unread) n.copyWith(unread: false) else n,
    ],
  );

  void refresh() => state = state.copyWith(
    items: ref.read(repositoryProvider).notifications(),
  );
}

final NotifierProvider<NotificationNotifier, NotificationState>
notificationProvider =
    NotifierProvider<NotificationNotifier, NotificationState>(
      NotificationNotifier.new,
    );

final Provider<int> unreadCountProvider = Provider<int>(
  (Ref ref) => ref.watch(notificationProvider).unreadCount,
);

final Provider<bool> hasUnreadProvider = Provider<bool>(
  (Ref ref) => ref.watch(notificationProvider).hasUnread,
);