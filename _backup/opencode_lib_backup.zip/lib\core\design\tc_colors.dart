// TallyConnect Liquid Glass - colour tokens
// Ported verbatim from prototype/app_styles.css (.ps-* looks, .ac-* accents,
// --c-* semantic palette, --pos/--neg/--warn overrides) and
// prototype/TallyConnect_App_Source.jsx (LOOKS, ACCENTS, LOOKACC, LOOKSIG,
// COMBOS, WALLS).
import 'package:flutter/material.dart';

/// A named look preset. `wall` holds the CSS radial/linear gradient stack that
/// the wallpaper painter reproduces.
class TCLook {
  const TCLook({
    required this.k,
    required this.t,
    required this.s,
    required this.acc,
    required this.acc2,
    required this.acc3,
    required this.navy,
    required this.navy2,
    required this.navy3,
    required this.ink,
    required this.ink2,
    required this.ink3,
    required this.gt,
    required this.wall,
    required this.o1,
    required this.o2,
    required this.o3,
    this.pos,
    this.neg,
    this.warn,
  });

  final String k;
  final String t;
  final String s;
  final Color acc;
  final Color acc2;
  final Color acc3;
  final Color navy;
  final Color navy2;
  final Color navy3;
  final Color ink;
  final Color ink2;
  final Color ink3;

  /// CSS `--gt` = glass tint as "r,g,b"
  final String gt;
  final TCWallSpec wall;
  final Color o1;
  final Color o2;
  final Color o3;

  /// Per-look semantic overrides; null means "inherit base".
  final Color? pos;
  final Color? neg;
  final Color? warn;
}

/// A named accent override (`.ac-*`).
class TCAccent {
  const TCAccent({
    required this.k,
    required this.t,
    required this.a,
    required this.b,
    required this.n,
  });

  final String k;
  final String t;
  final Color a;
  final Color b;
  final Color n;
}

/// One CSS gradient layer.
class TCWallLayer {
  const TCWallLayer({
    required this.color,
    required this.cx,
    required this.cy,
    required this.rx,
    required this.ry,
    required this.stops,
  });

  final Color color;

  /// centre as a fraction of the box (0..1)
  final double cx;
  final double cy;

  /// radii as a fraction of the box (0..1)
  final double rx;
  final double ry;

  /// [0.0, ..., 1.0] -> [opaque, transparent]
  final List<double> stops;
}

/// `repeating-linear-gradient(118deg, ...)` silk band.
class TCWallStreak {
  const TCWallStreak({
    required this.angleDeg,
    required this.stops,
    required this.size,
  });

  final double angleDeg;
  final List<TCStreakStop> stops;
  final double size;
}

class TCStreakStop {
  const TCStreakStop(this.color, this.start, this.end);
  final Color color;
  final double start;
  final double end;
}

/// `linear-gradient(<angle>, c1 0%, c2 100%)` base wash.
class TCWallLinear {
  const TCWallLinear({
    required this.color1,
    required this.color2,
    this.angleDeg = 180,
  });
  final Color color1;
  final Color color2;
  final double angleDeg;
}

/// `conic-gradient(from 200deg at 65% 35%, ...)`
class TCWallConic {
  const TCWallConic({
    required this.colors,
    required this.fromDeg,
    required this.cx,
    required this.cy,
  });
  final List<Color> colors;
  final double fromDeg;
  final double cx;
  final double cy;
}

/// A complete wallpaper recipe - the CSS `--wall` value.
class TCWallSpec {
  const TCWallSpec({
    this.radials = const [],
    this.streaks = const [],
    this.linear,
    this.conic,
  });

  final List<TCWallLayer> radials;
  final List<TCWallStreak> streaks;
  final TCWallLinear? linear;
  final TCWallConic? conic;
}

class TCColors {
  TCColors._();

  // ---------------------------------------------------------------- accents
  // ACCENTS array (jsx:266-267) == the .ac-* rules (css:389-400,424-429)
  static const List<TCAccent> accents = <TCAccent>[
    TCAccent(
      k: 'maroon',
      t: 'Maroon',
      a: Color(0xFF8C1D3F),
      b: Color(0xFF6E1531),
      n: Color(0xFF4A1428),
    ),
    TCAccent(
      k: 'berry',
      t: 'Berry',
      a: Color(0xFFA0306A),
      b: Color(0xFF7C2352),
      n: Color(0xFF4E1838),
    ),
    TCAccent(
      k: 'violet',
      t: 'Violet',
      a: Color(0xFF6D3FC4),
      b: Color(0xFF5530A0),
      n: Color(0xFF2E1F5E),
    ),
    TCAccent(
      k: 'indigo',
      t: 'Indigo',
      a: Color(0xFF4338CA),
      b: Color(0xFF312A9E),
      n: Color(0xFF1E1B4B),
    ),
    TCAccent(
      k: 'blue',
      t: 'Royal Blue',
      a: Color(0xFF1D4ED8),
      b: Color(0xFF1A3FAE),
      n: Color(0xFF172554),
    ),
    TCAccent(
      k: 'ocean',
      t: 'Ocean',
      a: Color(0xFF0B6A8F),
      b: Color(0xFF07506D),
      n: Color(0xFF133A63),
    ),
    TCAccent(
      k: 'teal',
      t: 'Teal',
      a: Color(0xFF0F766E),
      b: Color(0xFF0B5953),
      n: Color(0xFF133F3C),
    ),
    TCAccent(
      k: 'emerald',
      t: 'Emerald',
      a: Color(0xFF0E7159),
      b: Color(0xFF0A5443),
      n: Color(0xFF16423C),
    ),
    TCAccent(
      k: 'bronze',
      t: 'Bronze',
      a: Color(0xFF9A5B04),
      b: Color(0xFF7A4703),
      n: Color(0xFF3D2A12),
    ),
    TCAccent(
      k: 'terracotta',
      t: 'Terracotta',
      a: Color(0xFFA2462A),
      b: Color(0xFF7E331C),
      n: Color(0xFF4A2418),
    ),
    TCAccent(
      k: 'graphite',
      t: 'Graphite',
      a: Color(0xFF3E4C63),
      b: Color(0xFF2B3647),
      n: Color(0xFF1E2635),
    ),
    TCAccent(
      k: 'slate',
      t: 'Slate',
      a: Color(0xFF334E68),
      b: Color(0xFF243B53),
      n: Color(0xFF102A43),
    ),
    TCAccent(
      k: 'plum',
      t: 'Plum',
      a: Color(0xFF7A2E7A),
      b: Color(0xFF5E215E),
      n: Color(0xFF3A1638),
    ),
    TCAccent(
      k: 'clayrose',
      t: 'Clay Rose',
      a: Color(0xFFA0405A),
      b: Color(0xFF7E2E44),
      n: Color(0xFF4A1E2A),
    ),
    TCAccent(
      k: 'cocoa',
      t: 'Cocoa',
      a: Color(0xFF6B4A3A),
      b: Color(0xFF52372A),
      n: Color(0xFF2F2019),
    ),
    TCAccent(
      k: 'olive',
      t: 'Olive',
      a: Color(0xFF5F6B2E),
      b: Color(0xFF4A5423),
      n: Color(0xFF2A3014),
    ),
    TCAccent(
      k: 'forest',
      t: 'Forest',
      a: Color(0xFF2F6B3A),
      b: Color(0xFF22522B),
      n: Color(0xFF173320),
    ),
  ];

  static TCAccent accentDef(String k) =>
      accents.firstWhere((TCAccent a) => a.k == k, orElse: () => accents.first);

  // ------------------------------------------------------------------ looks
  static const List<TCLook> looks = <TCLook>[
    TCLook(
      k: 'aurora',
      t: 'Aurora',
      s: 'Maroon & navy · misty blue',
      acc: Color(0xFF8C1D3F),
      acc2: Color(0xFFA42A52),
      acc3: Color(0xFF6E1531),
      navy: Color(0xFF1B2D5B),
      navy2: Color(0xFF2A4584),
      navy3: Color(0xFF172A55),
      ink: Color(0xFF0E1B33),
      ink2: Color(0xFF3F4B68),
      ink3: Color(0xFF58647F),
      gt: '255,255,255',
      o1: Color(0xFFBCD3F8),
      o2: Color(0xFFDCCCF5),
      o3: Color(0xFFF0D3DF),
      wall: TCWallSpec(
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xFFC9DCFA),
            cx: .12,
            cy: .06,
            rx: .60,
            ry: .38,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFE2D8F7),
            cx: .95,
            cy: .22,
            rx: .55,
            ry: .34,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFD3E4F8),
            cx: .80,
            cy: .96,
            rx: .70,
            ry: .40,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFF1DFE8),
            cx: .04,
            cy: .70,
            rx: .45,
            ry: .30,
            stops: <double>[0, .70],
          ),
        ],
        linear: TCWallLinear(
          color1: Color(0xFFEEF2FB),
          color2: Color(0xFFE7EBF6),
        ),
      ),
    ),
    TCLook(
      k: 'ocean',
      t: 'Ocean Breeze',
      s: 'Calm blues',
      acc: Color(0xFF0B6A8F),
      acc2: Color(0xFF1486B0),
      acc3: Color(0xFF07506D),
      navy: Color(0xFF133A63),
      navy2: Color(0xFF1F5690),
      navy3: Color(0xFF0E2B4B),
      ink: Color(0xFF0B2340),
      ink2: Color(0xFF34506B),
      ink3: Color(0xFF4D677F),
      gt: '244,250,255',
      o1: Color(0xFFA9D6EF),
      o2: Color(0xFFBFD0F6),
      o3: Color(0xFFBFE8E1),
      pos: Color(0xFF0F7B62),
      neg: Color(0xFFB4364A),
      warn: Color(0xFFA5530E),
      wall: TCWallSpec(
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xFFBDE3F3),
            cx: .10,
            cy: .05,
            rx: .60,
            ry: .40,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFC7D6F8),
            cx: .95,
            cy: .25,
            rx: .55,
            ry: .35,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFCDEFEA),
            cx: .70,
            cy: .98,
            rx: .70,
            ry: .45,
            stops: <double>[0, .70],
          ),
        ],
        linear: TCWallLinear(
          color1: Color(0xFFEDF6FA),
          color2: Color(0xFFE3EEF6),
        ),
      ),
    ),
    TCLook(
      k: 'royal',
      t: 'Royal Silk',
      s: 'Violet on silk waves',
      acc: Color(0xFF5A3DBF),
      acc2: Color(0xFF7457D9),
      acc3: Color(0xFF43299A),
      navy: Color(0xFF26235F),
      navy2: Color(0xFF3A3790),
      navy3: Color(0xFF1B1946),
      ink: Color(0xFF1C1640),
      ink2: Color(0xFF453F6B),
      ink3: Color(0xFF5D5782),
      gt: '250,247,255',
      o1: Color(0xFFCAD8F8),
      o2: Color(0xFFE2D2F3),
      o3: Color(0xFFF1D2E0),
      wall: TCWallSpec(
        streaks: <TCWallStreak>[
          TCWallStreak(
            angleDeg: 118,
            size: 72,
            stops: <TCStreakStop>[
              TCStreakStop(Color(0x00FFFFFF), 0, 30),
              TCStreakStop(Color(0x66FFFFFF), 36, 36),
              TCStreakStop(Color(0x00FFFFFF), 42, 42),
              TCStreakStop(Color(0x00FFFFFF), 72, 72),
            ],
          ),
        ],
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xFFD3E1FB),
            cx: .00,
            cy: .00,
            rx: .90,
            ry: .60,
            stops: <double>[0, .65],
          ),
          TCWallLayer(
            color: Color(0xFFF2D8E6),
            cx: 1,
            cy: 1,
            rx: .80,
            ry: .60,
            stops: <double>[0, .65],
          ),
        ],
        linear: TCWallLinear(
          color1: Color(0xFFE6EBFA),
          color2: Color(0xFFF6E8EE),
          angleDeg: 160,
        ),
      ),
    ),
    TCLook(
      k: 'sunrise',
      t: 'Sunrise Clay',
      s: 'Warm terracotta',
      acc: Color(0xFFA2462A),
      acc2: Color(0xFFBF5E3E),
      acc3: Color(0xFF7E331C),
      navy: Color(0xFF3A2C4A),
      navy2: Color(0xFF574370),
      navy3: Color(0xFF2A1F36),
      ink: Color(0xFF2A1A14),
      ink2: Color(0xFF5A443A),
      ink3: Color(0xFF6E574D),
      gt: '255,250,246',
      o1: Color(0xFFF7C6AE),
      o2: Color(0xFFF2C0CF),
      o3: Color(0xFFF7DDB0),
      pos: Color(0xFF3E7B3A),
      neg: Color(0xFFA93A22),
      warn: Color(0xFF9A5B04),
      wall: TCWallSpec(
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xFFFBD6C3),
            cx: .10,
            cy: .06,
            rx: .60,
            ry: .40,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFF6CFDA),
            cx: .95,
            cy: .28,
            rx: .55,
            ry: .35,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFFBE6C2),
            cx: .65,
            cy: .98,
            rx: .70,
            ry: .45,
            stops: <double>[0, .70],
          ),
        ],
        linear: TCWallLinear(
          color1: Color(0xFFFCF4EE),
          color2: Color(0xFFF6EBE7),
        ),
      ),
    ),
    TCLook(
      k: 'mint',
      t: 'Mint Ledger',
      s: 'Fresh greens',
      acc: Color(0xFF0E7159),
      acc2: Color(0xFF169174),
      acc3: Color(0xFF0A5443),
      navy: Color(0xFF16423C),
      navy2: Color(0xFF22625A),
      navy3: Color(0xFF0F302B),
      ink: Color(0xFF0F2A24),
      ink2: Color(0xFF36514A),
      ink3: Color(0xFF4B665E),
      gt: '246,253,250',
      o1: Color(0xFFB5E0CB),
      o2: Color(0xFFBCD9EC),
      o3: Color(0xFFD7EBB9),
      pos: Color(0xFF0E7159),
      neg: Color(0xFFB0364A),
      warn: Color(0xFF9A5B04),
      wall: TCWallSpec(
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xFFC9EADB),
            cx: .10,
            cy: .06,
            rx: .60,
            ry: .40,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFCFE5F2),
            cx: .95,
            cy: .26,
            rx: .55,
            ry: .35,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFE2F0CE),
            cx: .65,
            cy: .98,
            rx: .70,
            ry: .45,
            stops: <double>[0, .70],
          ),
        ],
        linear: TCWallLinear(
          color1: Color(0xFFEFF8F3),
          color2: Color(0xFFE6F1EC),
        ),
      ),
    ),
    TCLook(
      k: 'pearl',
      t: 'Pearl Graphite',
      s: 'Quiet neutrals',
      acc: Color(0xFF3E4C63),
      acc2: Color(0xFF56657F),
      acc3: Color(0xFF2B3647),
      navy: Color(0xFF1E2635),
      navy2: Color(0xFF33405A),
      navy3: Color(0xFF141A25),
      ink: Color(0xFF141A25),
      ink2: Color(0xFF3F4758),
      ink3: Color(0xFF565E6E),
      gt: '255,255,255',
      o1: Color(0xFFDADFEA),
      o2: Color(0xFFEAE3D8),
      o3: Color(0xFFD8E0EC),
      wall: TCWallSpec(
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xFFE4E7F0),
            cx: .12,
            cy: .06,
            rx: .60,
            ry: .40,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFF1ECE4),
            cx: .92,
            cy: .28,
            rx: .55,
            ry: .35,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFE0E7F2),
            cx: .60,
            cy: .98,
            rx: .70,
            ry: .45,
            stops: <double>[0, .70],
          ),
        ],
        linear: TCWallLinear(
          color1: Color(0xFFF7F7F9),
          color2: Color(0xFFEDEEF2),
        ),
      ),
    ),
    TCLook(
      k: 'prism',
      t: 'Prism Indigo',
      s: 'Soft rainbow glass',
      acc: Color(0xFF4338CA),
      acc2: Color(0xFF5B51E0),
      acc3: Color(0xFF312A9E),
      navy: Color(0xFF1E1B4B),
      navy2: Color(0xFF2E2A75),
      navy3: Color(0xFF151238),
      ink: Color(0xFF15133A),
      ink2: Color(0xFF413E66),
      ink3: Color(0xFF58557C),
      gt: '255,255,255',
      o1: Color(0xFFCFE0FA),
      o2: Color(0xFFEBD3F1),
      o3: Color(0xFFF7E0CB),
      wall: TCWallSpec(
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xB3FFFFFF),
            cx: .50,
            cy: .45,
            rx: .70,
            ry: .55,
            stops: <double>[0, .70],
          ),
        ],
        conic: TCWallConic(
          colors: <Color>[
            Color(0xFFD6E4FB),
            Color(0xFFE6D8F6),
            Color(0xFFF5DCE5),
            Color(0xFFFAE9D6),
            Color(0xFFD9EFE6),
            Color(0xFFD6E4FB),
          ],
          fromDeg: 200,
          cx: .65,
          cy: .35,
        ),
      ),
    ),
    TCLook(
      k: 'rose',
      t: 'Rose Quartz',
      s: 'Rose on lavender',
      acc: Color(0xFFA0306A),
      acc2: Color(0xFFB8487F),
      acc3: Color(0xFF7C2352),
      navy: Color(0xFF3B2350),
      navy2: Color(0xFF57346F),
      navy3: Color(0xFF2A1839),
      ink: Color(0xFF24152E),
      ink2: Color(0xFF4E3F5A),
      ink3: Color(0xFF63556F),
      gt: '252,248,255',
      o1: Color(0xFFCDBBF2),
      o2: Color(0xFFEEC5DC),
      o3: Color(0xFFC0CBF3),
      pos: Color(0xFF1F7A5C),
      neg: Color(0xFFA8324A),
      warn: Color(0xFFA5470E),
      wall: TCWallSpec(
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xFFDACDF6),
            cx: .12,
            cy: .06,
            rx: .60,
            ry: .40,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFF2D3E6),
            cx: .92,
            cy: .30,
            rx: .55,
            ry: .35,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFCBD4F6),
            cx: .60,
            cy: .98,
            rx: .70,
            ry: .45,
            stops: <double>[0, .70],
          ),
        ],
        linear: TCWallLinear(
          color1: Color(0xFFF3F0FB),
          color2: Color(0xFFEAE5F6),
        ),
      ),
    ),
  ];

  static TCLook look(String k) =>
      looks.firstWhere((TCLook l) => l.k == k, orElse: () => looks.first);

  // ------------------------------------------------- accent-allowed-per-look
  // LOOKACC (jsx:268)
  static const Map<String, List<String>> lookAcc = <String, List<String>>{
    'aurora': <String>['berry', 'indigo', 'blue', 'graphite'],
    'ocean': <String>['blue', 'teal', 'slate', 'indigo'],
    'royal': <String>['indigo', 'berry', 'plum', 'graphite'],
    'sunrise': <String>['bronze', 'clayrose', 'cocoa', 'olive'],
    'mint': <String>['teal', 'forest', 'ocean', 'graphite'],
    'pearl': <String>['slate', 'blue', 'maroon', 'emerald'],
    'prism': <String>['violet', 'blue', 'berry', 'teal'],
    'rose': <String>['plum', 'maroon', 'violet', 'clayrose'],
  };

  /// LOOKSIG (jsx:269) - [title, hexA, hexB] for the "match look" swatch.
  static const Map<String, List<String>> lookSig = <String, List<String>>{
    'aurora': <String>['Maroon', '#8C1D3F', '#6E1531'],
    'ocean': <String>['Ocean', '#0B6A8F', '#07506D'],
    'royal': <String>['Royal Violet', '#5A3DBF', '#43299A'],
    'sunrise': <String>['Terracotta', '#A2462A', '#7E331C'],
    'mint': <String>['Emerald', '#0E7159', '#0A5443'],
    'pearl': <String>['Graphite', '#3E4C63', '#2B3647'],
    'prism': <String>['Indigo', '#4338CA', '#312A9E'],
    'rose': <String>['Rose', '#A0306A', '#7C2352'],
  };

  /// okAccent() (jsx:302). `a == 'look'` always true.
  static bool okAccent(String lookKey, String accentKey) =>
      accentKey == 'look' ||
      (lookAcc[lookKey] ?? const <String>[]).contains(accentKey);

  // ------------------------------------------------- semantic feature palette
  // css:387 `.root{--c-sales:...}`
  static const Color cSales = Color(0xFF0E7C86);
  static const Color cPurchase = Color(0xFF4F46E5);
  static Color get cReceipt => fallbackAccent; // overridden by TCTheme
  static const Color cPayment = Color(0xFFC2410C);
  static const Color cJournal = Color(0xFF8A5A12);
  static const Color cContra = Color(0xFF3B6FB6);
  static const Color cItems = Color(0xFFB45309);
  static const Color cParty = Color(0xFF2563EB);
  static const Color cVouchers = Color(0xFF1E3A8A);
  static const Color cOutstanding = Color(0xFF047857);
  static const Color cReports = Color(0xFF7C3AED);
  static const Color cSettings = Color(0xFF475569);
  static const Color cTeam = Color(0xFF9D174D);
  static const Color cActivity = Color(0xFF0369A1);

  /// The `--acc` fallback used before a theme is resolved.
  static const Color fallbackAccent = Color(0xFF8C1D3F);

  // -------------------------------------------------------- base semantics
  // css:430 `.root{--pos:...}`
  static const Color basePos = Color(0xFF0F7B55);
  static const Color baseNeg = Color(0xFFB4233F);
  static const Color baseWarn = Color(0xFFA5470E);

  // -------------------------------------------------------------- wallpaper
  // WALLS (jsx:303) + .wp-* (css:330-338)
  static final List<TCWallEntry> walls = <TCWallEntry>[
    TCWallEntry(k: 'aurora', t: 'Aurora mist', spec: looks[0].wall),
    TCWallEntry(
      k: 'ocean',
      t: 'Ocean haze',
      spec: const TCWallSpec(
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xFFBDE3F3),
            cx: .10,
            cy: .05,
            rx: .60,
            ry: .40,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFC7D6F8),
            cx: .95,
            cy: .25,
            rx: .55,
            ry: .35,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFCDEFEA),
            cx: .70,
            cy: .98,
            rx: .70,
            ry: .45,
            stops: <double>[0, .70],
          ),
        ],
        linear: TCWallLinear(
          color1: Color(0xFFEDF6FA),
          color2: Color(0xFFE3EEF6),
        ),
      ),
    ),
    TCWallEntry(
      k: 'lavender',
      t: 'Lavender',
      spec: const TCWallSpec(
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xFFDACDF6),
            cx: .12,
            cy: .06,
            rx: .60,
            ry: .40,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFF2D3E6),
            cx: .92,
            cy: .30,
            rx: .55,
            ry: .35,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFCBD4F6),
            cx: .60,
            cy: .98,
            rx: .70,
            ry: .45,
            stops: <double>[0, .70],
          ),
        ],
        linear: TCWallLinear(
          color1: Color(0xFFF3F0FB),
          color2: Color(0xFFEAE5F6),
        ),
      ),
    ),
    TCWallEntry(
      k: 'sunrise',
      t: 'Sunrise',
      spec: const TCWallSpec(
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xFFFBD6C3),
            cx: .10,
            cy: .06,
            rx: .60,
            ry: .40,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFF6CFDA),
            cx: .95,
            cy: .28,
            rx: .55,
            ry: .35,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFFBE6C2),
            cx: .65,
            cy: .98,
            rx: .70,
            ry: .45,
            stops: <double>[0, .70],
          ),
        ],
        linear: TCWallLinear(
          color1: Color(0xFFFCF4EE),
          color2: Color(0xFFF6EBE7),
        ),
      ),
    ),
    TCWallEntry(
      k: 'mint',
      t: 'Mint garden',
      spec: const TCWallSpec(
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xFFC9EADB),
            cx: .10,
            cy: .06,
            rx: .60,
            ry: .40,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFCFE5F2),
            cx: .95,
            cy: .26,
            rx: .55,
            ry: .35,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFE2F0CE),
            cx: .65,
            cy: .98,
            rx: .70,
            ry: .45,
            stops: <double>[0, .70],
          ),
        ],
        linear: TCWallLinear(
          color1: Color(0xFFEFF8F3),
          color2: Color(0xFFE6F1EC),
        ),
      ),
    ),
    TCWallEntry(
      k: 'pearl',
      t: 'Pearl',
      spec: const TCWallSpec(
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xFFE4E7F0),
            cx: .12,
            cy: .06,
            rx: .60,
            ry: .40,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFF1ECE4),
            cx: .92,
            cy: .28,
            rx: .55,
            ry: .35,
            stops: <double>[0, .70],
          ),
          TCWallLayer(
            color: Color(0xFFE0E7F2),
            cx: .60,
            cy: .98,
            rx: .70,
            ry: .45,
            stops: <double>[0, .70],
          ),
        ],
        linear: TCWallLinear(
          color1: Color(0xFFF7F7F9),
          color2: Color(0xFFEDEEF2),
        ),
      ),
    ),
    TCWallEntry(k: 'silk', t: 'Silk waves', spec: looks[2].wall),
    TCWallEntry(
      k: 'prism',
      t: 'Prism',
      spec: const TCWallSpec(
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xB3FFFFFF),
            cx: .50,
            cy: .45,
            rx: .70,
            ry: .55,
            stops: <double>[0, .70],
          ),
        ],
        conic: TCWallConic(
          colors: <Color>[
            Color(0xFFD6E4FB),
            Color(0xFFE6D8F6),
            Color(0xFFF5DCE5),
            Color(0xFFFAE9D6),
            Color(0xFFD9EFE6),
            Color(0xFFD6E4FB),
          ],
          fromDeg: 200,
          cx: .65,
          cy: .35,
        ),
      ),
    ),
    TCWallEntry(
      k: 'dunes',
      t: 'Dunes',
      spec: const TCWallSpec(
        radials: <TCWallLayer>[
          TCWallLayer(
            color: Color(0xFFE8CDB9),
            cx: .20,
            cy: 1.18,
            rx: 1.60,
            ry: .55,
            stops: <double>[0, .45, .62],
          ),
          TCWallLayer(
            color: Color(0xFFEBD9C6),
            cx: .90,
            cy: 1.25,
            rx: 1.50,
            ry: .50,
            stops: <double>[0, .45, .60],
          ),
        ],
        linear: TCWallLinear(
          color1: Color(0xFFDCE7F7),
          color2: Color(0xFFF5EDE6),
        ),
      ),
    ),
  ];

  static TCWallSpec wallSpec(String k) => walls
      .firstWhere((TCWallEntry w) => w.k == k, orElse: () => walls.first)
      .spec;

  static String wallTitle(String k) => walls
      .firstWhere((TCWallEntry w) => w.k == k, orElse: () => walls.first)
      .t;
}

class TCWallEntry {
  const TCWallEntry({required this.k, required this.t, required this.spec});
  final String k;
  final String t;
  final TCWallSpec spec;
}

// ---------------------------------------------------------------- helpers

/// CSS `color-mix(in srgb, A pct%, transparent)` -> rgba(A, pct).
Color tcMix(Color c, double pct) => c.withValues(alpha: pct / 100.0);

/// CSS `color-mix(in srgb, A pct%, B)` where [b] is opaque.
Color tcMixOver(Color a, double pct, Color b) =>
    Color.alphaBlend(a.withValues(alpha: pct / 100.0), b);

/// rgba(27,45,91,x) - the prototype's universal "navy shadow" ink.
const Color tcNavyInk = Color(0xFF1B2D5B);

Color tcNavyAlpha(double a) => tcNavyInk.withValues(alpha: a);
