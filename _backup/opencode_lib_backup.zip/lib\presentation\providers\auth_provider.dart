// Login state. The prototype accepts any credentials (jsx:8.1) - validation is
// present so the real flow has a seam, but it never blocks the prototype path.
library;

import 'package:flutter_riverpod/flutter_riverpod.dart';

class AuthState {
  const AuthState({
    this.loggedIn = false,
    this.username = '',
    this.showPass = false,
    this.forgotSent = false,
    this.busy = false,
  });

  final bool loggedIn;
  final String username;
  final bool showPass;
  final bool forgotSent;
  final bool busy;

  AuthState copyWith({
    bool? loggedIn,
    String? username,
    bool? showPass,
    bool? forgotSent,
    bool? busy,
  }) => AuthState(
    loggedIn: loggedIn ?? this.loggedIn,
    username: username ?? this.username,
    showPass: showPass ?? this.showPass,
    forgotSent: forgotSent ?? this.forgotSent,
    busy: busy ?? this.busy,
  );
}

class AuthNotifier extends Notifier<AuthState> {
  @override
  AuthState build() => const AuthState();

  void setUsername(String v) => state = state.copyWith(username: v);

  void togglePass() => state = state.copyWith(showPass: !state.showPass);

  /// Returns the message to toast, or null when nothing happened. jsx:8.1.
  Future<String?> login(String user, String pass) async {
    final String u = user.trim();
    if (u.isEmpty || pass.isEmpty) {
      state = state.copyWith(busy: false);
      return 'Fill all required fields';
    }
    state = state.copyWith(busy: true);
    await Future<void>.delayed(const Duration(milliseconds: 450));
    state = state.copyWith(loggedIn: true, username: u, busy: false);
    return null;
  }

  void logout() => state = const AuthState();

  /// jsx:2.2 - flips the screen into the "check your email" state.
  Future<String?> sendReset(String email) async {
    final String e = email.trim();
    if (e.isEmpty) return 'Fill all required fields';
    if (!e.contains('@') || !e.contains('.')) {
      return 'Enter a valid email address';
    }
    await Future<void>.delayed(const Duration(milliseconds: 400));
    state = state.copyWith(forgotSent: true);
    return null;
  }

  void resetForgot() => state = state.copyWith(forgotSent: false);
}

final NotifierProvider<AuthNotifier, AuthState> authProvider =
    NotifierProvider<AuthNotifier, AuthState>(AuthNotifier.new);