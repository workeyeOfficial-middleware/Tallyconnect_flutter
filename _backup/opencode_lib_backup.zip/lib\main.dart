// App entry. Boots SharedPreferences + the optional sqflite mirror, publishes
// them as provider overrides, then hands off to the theme-scoped root.
library;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/design/tc_colors.dart';
import 'core/design/tc_glass.dart';
import 'core/design/tc_theme_engine.dart';
import 'core/design/tc_wallpaper.dart';
import 'core/router/app_router.dart';
import 'core/storage/app_database.dart';
import 'core/storage/local_storage.dart';
import 'presentation/providers/app_providers.dart';
import 'presentation/providers/theme_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations(<DeviceOrientation>[
    DeviceOrientation.portraitUp,
  ]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      statusBarBrightness: Brightness.light,
      systemNavigationBarColor: Color(0x00000000),
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );

  // Storage is a hard dependency; the DB is best-effort so a platform without
  // sqflite still boots on mock data alone.
  final LocalStorage storage = await LocalStorage.open();
  AppDatabase? database;
  try {
    database = await AppDatabase.open();
  } catch (_) {
    database = null;
  }

  runApp(
    ProviderScope(
      overrides: <Override>[
        localStorageProvider.overrideWithValue(storage),
        appDatabaseProvider.overrideWithValue(database),
      ],
      child: const TallyConnectApp(),
    ),
  );
}

class TallyConnectApp extends ConsumerWidget {
  const TallyConnectApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final TCTheme theme = ref.watch(themeProvider);
    return TCScope(
      theme: theme,
      child: MaterialApp(
        title: 'TallyConnect',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.light,
          fontFamily: 'Figtree',
          scaffoldBackgroundColor: const Color(0xFFE9EDF7),
          colorScheme: ColorScheme.fromSeed(
            seedColor: theme.acc,
            brightness: Brightness.light,
          ),
          splashFactory: NoSplash.splashFactory,
          highlightColor: Colors.transparent,
          splashColor: Colors.transparent,
        ),
        builder: (BuildContext context, Widget? child) => TCWallpaper(
          child: child ?? const SizedBox.shrink(),
        ),
        home: const TCScreenHost(),
      ),
    );
  }
}

/// Maps `NavState.screen` to a widget inside an animated switch. Kept as a
/// separate widget so the whole tree rebuilds on theme change without losing
/// the screen's own state.
class TCScreenHost extends ConsumerWidget {
  const TCScreenHost({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final NavState nav = ref.watch(navProvider);
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 420),
      switchInCurve: Cubic(0.2, 0.85, 0.2, 1),
      switchOutCurve: Curves.easeIn,
      layoutBuilder:
          (Widget? current, List<Widget> previous) => Stack(
            fit: StackFit.expand,
            children: <Widget>[...previous, ?current],
          ),
      transitionBuilder: (Widget child, Animation<double> a) {
        final Animation<Offset> slide = Tween<Offset>(
          begin: Offset(nav.isForward ? 30 / 390 : -30 / 390, 0),
          end: Offset.zero,
        ).animate(a);
        return SlideTransition(position: slide, child: child);
      },
      // Keying on the screen key resets state between screens, matching the
      // prototype's full-remount `switch (s)` behaviour.
      child: KeyedSubtree(
        key: ValueKey<String>(nav.screen),
        child: TCScreenBuilder(screen: nav.screen, extra: nav.extra),
      ),
    );
  }
}

/// Resolves a screen key to its widget. Screens land here as they are built;
/// unknown keys fall back to Home so a bad `go()` can never white-screen.
class TCScreenBuilder extends StatelessWidget {
  const TCScreenBuilder({super.key, required this.screen, required this.extra});

  final String screen;
  final Map<String, String> extra;

  @override
  Widget build(BuildContext context) {
    // TODO(screens): each case wires to its screen widget as it lands.
    final Widget? w = TCScreenRegistry.resolve(screen, extra);
    if (w != null) return w;
    return Scaffold(
      body: Center(child: Text('Screen not built yet: $screen')),
    );
  }
}

/// Central screen registry so `TCScreens` keys and their widgets stay in sync.
class TCScreenRegistry {
  TCScreenRegistry._();

  static final Map<String, Widget Function(Map<String, String>)> _builders =
      <String, Widget Function(Map<String, String>)>{};

  static void register(
    String key,
    Widget Function(Map<String, String>) builder,
  ) => _builders[key] = builder;

  static Widget? resolve(String key, Map<String, String> extra) =>
      _builders[key]?.call(extra);
}

/// Colours the prototype's glass tint uses for fallback paints, re-exported so
/// screens do not need to import tc_colors directly.
const Color tcSurfaceFallback = Color(0xFFE9EDF7);

/// Convenience so screens can pull the resolved accent without a TCScope read.
Color tcAccentOf(BuildContext context) => TCScope.of(context).acc;

/// Semantic feature colour by key (`tcSemantic` in tc_glass).
Color tcSemanticOf(BuildContext context, String key) =>
    tcSemantic(context, key);

/// Look title lookup used by the appearance sheet.
String tcLookTitle(String key) {
  final List<String>? s = TCColors.lookSig[key];
  return (s != null && s.isNotEmpty) ? s[0] : key;
}