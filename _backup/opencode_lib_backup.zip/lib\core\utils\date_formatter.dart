// Date + text helpers - exact ports of MON/fdate/initials() from
// prototype/TallyConnect_App_Source.jsx:75-77.
library;

const List<String> tcMon = <String>[
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

/// `fdate(s)` - `2026-09-26` -> `26 Sep 2026`; anything else passes through.
String fdate(String? s) {
  if (s == null || s.isEmpty) return '—';
  final List<String> p = s.split('-');
  if (p.length < 3) return s;
  final int m = int.tryParse(p[1]) ?? 0;
  if (m < 1 || m > 12) return s;
  return '${p[2]} ${tcMon[m - 1]} ${p[0]}';
}

/// `2026-09-26` -> `26 Sep`
String fdateShort(String? s) {
  if (s == null || s.isEmpty) return '—';
  final List<String> p = s.split('-');
  if (p.length < 3) return s;
  final int m = int.tryParse(p[1]) ?? 0;
  if (m < 1 || m > 12) return s;
  return '${p[2]} ${tcMon[m - 1]}';
}

/// `initials(n)` - first character, upper-cased. NOTE: the prototype takes only
/// the *first* letter, so "Shree Balaji Traders" -> "S".
String tcInitials(String? n) {
  final String t = (n ?? '?').trim();
  if (t.isEmpty) return '?';
  return t[0].toUpperCase();
}

/// Trim + collapse runs of whitespace, matching the prototype's text helpers.
String tcClean(String? s) => (s ?? '').replaceAll(RegExp(r'\s+'), ' ').trim();

/// "1 coil" / "30 coil" from the SALES9 line items.
String qtyLabel(String unit, num qty) => '$qty $unit';
