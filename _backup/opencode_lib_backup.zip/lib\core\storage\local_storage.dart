// SharedPreferences wrapper for the prototype's localStorage keys
// (inventory report section 4.1 / 16.1).
library;

import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

/// Namespaced keys + typed read/write helpers.
///
/// Every getter is null-safe: a missing or corrupt value falls back to the
/// supplied default rather than throwing, so a bad write can never brick the
/// app on launch.
class LocalStorage {
  LocalStorage(this._prefs);

  final SharedPreferences _prefs;

  static Future<LocalStorage> open() async =>
      LocalStorage(await SharedPreferences.getInstance());

  // ---- keys ---------------------------------------------------------------

  /// Page layout per workspace: `{pages:[{widgets,hidden}],pageIdx}`.
  static String kPages(String wsId) => 'tc-liquid-pages-v2-$wsId';

  /// Bottom tab order, e.g. `[0,1,2,3,4]`.
  static const String kTabOrder = 'tc-liquid-tabs';

  /// Current page index, per workspace.
  static String kPageIdx(String wsId) => 'tc-liquid-page-v2-$wsId';

  /// Pinned widget keys per workspace.
  static String kPinned(String wsId) => 'tc-liquid-pinned-$wsId';

  /// List view prefs (order / hidden / sort) per list id.
  static String kLists(String listId) => 'tc-liquid-lists-$listId';

  /// Saved layout preset name.
  static const String kPreset = 'tc-liquid-preset';

  /// Theme / accent / wallpaper / glass customisation.
  static const String kLook = 'tc-liquid-look';

  /// Active company id.
  static const String kCompany = 'tc-company';

  /// Active workspace id.
  static const String kWs = 'tc-ws';

  /// Recent search terms, newest first.
  static const String kSearch = 'tc-search-recent';

  /// Cached mock rows, keyed by dataset name - lets the sqflite mirror and the
  /// local cache agree on one vocabulary.
  static String kCache(String dataset) => 'tc-cache-$dataset';

  // ---- primitives ---------------------------------------------------------

  String? getString(String key) => _prefs.getString(key);

  void writeString(String key, String value) => _prefs.setString(key, value);

  int getInt(String key, int fallback) => _prefs.getInt(key) ?? fallback;

  void writeInt(String key, int value) => _prefs.setInt(key, value);

  bool getBool(String key, bool fallback) => _prefs.getBool(key) ?? fallback;

  void writeBool(String key, bool value) => _prefs.setBool(key, value);

  double getDouble(String key, double fallback) =>
      _prefs.getDouble(key) ?? fallback;

  void writeDouble(String key, double value) => _prefs.setDouble(key, value);

  String? readJson(String key) => _prefs.getString(key);

  Map<String, dynamic>? readJsonMap(String key) {
    final String? raw = _prefs.getString(key);
    if (raw == null || raw.isEmpty) return null;
    try {
      final Object? decoded = jsonDecode(raw);
      return decoded is Map<String, dynamic> ? decoded : null;
    } on FormatException {
      return null;
    }
  }

  void writeJson(String key, Object value) =>
      _prefs.setString(key, jsonEncode(value));

  List<dynamic>? readJsonList(String key) {
    final String? raw = _prefs.getString(key);
    if (raw == null || raw.isEmpty) return null;
    try {
      final Object? decoded = jsonDecode(raw);
      return decoded is List ? decoded : null;
    } on FormatException {
      return null;
    }
  }

  void writeJsonList(String key, List<Object?> value) =>
      _prefs.setString(key, jsonEncode(value));

  /// Reads a `List<String>`; ignores non-string members.
  List<String> readStringList(String key) {
    final List<dynamic>? raw = readJsonList(key);
    if (raw == null) return const <String>[];
    return raw.whereType<String>().toList(growable: false);
  }

  void writeStringList(String key, List<String> value) =>
      writeJsonList(key, value);

  void remove(String key) => _prefs.remove(key);

  Future<bool> clear() => _prefs.clear();

  // ---- domain shortcuts ---------------------------------------------------

  /// Tab order with duplicates and out-of-range entries filtered out, so a
  /// corrupt write degrades to `[0,1,2,3,4]` instead of breaking the pill.
  List<int> tabOrder(int tabCount) {
    final List<String> raw = readStringList(kTabOrder);
    if (raw.isEmpty) return List<int>.generate(tabCount, (int i) => i);
    final List<int> out = <int>[];
    for (final String s in raw) {
      final int? i = int.tryParse(s);
      if (i != null && i >= 0 && i < tabCount && !out.contains(i)) out.add(i);
    }
    for (int i = 0; i < tabCount; i++) {
      if (!out.contains(i)) out.add(i);
    }
    return out;
  }

  void writeTabOrder(List<int> order) =>
      writeStringList(kTabOrder, order.map((int i) => '$i').toList(growable: false));

  String get activeCompany => getString(kCompany) ?? '';

  set activeCompany(String v) => writeString(kCompany, v);

  String get activeWorkspace => getString(kWs) ?? 'def';

  set activeWorkspace(String v) => writeString(kWs, v);

  /// Serialise the active `TCTheme` fields as the `tc-liquid-look` payload.
  Map<String, dynamic> readLook() {
    final Map<String, dynamic>? m = readJsonMap(kLook);
    if (m == null) return <String, dynamic>{};
    return m;
  }

  void writeLook(Map<String, dynamic> value) => writeJson(kLook, value);

  /// Newest-first recent searches, capped at 8 (js x:8.14).
  List<String> readRecentSearches() => readStringList(kSearch);

  void pushRecentSearch(String term) {
    final String t = term.trim();
    if (t.isEmpty) return;
    final List<String> list = readRecentSearches()
      ..remove(t)
      ..insert(0, t);
    writeStringList(kSearch, list.take(8).toList(growable: false));
  }
}