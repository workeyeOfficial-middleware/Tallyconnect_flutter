// Active look / accent / wallpaper / glass density. Mirrors the `tc-liquid-look`
// payload from the prototype (jsx:8.18) and hands widgets a resolved [TCTheme].
library;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/design/tc_colors.dart';
import '../../core/design/tc_theme_engine.dart';
import 'app_providers.dart';

class ThemeNotifier extends Notifier<TCTheme> {
  @override
  TCTheme build() {
    final Map<String, dynamic> saved = ref
        .watch(localStorageProvider)
        ?.readLook() ??
        const <String, dynamic>{};
    if (saved.isEmpty) return TCTheme.initial();
    return TCTheme(
      mode: (saved['mode'] as String?) == 'custom'
          ? TCLookMode.custom
          : TCLookMode.look,
      preset: (saved['preset'] as String?) ?? 'aurora',
      accent: (saved['accent'] as String?) ?? 'look',
      wallK: (saved['wallK'] as String?) ?? 'theme',
      glass: (saved['glass'] as num?)?.toInt() ?? 60,
      custom: saved['custom'] as String?,
      combo: (saved['combo'] as num?)?.toInt() ?? 0,
      iconMatch: (saved['iconMatch'] as bool?) ?? true,
    );
  }

  void _persist(TCTheme t) {
    state = t;
    ref.read(localStorageProvider)?.writeLook(<String, dynamic>{
      'mode': t.mode.name,
      'preset': t.preset,
      'accent': t.accent,
      'wallK': t.wallK,
      'glass': t.glass,
      'custom': t.custom,
      'combo': t.combo,
      'iconMatch': t.iconMatch,
    });
  }

  /// Base look. Changing it drops a custom accent back to "match look".
  void setPreset(String preset) => _persist(
    state.copyWith(preset: preset, mode: TCLookMode.look, accent: 'look'),
  );

  /// Accent override, rejected when the look forbids it (TCColors.okAccent).
  void setAccent(String accent) {
    if (!TCColors.okAccent(state.preset, accent)) return;
    _persist(state.copyWith(accent: accent, mode: TCLookMode.look));
  }

  void setCustomHex(String hex) => _persist(
    state.copyWith(mode: TCLookMode.custom, custom: hex),
  );

  void setCombo(int combo) => _persist(state.copyWith(combo: combo));

  /// 'theme' follows the look; anything else picks a named wallpaper.
  void setWallpaper(String key) => _persist(state.copyWith(wallK: key));

  /// 0..100, rounded to the nearest 10 like the prototype.
  void setGlass(int g) =>
      _persist(state.copyWith(glass: ((g / 10).round() * 10).clamp(0, 100)));

  void setIconMatch(bool v) => _persist(state.copyWith(iconMatch: v));

  void reset() {
    ref.read(localStorageProvider)?.remove('tc-liquid-look');
    state = TCTheme.initial();
  }
}

final NotifierProvider<ThemeNotifier, TCTheme> themeProvider =
    NotifierProvider<ThemeNotifier, TCTheme>(ThemeNotifier.new);

/// Accent keys the active look allows, for the look sheet's swatch grid.
final Provider<List<String>> allowedAccentsProvider = Provider<List<String>>(
  (Ref ref) {
    final String preset = ref.watch(themeProvider).preset;
    final List<String>? a = TCColors.lookAcc[preset];
    return a ?? <String>[...TCColors.accents.map((TCAccent x) => x.k)];
  },
);

final Provider<List<TCWallEntry>> wallpapersProvider = Provider<List<TCWallEntry>>(
  (Ref ref) => TCColors.walls,
);