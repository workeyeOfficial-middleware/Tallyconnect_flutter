// Typed voucher / entry model. Wraps the raw `Map<String, dynamic>` rows in
// TCMockData.vouchers and the rows produced by the entry wizard so screens
// never have to index into maps.
library;

import '../../core/utils/date_formatter.dart';

/// Voucher / entry kinds, matching `KIND` keys (jsx:106-113).
class TCKinds {
  TCKinds._();

  static const String sales = 'sales';
  static const String purchase = 'purchase';
  static const String receipt = 'receipt';
  static const String payment = 'payment';
  static const String journal = 'journal';

  static const List<String> all = <String>[
    sales,
    purchase,
    receipt,
    payment,
    journal,
  ];

  /// Kinds that carry an item list in the wizard (FT config, jsx:193-199).
  static const List<String> itemKinds = <String>[sales, purchase];

  /// Kinds that carry Dr/Cr journal lines instead of items.
  static const List<String> contraKinds = <String>[journal];

  /// Sync status values used on badges.
  static const String statusOk = 'ok';
  static const String statusWait = 'wait';
  static const String statusError = 'error';
}

/// One line of a sales/purchase voucher (wizard step 1).
class TCEntryItem {
  const TCEntryItem({
    required this.itemId,
    required this.name,
    this.rate = 0,
    this.qty = 1,
    this.unit = 'pc',
    this.gst = 0,
  });

  final String itemId;
  final String name;
  final double rate;
  final double qty;
  final String unit;
  final double gst;

  double get amount => rate * qty;
  double get gstAmount => amount * gst / 100;

  /// `rate x qty unit` subtitle used on the wizard line.
  String get calcLabel {
    final String r = rate == rate.roundToDouble()
        ? rate.toStringAsFixed(0)
        : rate.toStringAsFixed(2);
    final String q = qty == qty.roundToDouble()
        ? qty.toStringAsFixed(0)
        : qty.toStringAsFixed(2);
    final String g = gst == 0 ? '' : ' + ${_trim(gst)}% GST';
    return '$r x $q $unit$g';
  }

  TCEntryItem copyWith({double? qty, double? rate}) => TCEntryItem(
    itemId: itemId,
    name: name,
    rate: rate ?? this.rate,
    qty: qty ?? this.qty,
    unit: unit,
    gst: gst,
  );

  factory TCEntryItem.fromMap(Map<String, dynamic> m) => TCEntryItem(
    itemId: (m['id'] ?? m['itemId'] ?? '') as String,
    name: (m['n'] ?? m['name'] ?? '') as String,
    rate: _num(m['rate'] ?? m['r']),
    qty: _num(m['qty']) <= 0 ? 1 : _num(m['qty']),
    unit: (m['unit'] ?? 'pc') as String,
    gst: _num(m['gst']),
  );

  Map<String, dynamic> toMap() => <String, dynamic>{
    'id': itemId,
    'n': name,
    'rate': rate,
    'qty': qty,
    'unit': unit,
    'gst': gst,
  };
}

/// One Dr/Cr line of a journal voucher.
class TCJournalLine {
  const TCJournalLine({
    required this.ledgerId,
    required this.name,
    required this.group,
    required this.amount,
    this.side = 'dr',
  });

  final String ledgerId;
  final String name;
  final String group;
  final double amount;

  /// 'dr' | 'cr'
  final String side;

  bool get isDr => side == 'dr';

  TCJournalLine copyWith({String? side, double? amount, String? name}) =>
      TCJournalLine(
        ledgerId: ledgerId,
        name: name ?? this.name,
        group: group,
        amount: amount ?? this.amount,
        side: side ?? this.side,
      );

  factory TCJournalLine.fromMap(Map<String, dynamic> m) => TCJournalLine(
    ledgerId: (m['id'] ?? m['ledgerId'] ?? '') as String,
    name: (m['n'] ?? m['name'] ?? '') as String,
    group: (m['g'] ?? m['group'] ?? '') as String,
    amount: _num(m['amt'] ?? m['amount']),
    side: (m['side'] ?? 'dr') as String,
  );

  Map<String, dynamic> toMap() => <String, dynamic>{
    'id': ledgerId,
    'n': name,
    'g': group,
    'amt': amount,
    'side': side,
  };
}

/// A voucher or newly recorded entry (sales, purchase, receipt, payment,
/// journal). Reads both the mock row shape and the wizard's saved shape.
class TCVoucher {
  const TCVoucher({
    required this.id,
    required this.kind,
    this.no = '',
    this.party = '',
    this.amt = 0,
    this.day,
    this.date,
    this.due,
    this.status = TCKinds.statusOk,
    this.time = '',
    this.ref,
    this.note = '',
    this.mode = 'cash',
    this.acc = '',
    this.bank = '',
    this.items = const <TCEntryItem>[],
    this.lines = const <TCJournalLine>[],
    this.paid = 0,
    this.draft = false,
    this.fresh = false,
  });

  final String id;
  final String kind;
  final String no;
  final String party;
  final double amt;
  final int? day;
  final String? date;
  final String? due;
  final String status;
  final String time;
  final String? ref;
  final String note;
  final String mode;
  final String acc;
  final String bank;
  final List<TCEntryItem> items;
  final List<TCJournalLine> lines;
  final double paid;
  final bool draft;
  final bool fresh;

  bool get hasItems => items.isNotEmpty;
  bool get hasLines => lines.isNotEmpty;
  bool get isContra => TCKinds.contraKinds.contains(kind);

  /// Money in (receipt) / sales read as positive, out as negative - mirrors the
  /// prototype's green/red amount colouring on voucher rows.
  bool get isMoneyIn =>
      kind == TCKinds.receipt || kind == TCKinds.sales;

  bool get isSynced => status == TCKinds.statusOk;
  bool get isWaiting => status == TCKinds.statusWait;

  /// Balance still to get / to pay (item kinds only).
  double get balance => (amt - paid).clamp(0, double.infinity);

  double get subtotal {
    if (items.isNotEmpty) {
      return items.fold<double>(0, (double a, TCEntryItem i) => a + i.amount);
    }
    if (lines.isNotEmpty) {
      return lines.fold<double>(
        0,
        (double a, TCJournalLine l) => a + (l.isDr ? l.amount : 0),
      );
    }
    return amt;
  }

  double get gstTotal =>
      items.fold<double>(0, (double a, TCEntryItem i) => a + i.gstAmount);

  /// `26 Sep` from an ISO date, or `day 24` for mock rows that only carry a day.
  String get dateLabel {
    if (date != null && date!.isNotEmpty) return fdateShort(date);
    if (day != null) return 'day $day';
    return '—';
  }

  String get fullDateLabel {
    if (date != null && date!.isNotEmpty) return fdate(date);
    if (day != null) return 'day $day';
    return '—';
  }

  /// Journal totals used by the balance indicator.
  double get drTotal =>
      lines.fold<double>(0, (double a, TCJournalLine l) => a + (l.isDr ? l.amount : 0));
  double get crTotal =>
      lines.fold<double>(0, (double a, TCJournalLine l) => a + (l.isDr ? 0 : l.amount));

  bool get balanced => drTotal > 0 && (drTotal - crTotal).abs() < 0.01;
  double get balanceDiff => (drTotal - crTotal).abs();

  TCVoucher copyWith({
    String? status,
    String? time,
    double? paid,
    bool? draft,
    bool? fresh,
    String? note,
  }) => TCVoucher(
    id: id,
    kind: kind,
    no: no,
    party: party,
    amt: amt,
    day: day,
    date: date,
    due: due,
    status: status ?? this.status,
    time: time ?? this.time,
    ref: ref,
    note: note ?? this.note,
    mode: mode,
    acc: acc,
    bank: bank,
    items: items,
    lines: lines,
    paid: paid ?? this.paid,
    draft: draft ?? this.draft,
    fresh: fresh ?? this.fresh,
  );

  factory TCVoucher.fromMap(Map<String, dynamic> m) {
    final List<dynamic> rawItems = (m['items'] as List<dynamic>?) ?? const <dynamic>[];
    final List<dynamic> rawLines = (m['lines'] as List<dynamic>?) ?? const <dynamic>[];
    final String kind = (m['kind'] ?? m['k'] ?? TCKinds.sales) as String;
    final double amt = _num(m['amt'] ?? m['v']);
    final double paid = _num(m['payAmt'] ?? m['paid']);
    return TCVoucher(
      id: (m['id'] ?? '') as String,
      kind: kind,
      no: (m['no'] ?? '') as String,
      party: (m['party'] ?? m['p'] ?? '') as String,
      amt: amt,
      day: m['day'] == null ? null : _num(m['day']).toInt(),
      date: m['date'] as String?,
      due: (m['due'] ?? m['dueDate']) as String?,
      status: (m['status'] ?? (m['syn'] == false ? TCKinds.statusWait : TCKinds.statusOk))
          as String,
      time: (m['time'] ?? '') as String,
      ref: m['ref'] as String?,
      note: (m['note'] ?? '') as String,
      mode: (m['mode'] ?? 'cash') as String,
      acc: (m['acc'] ?? '') as String,
      bank: (m['bank'] ?? '') as String,
      items: rawItems
          .map((dynamic e) => TCEntryItem.fromMap(e as Map<String, dynamic>))
          .toList(growable: false),
      lines: rawLines
          .map((dynamic e) => TCJournalLine.fromMap(e as Map<String, dynamic>))
          .toList(growable: false),
      paid: paid > 0 ? paid : (paid == 0 && m['payAmt'] == null ? 0 : 0),
      draft: (m['draft'] ?? false) as bool,
      fresh: (m['fresh'] ?? false) as bool,
    );
  }

  Map<String, dynamic> toMap() => <String, dynamic>{
    'id': id,
    'kind': kind,
    'no': no,
    'party': party,
    'amt': amt,
    if (day != null) 'day': day,
    if (date != null) 'date': date,
    if (due != null) 'due': due,
    'status': status,
    'time': time,
    if (ref != null) 'ref': ref,
    'note': note,
    'mode': mode,
    'acc': acc,
    'bank': bank,
    'items': items.map((TCEntryItem i) => i.toMap()).toList(growable: false),
    'lines': lines.map((TCJournalLine l) => l.toMap()).toList(growable: false),
    'paid': paid,
    'draft': draft,
    'fresh': fresh,
  };
}

/// One row on a vouchers list. Wraps `VOUCH`, `RECV` and `PAYB`.
class TCVoucherRow {
  const TCVoucherRow({
    required this.id,
    required this.kind,
    required this.party,
    required this.no,
    required this.amt,
    this.due,
    this.dateLabel = '',
    this.voucherId,
  });

  final String id;
  final String kind;
  final String party;
  final String no;
  final double amt;
  final String? due;
  final String dateLabel;

  /// Set when the row maps to a voucher in [TCVoucher.id] space.
  final String? voucherId;

  factory TCVoucherRow.fromMap(Map<String, dynamic> m) => TCVoucherRow(
    id: (m['id'] ?? '') as String,
    kind: (m['kind'] ?? m['k'] ?? TCKinds.sales) as String,
    party: (m['party'] ?? m['p'] ?? m['n'] ?? '') as String,
    no: (m['no'] ?? m['t'] ?? '') as String,
    amt: _num(m['amt'] ?? m['v']),
    due: (m['due'] ?? m['dueDate']) as String?,
    dateLabel: (m['date'] ?? m['d'] ?? '') as String,
    voucherId: m['ref'] as String?,
  );
}

double _num(Object? v) {
  if (v is num) return v.toDouble();
  if (v is String) return double.tryParse(v) ?? 0;
  return 0;
}

String _trim(double v) =>
    v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(2);