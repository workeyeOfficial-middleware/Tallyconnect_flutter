// The 4-step entry wizard. One form object per prototype (FORM, jsx:201-210),
// driven by the per-type [TCFlowConfig] (js x:3.11).
library;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/models/core_models.dart';
import '../../data/models/voucher_model.dart';
import 'app_providers.dart';

/// Mutable entry form. Field names match FORM so the port stays greppable.
class FlowForm {
  FlowForm({
    this.type = TCKinds.sales,
    this.no = '',
    this.date = '2026-09-26',
    this.party = '',
    this.ref = '',
    this.supInv = '',
    this.amt = '',
    this.payAmt = '',
    this.mode = 'cash',
    this.acc = TCAccount.cashId,
    this.bank = '',
    this.note = '',
    List<TCEntryItem>? items,
    List<TCJournalLine>? lines,
  }) : items = items ?? <TCEntryItem>[],
       lines = lines ?? <TCJournalLine>[];

  String type;
  String no;
  String date;
  String party;
  String ref;
  String supInv;
  String amt;
  String payAmt;
  String mode;
  String acc;
  String bank;
  String note;
  List<TCEntryItem> items;
  List<TCJournalLine> lines;

  double get amtNum => double.tryParse(amt) ?? 0;
  double get payNum => double.tryParse(payAmt) ?? 0;

  double get total {
    if (items.isNotEmpty) {
      final double sub = items.fold<double>(
        0,
        (double a, TCEntryItem i) => a + i.amount,
      );
      final double g = items.fold<double>(
        0,
        (double a, TCEntryItem i) => a + i.gstAmount,
      );
      return sub + g;
    }
    if (lines.isNotEmpty) return drTotal;
    return amtNum;
  }

  double get subtotal =>
      items.fold<double>(0, (double a, TCEntryItem i) => a + i.amount);
  double get gstTotal =>
      items.fold<double>(0, (double a, TCEntryItem i) => a + i.gstAmount);

  double get drTotal =>
      lines.fold<double>(0, (double a, TCJournalLine l) => a + (l.isDr ? l.amount : 0));
  double get crTotal =>
      lines.fold<double>(0, (double a, TCJournalLine l) => a + (l.isDr ? 0 : l.amount));

  bool get balanced => drTotal > 0 && (drTotal - crTotal).abs() < 0.01;

  /// Dr/Cr gap shown in the "Not matching" warning (jsx:8.12).
  double get balanceDiff => (drTotal - crTotal).abs();

  /// Still to get / to pay - red when positive (jsx:2.8 step 2).
  double get balance => (total - payNum).clamp(0, double.infinity);
  bool get settled => balance <= 0.01;

  bool get hasBankFields => mode != 'cash';
}

class FlowState {
  const FlowState({this.step = 0, this.config});

  final int step;
  final TCFlowConfig? config;

  int get stepCount => config?.stepCount ?? 0;
  bool get isFirst => step <= 0;
  bool get isLast => step >= stepCount - 1;

  /// `Details`, `Items`, ... - the label of the current step.
  String get stepLabel =>
      (config != null && step < stepCount) ? config!.steps[step] : '';

  FlowState copyWith({int? step, TCFlowConfig? config}) =>
      FlowState(step: step ?? this.step, config: config ?? this.config);
}

class FlowEntryNotifier extends Notifier<FlowState> {
  FlowForm form = FlowForm();

  @override
  FlowState build() => const FlowState();

  /// jsx:8.2 step 1 - resets to a blank form and loads the type's config.
  void start(String type) {
    final TCFlowConfig? cfg = ref.read(repositoryProvider).flowConfig(type);
    form = FlowForm(type: type);
    state = FlowState(step: 0, config: cfg);
  }

  void setStep(int i) {
    final int max = state.stepCount - 1;
    state = state.copyWith(step: i.clamp(0, max < 0 ? 0 : max));
  }

  void next() => setStep(state.step + 1);
  void prev() => setStep(state.step - 1);

  // ---- validation ---------------------------------------------------------

  /// Returns the blocking message for the current step, or null when it may
  /// advance (jsx:9.1 / 8.12).
  String? validate() {
    final TCFlowConfig? cfg = state.config;
    if (cfg == null) return null;
    final int s = state.step;

    // Step 0 - Details
    if (s == 0) {
      if (form.date.trim().isEmpty) return 'Pick a date';
      if (cfg.hasParty && form.party.trim().isEmpty) {
        return cfg.contra ? 'Pick the main account' : 'Fill party';
      }
      if (!cfg.items && !cfg.contra && form.amtNum <= 0) return 'Fill amount';
    }

    // Items step
    for (int i = 1; i < cfg.stepCount; i++) {
      if (cfg.steps[i] != 'Items') continue;
      if (form.items.isEmpty) return 'Add at least one item';
    }

    // Accounts step - journal must balance
    for (int i = 1; i < cfg.stepCount; i++) {
      if (cfg.steps[i] != 'Accounts') continue;
      if (form.lines.isEmpty) return 'Add at least one account';
      if (!form.balanced) {
        return 'Debit and credit must match (${form.balanceDiff.toStringAsFixed(2)} apart)';
      }
    }
    return null;
  }

  // ---- field setters ------------------------------------------------------

  void setNo(String v) => form.no = v;
  void setDate(String v) => form.date = v;
  void setParty(String v) => form.party = v;
  void setRef(String v) => form.ref = v;
  void setSupInv(String v) => form.supInv = v;
  void setAmt(String v) => form.amt = v;
  void setNote(String v) => form.note = v;
  void setBank(String v) => form.bank = v;

  /// Mode change also snaps the account to Cash in hand for cash, and back to
  /// the first bank account otherwise (jsx:8.11).
  void setMode(String mode) {
    form.mode = mode;
    final List<TCAccount> accts = ref.read(accountsProvider);
    if (mode == 'cash') {
      form.acc = TCAccount.cashId;
      form.bank = '';
    } else {
      final Iterable<TCAccount> banks = accts.where(
        (TCAccount a) => !a.isCash,
      );
      if (banks.isNotEmpty) form.acc = banks.first.id;
      if (form.bank.isEmpty) form.bank = '';
    }
  }

  void setAcc(String id) => form.acc = id;

  /// Payment step defaults the paid amount to the bill total the first time.
  void syncPayAmount() {
    if (form.payAmt.isEmpty) form.payAmt = form.total.toStringAsFixed(2);
  }

  void clearPayAmount() => form.payAmt = '';

  // ---- items --------------------------------------------------------------

  void addItem(TCItem item) {
    if (form.items.any((TCEntryItem i) => i.itemId == item.id)) return;
    form.items = <TCEntryItem>[
      ...form.items,
      TCEntryItem(
        itemId: item.id,
        name: item.name,
        rate: item.rate,
        qty: 1,
        unit: item.unit,
        gst: item.gst,
      ),
    ];
    syncPayAmount();
  }

  void removeItemAt(int i) {
    if (i < 0 || i >= form.items.length) return;
    final List<TCEntryItem> next = List<TCEntryItem>.of(form.items)..removeAt(i);
    form.items = next;
  }

  void setQty(int i, double qty) {
    if (i < 0 || i >= form.items.length) return;
    final List<TCEntryItem> next = List<TCEntryItem>.of(form.items);
    next[i] = next[i].copyWith(qty: qty < 1 ? 1 : qty);
    form.items = next;
    syncPayAmount();
  }

  // ---- journal lines ------------------------------------------------------

  void addLine(TCLedger ledger, String side) {
    form.lines = <TCJournalLine>[
      ...form.lines,
      TCJournalLine(
        ledgerId: ledger.id,
        name: ledger.name,
        group: ledger.group,
        amount: 0,
        side: side,
      ),
    ];
  }

  void removeLineAt(int i) {
    if (i < 0 || i >= form.lines.length) return;
    final List<TCJournalLine> next =
        List<TCJournalLine>.of(form.lines)..removeAt(i);
    form.lines = next;
  }

  void toggleLineSide(int i) {
    if (i < 0 || i >= form.lines.length) return;
    final List<TCJournalLine> next = List<TCJournalLine>.of(form.lines);
    next[i] = next[i].copyWith(side: next[i].isDr ? 'cr' : 'dr');
    form.lines = next;
  }

  void setLineAmount(int i, double amount) {
    if (i < 0 || i >= form.lines.length) return;
    final List<TCJournalLine> next = List<TCJournalLine>.of(form.lines);
    next[i] = next[i].copyWith(amount: amount < 0 ? 0 : amount);
    form.lines = next;
  }

  // ---- result -------------------------------------------------------------

  /// Builds the persisted voucher, auto-numbering when the field was left blank
  /// (jsx:9.1 `no: auto-generated if empty`).
  TCVoucher buildVoucher({required bool draft}) {
    final String kind = form.type;
    final String prefix = switch (kind) {
      TCKinds.sales => 'BILL',
      TCKinds.purchase => 'PBN',
      TCKinds.receipt => 'RCPT',
      TCKinds.payment => 'PAY',
      _ => 'JV',
    };
    final String no = form.no.trim().isNotEmpty
        ? form.no.trim()
        : '$prefix-${DateTime.now().millisecondsSinceEpoch % 10000}';
    return TCVoucher(
      id: draft ? '' : 'n${DateTime.now().millisecondsSinceEpoch}',
      kind: kind,
      no: no,
      party: form.party,
      amt: draft && form.items.isEmpty ? form.amtNum : form.total,
      date: form.date,
      due: kind == TCKinds.sales || kind == TCKinds.purchase ? form.ref : null,
      status: draft ? TCKinds.statusOk : TCKinds.statusWait,
      time: draft ? 'Saved on this phone' : 'Just now',
      ref: form.ref.isEmpty ? null : form.ref,
      note: form.note,
      mode: form.mode,
      acc: form.acc,
      bank: form.bank,
      items: form.items,
      lines: form.lines,
      paid: form.payNum,
      draft: draft,
      fresh: !draft,
    );
  }
}

final NotifierProvider<FlowEntryNotifier, FlowState> flowEntryProvider =
    NotifierProvider<FlowEntryNotifier, FlowState>(FlowEntryNotifier.new);

final Provider<List<TCItem>> itemsProvider = Provider<List<TCItem>>(
  (Ref ref) => ref.watch(repositoryProvider).items(),
);

final Provider<List<TCAccount>> accountsProvider = Provider<List<TCAccount>>(
  (Ref ref) => ref.watch(repositoryProvider).accounts(),
);

final Provider<List<TCLedger>> ledgersProvider = Provider<List<TCLedger>>(
  (Ref ref) => ref.watch(repositoryProvider).ledgers(),
);

/// Party pool filtered to the wizard's `list` side (c = customer, s = supplier).
final ProviderFamily<List<TCParty>, String> partyPoolProvider =
    Provider.family<List<TCParty>, String>(
      (Ref ref, String side) => ref
          .watch(repositoryProvider)
          .parties()
          .where(
            (TCParty p) => side == 's' ? p.isSupplier : p.isCustomer,
          )
          .toList(growable: false),
    );