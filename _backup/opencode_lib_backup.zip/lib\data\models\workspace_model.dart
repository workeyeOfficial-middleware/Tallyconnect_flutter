// Typed workspace model + the home page layout that hangs off it.
// `WS` (jsx:237-241) plus the `tc-liquid-pages-v2` layout persisted per
// workspace (jsx section 4).
library;

import '../../core/storage/local_storage.dart';

/// A home workspace: a named set of feature shortcuts + money cards.
class TCWorkspace {
  const TCWorkspace({
    required this.id,
    required this.name,
    this.builtin = false,
    this.feats = const <String>[],
    this.sums = const <String>[],
  });

  final String id;
  final String name;
  final bool builtin;
  final List<String> feats;
  final List<String> sums;

  /// 1:1 save guard - the prototype disables Save until both lists are filled
  /// (jsx:9.2).
  bool get isValid => name.trim().isNotEmpty && sums.isNotEmpty;

  int get shortcutCount => feats.length;

  /// `Shortcuts: sales, money in, party`
  String get shortcutsLabel => feats.join(', ');

  /// `Money cards: to get, sales`
  String get sumsLabel => sums.join(', ');

  factory TCWorkspace.fromMap(Map<String, dynamic> m) => TCWorkspace(
    id: (m['id'] ?? '') as String,
    name: (m['name'] ?? '') as String,
    builtin: (m['builtin'] ?? false) as bool,
    feats: ((m['feats'] as List<dynamic>?) ?? const <dynamic>[])
        .map((dynamic e) => e as String)
        .toList(growable: false),
    sums: ((m['sums'] as List<dynamic>?) ?? const <dynamic>[])
        .map((dynamic e) => e as String)
        .toList(growable: false),
  );

  Map<String, dynamic> toMap() => <String, dynamic>{
    'id': id,
    'name': name,
    'builtin': builtin,
    'feats': feats,
    'sums': sums,
  };
}

/// One swipeable home page: an ordered list of widget keys plus the widget the
/// user hid from it.
class TCHomePage {
  TCHomePage({List<String>? widgets, List<String>? hidden})
    : widgets = widgets ?? <String>[],
      hidden = hidden ?? <String>[];

  List<String> widgets;
  List<String> hidden;

  /// Pin moves the key to the top of page 0 (jsx:2.3 context menu).
  void pin(String key) {
    widgets.remove(key);
    hidden.remove(key);
    widgets.insert(0, key);
  }

  void unpin(String key) {
    if (!widgets.contains(key)) return;
    widgets.removeAt(0);
    final int i = widgets.indexOf(key);
    if (i > 0) widgets.add(widgets.removeAt(i));
  }

  void hide(String key) {
    widgets.remove(key);
    if (!hidden.contains(key)) hidden.add(key);
  }

  void restore(String key) {
    hidden.remove(key);
    if (!widgets.contains(key)) widgets.add(key);
  }

  TCHomePage copy() => TCHomePage(
    widgets: List<String>.of(widgets),
    hidden: List<String>.of(hidden),
  );

  factory TCHomePage.fromMap(Map<String, dynamic> m) => TCHomePage(
    widgets: ((m['widgets'] as List<dynamic>?) ?? const <dynamic>[])
        .map((dynamic e) => e as String)
        .toList(),
    hidden: ((m['hidden'] as List<dynamic>?) ?? const <dynamic>[])
        .map((dynamic e) => e as String)
        .toList(),
  );

  Map<String, dynamic> toMap() => <String, dynamic>{
    'widgets': widgets,
    'hidden': hidden,
  };
}

/// The full home layout for one workspace: pages + current page index.
class TCPageLayout {
  TCPageLayout({List<TCHomePage>? pages, this.pageIdx = 0})
    : pages = pages ?? <TCHomePage>[];

  List<TCHomePage> pages;
  int pageIdx;

  bool get hasMultiple => pages.length > 1;

  /// Widgets the user hid anywhere on this workspace - the `hidden_cards_sheet`
  /// source (jsx:2.19).
  List<String> get allHidden => <String>[
    for (final TCHomePage p in pages) ...p.hidden,
  ];

  void addPage() {
    pages.add(TCHomePage());
    pageIdx = pages.length - 1;
  }

  /// Refuses to drop the last page - the prototype always keeps page 1.
  bool removePage(int i) {
    if (pages.length <= 1 || i < 0 || i >= pages.length) return false;
    pages.removeAt(i);
    if (pageIdx >= pages.length) pageIdx = pages.length - 1;
    return true;
  }

  void clampPage() {
    if (pages.isEmpty) pages.add(TCHomePage());
    if (pageIdx < 0) pageIdx = 0;
    if (pageIdx >= pages.length) pageIdx = pages.length - 1;
  }

  Map<String, dynamic> toMap() => <String, dynamic>{
    'pages': pages.map((TCHomePage p) => p.toMap()).toList(growable: false),
    'pageIdx': pageIdx,
  };

  factory TCPageLayout.fromMap(Map<String, dynamic> m) {
    final List<dynamic> raw = (m['pages'] as List<dynamic>?) ?? const <dynamic>[];
    final TCPageLayout l = TCPageLayout(
      pages: raw
          .map((dynamic e) => TCHomePage.fromMap(e as Map<String, dynamic>))
          .toList(),
      pageIdx: (m['pageIdx'] as num?)?.toInt() ?? 0,
    );
    l.clampPage();
    return l;
  }
}

/// Default two-page layout for a fresh `def` workspace (jsx:753-757).
TCPageLayout tcDefaultLayout({
  required List<String> pageOne,
  required List<String> pageTwo,
}) => TCPageLayout(
  pages: <TCHomePage>[
    TCHomePage(widgets: List<String>.of(pageOne)),
    TCHomePage(widgets: List<String>.of(pageTwo)),
  ],
);

/// Reads / writes the page layout for a workspace through [LocalStorage].
extension TCWorkspaceLayoutStore on LocalStorage {
  TCPageLayout readPages(String wsId) {
    final Map<String, dynamic>? raw = readJsonMap(LocalStorage.kPages(wsId));
    if (raw == null) return TCPageLayout(pages: <TCHomePage>[TCHomePage()]);
    return TCPageLayout.fromMap(raw);
  }

  void writePages(String wsId, TCPageLayout layout) =>
      writeJson(LocalStorage.kPages(wsId), layout.toMap());
}