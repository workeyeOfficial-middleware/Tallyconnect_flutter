// Mock datasets transcribed verbatim from
// prototype/TallyConnect_App_Source.jsx (lines 79-257).
//
// These are the *only* data the Batch 1 screens may show. No fabrication.

class TCMockData {
  TCMockData._();

  // ------------------------------------------------------------------ nav ---
  // TABS (jsx:79)
  static const List<Map<String, String>> tabs = <Map<String, String>>[
    <String, String>{'k': 'home', 't': 'Home', 'ic': 'home'},
    <String, String>{'k': 'outHub', 't': 'Dues', 'ic': 'rupeeC'},
    <String, String>{'k': 'team', 't': 'Team', 'ic': 'team'},
    <String, String>{'k': 'activity', 't': 'Activity', 'ic': 'activity'},
    <String, String>{'k': 'reports', 't': 'Reports', 'ic': 'chart'},
  ];

  /// NO_TAB (jsx:80) - screens without the bottom bar.
  static const List<String> noTab = <String>[
    'login',
    'forgot',
    'flow',
    'createWs',
    'manageWs',
    'billDetail',
    'partyDetail',
    'actDetail',
    'entryDetail',
    'newEntry',
  ];

  /// FLOWLIKE (jsx:81) - screens styled as a full-height flow.
  static const List<String> flowLike = <String>[
    'flow',
    'createWs',
    'manageWs',
    'billDetail',
    'partyDetail',
    'entryDetail',
  ];

  /// TITLES (jsx:82)
  static const Map<String, String> titles = <String, String>{
    'home': 'Home',
    'notifs': 'Alerts',
    'createWs': 'Workspace',
    'manageWs': 'Workspaces',
    'newEntry': 'New Entry',
    'flow': 'Entry',
    'vHub': 'Vouchers',
    'vList': 'Vouchers',
    'entryDetail': 'Entry',
    'outHub': 'Dues',
    'outList': 'Dues',
    'billDetail': 'Bill',
    'items': 'Items',
    'party': 'Party',
    'partyDetail': 'Party',
    'reports': 'Reports',
    'report': 'Reports',
    'activity': 'Activity',
    'actDetail': 'Activity',
    'team': 'Team',
    'settings': 'Settings',
    'companies': 'Companies',
    'billing': 'Plans',
    'refer': 'Refer',
    'help': 'Help',
    'login': 'Log in',
    'forgot': 'Log in',
  };

  // ------------------------------------------------------------- features ---
  // T (jsx:84-95). `c` is a semantic palette key resolved by TCTheme.
  static const Map<String, Map<String, String>> features =
      <String, Map<String, String>>{
        'items': <String, String>{
          't': 'Items',
          's': 'Stock',
          'ic': 'box',
          'c': 'items',
          'to': 'items',
        },
        'party': <String, String>{
          't': 'Party',
          's': 'Customers',
          'ic': 'person',
          'c': 'party',
          'to': 'party',
        },
        'vouchers': <String, String>{
          't': 'Vouchers',
          's': 'All entries',
          'ic': 'receipt',
          'c': 'vouchers',
          'to': 'vHub',
        },
        'outstanding': <String, String>{
          't': 'Outstanding',
          's': 'Money due',
          'ic': 'rupeeC',
          'c': 'outstanding',
          'to': 'outHub',
        },
        'reports': <String, String>{
          't': 'Reports',
          's': 'Insights',
          'ic': 'chart',
          'c': 'reports',
          'to': 'reports',
        },
        'settings': <String, String>{
          't': 'Settings',
          's': 'App setup',
          'ic': 'gear',
          'c': 'settings',
          'to': 'settings',
        },
        'sales': <String, String>{
          't': 'Sales',
          's': 'New sale',
          'ic': 'bag',
          'c': 'sales',
          'flow': 'sales',
        },
        'purchase': <String, String>{
          't': 'Purchase',
          's': 'New purchase',
          'ic': 'cart',
          'c': 'purchase',
          'flow': 'purchase',
        },
        'moneyIn': <String, String>{
          't': 'Money In',
          's': 'Receipt',
          'ic': 'in',
          'c': 'receipt',
          'flow': 'receipt',
        },
        'moneyOut': <String, String>{
          't': 'Money Out',
          's': 'Payment',
          'ic': 'out',
          'c': 'payment',
          'flow': 'payment',
        },
      };

  // ------------------------------------------------------------ metric KPI ---
  // SUMS (jsx:96-105)
  static const Map<String, Map<String, dynamic>> sums =
      <String, Map<String, dynamic>>{
        'toGet': <String, dynamic>{
          't': 'To get',
          's': 'Others owe you',
          'v': 348690,
          'ic': 'in',
          'c': 'receipt',
          'cls': 'amt in',
        },
        'toGive': <String, dynamic>{
          't': 'To give',
          's': 'You owe others',
          'v': 126850,
          'ic': 'out',
          'c': 'payment',
          'cls': 'amt out',
        },
        'mIn': <String, dynamic>{
          't': 'Money in',
          's': 'This month',
          'v': 215000,
          'ic': 'in',
          'c': 'receipt',
          'cls': 'amt',
        },
        'mOut': <String, dynamic>{
          't': 'Money out',
          's': 'This month',
          'v': 98450,
          'ic': 'out',
          'c': 'payment',
          'cls': 'amt',
        },
        'sales': <String, dynamic>{
          't': 'Total sales',
          's': 'This month',
          'v': 348690,
          'ic': 'bag',
          'c': 'sales',
          'cls': 'amt',
        },
        'purch': <String, dynamic>{
          't': 'Total purchase',
          's': 'This month',
          'v': 126850,
          'ic': 'cart',
          'c': 'purchase',
          'cls': 'amt',
        },
        'cash': <String, dynamic>{
          't': 'Cash in hand',
          's': 'Cash balance',
          'v': 42300,
          'ic': 'cash',
          'c': 'navy',
          'cls': 'amt',
        },
        'bank': <String, dynamic>{
          't': 'Bank balance',
          's': 'All banks',
          'v': 386900,
          'ic': 'bank',
          'c': 'navy',
          'cls': 'amt',
        },
      };

  // --------------------------------------------------------- voucher kinds ---
  // KIND (jsx:106-113)
  static const Map<String, Map<String, dynamic>> kinds =
      <String, Map<String, dynamic>>{
        'sales': <String, dynamic>{
          't': 'Sale',
          'long': 'Sale (Sales)',
          'ic': 'bag',
          'c': 'sales',
          'sign': 1,
        },
        'purchase': <String, dynamic>{
          't': 'Purchase',
          'long': 'Purchase',
          'ic': 'cart',
          'c': 'purchase',
          'sign': -1,
        },
        'receipt': <String, dynamic>{
          't': 'Money In',
          'long': 'Money In (Receipt)',
          'ic': 'in',
          'c': 'receipt',
          'sign': 1,
        },
        'payment': <String, dynamic>{
          't': 'Money Out',
          'long': 'Money Out (Payment)',
          'ic': 'out',
          'c': 'payment',
          'sign': -1,
        },
        'journal': <String, dynamic>{
          't': 'Adjustment',
          'long': 'Adjustment (Journal)',
          'ic': 'book',
          'c': 'journal',
          'sign': 0,
        },
        'contra': <String, dynamic>{
          't': 'Bank ↔ Cash',
          'long': 'Bank ↔ Cash (Contra)',
          'ic': 'swap',
          'c': 'contra',
          'sign': 0,
        },
      };

  // ------------------------------------------------------------- vouchers ---
  // VOUCH (jsx:114-136)
  static const List<Map<String, dynamic>> vouchers = <Map<String, dynamic>>[
    <String, dynamic>{
      'kind': 'sales',
      'party': 'Mehta Electricals',
      'no': 'Sales 10',
      'day': 24,
      'amt': 84960,
    },
    <String, dynamic>{
      'kind': 'sales',
      'party': 'Shree Balaji Traders',
      'no': 'Sales 9',
      'day': 21,
      'amt': 112100,
    },
    <String, dynamic>{
      'kind': 'sales',
      'party': 'Om Sai Electricals',
      'no': 'Sales 8',
      'day': 17,
      'amt': 12980,
    },
    <String, dynamic>{
      'kind': 'sales',
      'party': 'Patel Traders',
      'no': 'Sales 7',
      'day': 12,
      'amt': 24780,
    },
    <String, dynamic>{
      'kind': 'sales',
      'party': 'Gupta Hardware Stores',
      'no': 'Sales 6',
      'day': 8,
      'amt': 68440,
    },
    <String, dynamic>{
      'kind': 'sales',
      'party': 'Sai Enterprises',
      'no': 'Sales 5',
      'day': 3,
      'amt': 45430,
    },
    <String, dynamic>{
      'kind': 'purchase',
      'party': 'Kiran Steel Industries',
      'no': 'PI-0005',
      'day': 23,
      'amt': 48380,
    },
    <String, dynamic>{
      'kind': 'purchase',
      'party': 'Havells India Ltd',
      'no': 'PI-0004',
      'day': 19,
      'amt': 36580,
    },
    <String, dynamic>{
      'kind': 'purchase',
      'party': 'Polycab Wires Pvt Ltd',
      'no': 'PI-0003',
      'day': 14,
      'amt': 24190,
    },
    <String, dynamic>{
      'kind': 'purchase',
      'party': 'Anchor Electricals',
      'no': 'PI-0002',
      'day': 9,
      'amt': 11800,
    },
    <String, dynamic>{
      'kind': 'purchase',
      'party': 'Finolex Cables',
      'no': 'PI-0001',
      'day': 2,
      'amt': 5900,
    },
    <String, dynamic>{
      'kind': 'receipt',
      'party': 'Mehta Electricals',
      'no': 'RCT-0003',
      'day': 26,
      'amt': 25000,
    },
    <String, dynamic>{
      'kind': 'receipt',
      'party': 'Gupta Hardware Stores',
      'no': 'RCT-0002',
      'day': 18,
      'amt': 125000,
    },
    <String, dynamic>{
      'kind': 'receipt',
      'party': 'Patel Traders',
      'no': 'RCT-0001',
      'day': 5,
      'amt': 65000,
    },
    <String, dynamic>{
      'kind': 'payment',
      'party': 'Kiran Steel Industries',
      'no': 'PAY-0003',
      'day': 22,
      'amt': 52000,
    },
    <String, dynamic>{
      'kind': 'payment',
      'party': 'Havells India Ltd',
      'no': 'PAY-0002',
      'day': 15,
      'amt': 38000,
    },
    <String, dynamic>{
      'kind': 'payment',
      'party': 'Mahalaxmi Transport',
      'no': 'PAY-0001',
      'day': 3,
      'amt': 8450,
    },
    <String, dynamic>{
      'kind': 'journal',
      'party': 'Depreciation A/c',
      'no': 'JV-0002',
      'day': 25,
      'amt': 24500,
    },
    <String, dynamic>{
      'kind': 'journal',
      'party': 'Rent A/c',
      'no': 'JV-0001',
      'day': 10,
      'amt': 35000,
    },
    <String, dynamic>{
      'kind': 'contra',
      'party': 'Cash → HDFC Bank',
      'no': 'CN-0002',
      'day': 20,
      'amt': 50000,
    },
    <String, dynamic>{
      'kind': 'contra',
      'party': 'ICICI Bank → Cash',
      'no': 'CN-0001',
      'day': 6,
      'amt': 20000,
    },
  ];

  // ------------------------------------------------------------ receivables ---
  // RECV (jsx:137-144)
  static const List<Map<String, dynamic>> receivables = <Map<String, dynamic>>[
    <String, dynamic>{
      'party': 'Shree Balaji Traders',
      'no': 'Sales 9',
      'bill': '21 Sep 2026',
      'due': '06 Oct 2026',
      'credit': '15 days',
      'amt': 112100,
      'st': 'ok',
      'txt': 'Due in 10 days',
      'city': 'Mumbai',
    },
    <String, dynamic>{
      'party': 'Mehta Electricals',
      'no': 'Sales 10',
      'bill': '24 Sep 2026',
      'due': '24 Oct 2026',
      'credit': '30 days',
      'amt': 84960,
      'st': 'ok',
      'txt': 'Due in 28 days',
      'city': 'Pune',
    },
    <String, dynamic>{
      'party': 'Gupta Hardware Stores',
      'no': 'Sales 6',
      'bill': '08 Sep 2026',
      'due': '14 Sep 2026',
      'credit': '6 days',
      'amt': 68440,
      'st': 'late',
      'txt': '12 days late',
      'city': 'Jaipur',
    },
    <String, dynamic>{
      'party': 'Sai Enterprises',
      'no': 'Sales 5',
      'bill': '03 Sep 2026',
      'due': '08 Sep 2026',
      'credit': '5 days',
      'amt': 45430,
      'st': 'late',
      'txt': '18 days late',
      'city': 'Nashik',
    },
    <String, dynamic>{
      'party': 'Patel Traders',
      'no': 'Sales 7',
      'bill': '12 Sep 2026',
      'due': '27 Sep 2026',
      'credit': '15 days',
      'amt': 24780,
      'st': 'soon',
      'txt': 'Due tomorrow',
      'city': 'Surat',
    },
    <String, dynamic>{
      'party': 'Om Sai Electricals',
      'no': 'Sales 8',
      'bill': '17 Sep 2026',
      'due': '02 Oct 2026',
      'credit': '15 days',
      'amt': 12980,
      'st': 'soon',
      'txt': 'Due in 6 days',
      'city': 'Thane',
    },
  ];

  // --------------------------------------------------------------- payables ---
  // PAYB (jsx:145-151)
  static const List<Map<String, dynamic>> payables = <Map<String, dynamic>>[
    <String, dynamic>{
      'party': 'Kiran Steel Industries',
      'no': 'PI-0005',
      'bill': '23 Sep 2026',
      'due': '29 Sep 2026',
      'credit': '6 days',
      'amt': 48380,
      'st': 'soon',
      'txt': 'Due in 3 days',
      'city': 'Ludhiana',
    },
    <String, dynamic>{
      'party': 'Havells India Ltd',
      'no': 'PI-0004',
      'bill': '19 Sep 2026',
      'due': '19 Oct 2026',
      'credit': '30 days',
      'amt': 36580,
      'st': 'ok',
      'txt': 'Due in 23 days',
      'city': 'Noida',
    },
    <String, dynamic>{
      'party': 'Polycab Wires Pvt Ltd',
      'no': 'PI-0003',
      'bill': '14 Sep 2026',
      'due': '30 Sep 2026',
      'credit': '16 days',
      'amt': 24190,
      'st': 'soon',
      'txt': 'Due in 4 days',
      'city': 'Mumbai',
    },
    <String, dynamic>{
      'party': 'Anchor Electricals',
      'no': 'PI-0002',
      'bill': '09 Sep 2026',
      'due': '21 Sep 2026',
      'credit': '12 days',
      'amt': 11800,
      'st': 'late',
      'txt': '5 days late',
      'city': 'Mumbai',
    },
    <String, dynamic>{
      'party': 'Finolex Cables',
      'no': 'PI-0001',
      'bill': '02 Sep 2026',
      'due': '16 Sep 2026',
      'credit': '14 days',
      'amt': 5900,
      'st': 'late',
      'txt': '10 days late',
      'city': 'Pune',
    },
  ];

  // ---------------------------------------------------------------- parties ---
  // PARTIES (jsx:152-167)
  static const List<Map<String, dynamic>> parties = <Map<String, dynamic>>[
    <String, dynamic>{
      'name': 'Shree Balaji Traders',
      'type': 'c',
      'city': 'Mumbai',
      'bal': 112100,
    },
    <String, dynamic>{
      'name': 'Mehta Electricals',
      'type': 'c',
      'city': 'Pune',
      'bal': 84960,
    },
    <String, dynamic>{
      'name': 'Gupta Hardware Stores',
      'type': 'c',
      'city': 'Jaipur',
      'bal': 68440,
    },
    <String, dynamic>{
      'name': 'Kiran Steel Industries',
      'type': 's',
      'city': 'Ludhiana',
      'bal': 48380,
    },
    <String, dynamic>{
      'name': 'Sai Enterprises',
      'type': 'c',
      'city': 'Nashik',
      'bal': 45430,
    },
    <String, dynamic>{
      'name': 'Havells India Ltd',
      'type': 's',
      'city': 'Noida',
      'bal': 36580,
    },
    <String, dynamic>{
      'name': 'Patel Traders',
      'type': 'c',
      'city': 'Surat',
      'bal': 24780,
    },
    <String, dynamic>{
      'name': 'Polycab Wires Pvt Ltd',
      'type': 's',
      'city': 'Mumbai',
      'bal': 24190,
    },
    <String, dynamic>{
      'name': 'Om Sai Electricals',
      'type': 'c',
      'city': 'Thane',
      'bal': 12980,
    },
    <String, dynamic>{
      'name': 'Anchor Electricals',
      'type': 's',
      'city': 'Mumbai',
      'bal': 11800,
    },
    <String, dynamic>{
      'name': 'Finolex Cables',
      'type': 's',
      'city': 'Pune',
      'bal': 5900,
    },
    <String, dynamic>{
      'name': 'Mahalaxmi Transport',
      'type': 's',
      'city': 'Mumbai',
      'bal': 0,
    },
    <String, dynamic>{
      'name': 'Rajesh Hardware',
      'type': 'c',
      'city': 'Mumbai',
      'bal': 0,
    },
    <String, dynamic>{
      'name': 'Laxmi Traders',
      'type': 'c',
      'city': 'Vapi',
      'bal': 0,
    },
  ];

  // ------------------------------------------------------------------ items ---
  // ITEMS (jsx:168-177)
  static const List<Map<String, dynamic>> items = <Map<String, dynamic>>[
    <String, dynamic>{
      'name': 'Havells FR Wire 1.5 sq mm (90 m)',
      'stock': 48,
      'unit': 'coil',
      'rate': 1850,
      'st': 'ok',
    },
    <String, dynamic>{
      'name': 'Polycab FR Wire 1.0 sq mm (90 m)',
      'stock': 36,
      'unit': 'coil',
      'rate': 1600,
      'st': 'ok',
    },
    <String, dynamic>{
      'name': 'Polycab LED Panel 18W',
      'stock': 120,
      'unit': 'pcs',
      'rate': 520,
      'st': 'ok',
    },
    <String, dynamic>{
      'name': 'Anchor Roma Switch 6A',
      'stock': 850,
      'unit': 'pcs',
      'rate': 34,
      'st': 'ok',
    },
    <String, dynamic>{
      'name': 'Havells MCB 32A DP',
      'stock': 8,
      'unit': 'pcs',
      'rate': 620,
      'st': 'low',
    },
    <String, dynamic>{
      'name': 'Crompton Ceiling Fan 1200 mm',
      'stock': 1,
      'unit': 'pcs',
      'rate': 3100,
      'st': 'low',
    },
    <String, dynamic>{
      'name': 'Supreme PVC Pipe 1 inch',
      'stock': 0,
      'unit': 'pcs',
      'rate': 85,
      'st': 'out',
    },
    <String, dynamic>{
      'name': 'Anchor Roma Socket 16A',
      'stock': 0,
      'unit': 'pcs',
      'rate': 96,
      'st': 'out',
    },
  ];

  /// Line items of "Sales 9" - SALES9 (jsx:178-182)
  static const List<Map<String, dynamic>> sales9Lines = <Map<String, dynamic>>[
    <String, dynamic>{
      'name': 'Polycab FR Wire 1.0 sq mm (90 m)',
      'hsn': '8544',
      'qty': '30 coil',
      'rate': '₹1,600',
      'amt': 48000,
    },
    <String, dynamic>{
      'name': 'Havells MCB 32A DP',
      'hsn': '8536',
      'qty': '40 pcs',
      'rate': '₹620',
      'amt': 24800,
    },
    <String, dynamic>{
      'name': 'Polycab LED Panel 18W',
      'hsn': '9405',
      'qty': '42 pcs',
      'rate': '₹528.57',
      'amt': 22200,
    },
  ];

  // ---------------------------------------------------------------- ledgers ---
  // LEDGERS (jsx:183-186)
  static const List<Map<String, String>> ledgers = <Map<String, String>>[
    <String, String>{'t': 'Salaries A/c', 's': 'Indirect Expenses'},
    <String, String>{'t': 'Salary Payable', 's': 'Current Liabilities'},
    <String, String>{'t': 'Rent A/c', 's': 'Indirect Expenses'},
    <String, String>{'t': 'Depreciation A/c', 's': 'Indirect Expenses'},
    <String, String>{'t': 'Office Expenses A/c', 's': 'Indirect Expenses'},
    <String, String>{'t': 'Freight Charges', 's': 'Direct Expenses'},
  ];

  // --------------------------------------------------------------- accounts ---
  // ACCOUNTS (jsx:187)
  static const List<Map<String, String>> accounts = <Map<String, String>>[
    <String, String>{'t': 'HDFC Bank – Current', 's': 'Bank account'},
    <String, String>{'t': 'ICICI Bank – Current', 's': 'Bank account'},
    <String, String>{'t': 'Cash in hand', 's': 'Cash'},
  ];

  // --------------------------------------------------------------- companies ---
  // COMPANIES (jsx:188-192)
  static const List<Map<String, String>> companies = <Map<String, String>>[
    <String, String>{
      'id': 'rs',
      'name': 'Rajlaxmi Solutions Private Limited - (From 1-Apr-2016)',
      'sub': 'Tally company · synced yesterday',
    },
    <String, String>{
      'id': 'gi',
      'name': 'GI Apr 25-26',
      'sub': 'Tally company · synced 10:32 AM',
    },
    <String, String>{
      'id': 'av',
      'name': 'Averlon3',
      'sub': 'Tally company · synced 22 Sep',
    },
  ];

  // -------------------------------------------------------------- flow types ---
  // FT (jsx:193-199)
  static const Map<String, Map<String, dynamic>> flowTypes =
      <String, Map<String, dynamic>>{
        'sales': <String, dynamic>{
          'title': 'New Sale',
          'sub': 'Sales bill',
          'ic': 'bag',
          'c': 'sales',
          'steps': <String>['Details', 'Items', 'Payment', 'Check'],
          'p': 's',
          'partyLabel': 'Customer',
          'list': 'c',
          'items': true,
          'noLabel': 'Bill no.',
          'amtLabel': 'Money received now',
          'balLabel': 'Still to get',
          'draft': true,
        },
        'purchase': <String, dynamic>{
          'title': 'New Purchase',
          'sub': 'Purchase bill',
          'ic': 'cart',
          'c': 'purchase',
          'steps': <String>['Details', 'Items', 'Payment', 'Check'],
          'p': 'p',
          'partyLabel': 'Supplier (you bought from)',
          'list': 's',
          'items': true,
          'noLabel': 'Bill no.',
          'amtLabel': 'Money paid now',
          'balLabel': 'Still to pay',
          'draft': true,
        },
        'receipt': <String, dynamic>{
          'title': 'Money In',
          'sub': 'Receipt',
          'ic': 'in',
          'c': 'receipt',
          'steps': <String>['Details', 'How paid', 'Check'],
          'p': 'r',
          'partyLabel': 'Received from',
          'list': 'c',
          'noLabel': 'Receipt no.',
          'amtLabel': 'Amount received',
          'accLabel': 'Put money into',
        },
        'payment': <String, dynamic>{
          'title': 'Money Out',
          'sub': 'Payment',
          'ic': 'out',
          'c': 'payment',
          'steps': <String>['Details', 'How paid', 'Check'],
          'p': 'y',
          'partyLabel': 'Paid to',
          'list': 's',
          'noLabel': 'Payment no.',
          'amtLabel': 'Amount paid',
          'accLabel': 'Paid from',
        },
        'journal': <String, dynamic>{
          'title': 'Adjustment',
          'sub': 'Journal entry',
          'ic': 'book',
          'c': 'journal',
          'steps': <String>['Details', 'Accounts', 'Check'],
          'p': 'j',
          'partyLabel': 'Main account',
          'noLabel': 'Entry no.',
        },
      };

  // MODES (jsx:200)
  static const List<Map<String, String>> payModes = <Map<String, String>>[
    <String, String>{'id': 'cash', 't': 'Cash', 'ic': 'cash'},
    <String, String>{'id': 'bank', 't': 'Bank', 'ic': 'bank'},
    <String, String>{'id': 'upi', 't': 'UPI', 'ic': 'upi'},
    <String, String>{'id': 'cheque', 't': 'Cheque', 'ic': 'cheque'},
    <String, String>{'id': 'other', 't': 'Other', 'ic': 'more'},
  ];

  /// Prefilled form values - FORM (jsx:201-210)
  static const Map<String, String> form = <String, String>{
    'user': '',
    'pass': '',
    'fEmail': '',
    'q': '',
    'pq': '',
    'pickQ': '',
    'itemQ': '',
    'partyQ': '',
    'teamQ': '',
    'wsName': '',
    'sNo': '11',
    'sDate': '2026-09-26',
    'sParty': 'Om Sai Electricals',
    'sDue': '2026-10-11',
    'sNote': 'Order by phone – deliver today',
    'sAmt': '5000',
    'sPayNote': 'Balance on 15-day credit',
    'pNo': 'PI-0006',
    'pDate': '2026-09-26',
    'pParty': 'Polycab Wires Pvt Ltd',
    'pSupInv': 'PWPL/2627/0891',
    'pDue': '2026-10-11',
    'pNote': 'Monthly stock refill',
    'pAmt': '14160',
    'pPayNote': 'Paid in full',
    'rNo': 'RCT-0004',
    'rDate': '2026-09-26',
    'rParty': 'Shree Balaji Traders',
    'rAmt': '50000',
    'rRef': 'Against Sales 9',
    'rNote': 'Part payment by NEFT',
    'rBank': 'HDFC Bank',
    'rUtr': 'NEFT UTR HDFCN26269123',
    'rAcc': 'HDFC Bank – Current',
    'yNo': 'PAY-0004',
    'yDate': '2026-09-26',
    'yParty': 'Havells India Ltd',
    'yAmt': '36580',
    'yRef': 'Against PI-0004',
    'yNote': 'Full payment for MCB order',
    'yBank': 'ICICI Bank',
    'yUtr': 'RTGS ICICR52026092600417',
    'yAcc': 'ICICI Bank – Current',
    'jNo': 'JV-0003',
    'jDate': '2026-09-26',
    'jParty': 'Salaries A/c',
    'jNote': 'Salary provision for September 2026',
    'niName': 'Supreme PVC Pipe 1 inch',
    'niHsn': '',
    'niDisc': '0',
    'niQty': '1',
    'niRate': '',
    'iEmail': '',
    'nuName': '',
    'nuPhone': '',
    'npName': '',
    'npPhone': '',
    'npCity': '',
  };

  // ---------------------------------------------------------- notifications ---
  // NOTIFS (jsx:211-218)
  static const List<Map<String, dynamic>> notifications =
      <Map<String, dynamic>>[
        <String, dynamic>{
          'id': 'n1',
          't': 'Payment received',
          'b': '₹25,000 from Mehta Electricals was saved as Money In RCT-0003.',
          'time': '10 min ago',
          'ic': 'in',
          'c': 'receipt',
          'unread': true,
          'go': <dynamic>[
            'vList',
            <String, String>{'vFilter': 'receipt', 'vPeriod': 'month'},
          ],
        },
        <String, dynamic>{
          'id': 'n2',
          't': 'Sent to Tally',
          'b': '12 entries from the app reached Tally for GI Apr 25-26.',
          'time': '1 hr ago',
          'ic': 'sync',
          'c': 'activity',
          'unread': true,
          'go': 'activity',
        },
        <String, dynamic>{
          'id': 'n3',
          't': 'Invite accepted',
          'b': 'Priya Shah joined your sales team.',
          'time': 'Yesterday',
          'ic': 'team',
          'c': 'team',
          'unread': true,
          'go': 'team',
        },
        <String, dynamic>{
          'id': 'n4',
          't': 'Payment due soon',
          'b': '₹48,380 to Kiran Steel Industries is due on 29 Sep.',
          'time': 'Yesterday',
          'ic': 'out',
          'c': 'payment',
          'unread': false,
          'go': <dynamic>[
            'outList',
            <String, String>{'outKind': 'pay', 'outFilter': 'all'},
          ],
        },
        <String, dynamic>{
          'id': 'n5',
          't': 'New join request',
          'b': 'Sunita Rao asked to join your team as Sales Rep.',
          'time': '23 Sep',
          'ic': 'userPlus',
          'c': 'party',
          'unread': false,
          'go': 'team',
        },
        <String, dynamic>{
          'id': 'n6',
          't': 'Plan renewal',
          'b': 'Your Enterprise plan renews on 31 Mar 2027.',
          'time': '20 Sep',
          'ic': 'card',
          'c': 'acc',
          'unread': false,
          'go': 'billing',
        },
      ];

  // ------------------------------------------------------------- activities ---
  // ACTS (jsx:219-230)
  static const List<Map<String, dynamic>> activities = <Map<String, dynamic>>[
    <String, dynamic>{
      'id': 'a1',
      'kind': 'receipt',
      'no': 'RCT-0004',
      'party': 'Shree Balaji Traders',
      'amt': 50000,
      'time': '11:05 AM',
      'status': 'fail',
      'note': 'Tally was closed on RAJESH-PC',
    },
    <String, dynamic>{
      'id': 'a2',
      'kind': 'sales',
      'no': 'Sales 11',
      'party': 'Om Sai Electricals',
      'amt': 14514,
      'time': '10:58 AM',
      'status': 'wait',
    },
    <String, dynamic>{
      'id': 'a3',
      'kind': 'purchase',
      'no': 'PI-0006',
      'party': 'Polycab Wires Pvt Ltd',
      'amt': 14160,
      'time': '10:51 AM',
      'status': 'wait',
    },
    <String, dynamic>{
      'id': 'a4',
      'kind': 'receipt',
      'no': 'RCT-0003',
      'party': 'Mehta Electricals',
      'amt': 25000,
      'time': '10:32 AM',
      'status': 'ok',
    },
    <String, dynamic>{
      'id': 'a5',
      'kind': 'journal',
      'no': 'JV-0002',
      'party': 'Depreciation A/c',
      'amt': 24500,
      'time': '25 Sep',
      'status': 'ok',
    },
    <String, dynamic>{
      'id': 'a6',
      'kind': 'sales',
      'no': 'Sales 10',
      'party': 'Mehta Electricals',
      'amt': 84960,
      'time': '24 Sep',
      'status': 'ok',
    },
    <String, dynamic>{
      'id': 'a7',
      'kind': 'purchase',
      'no': 'PI-0005',
      'party': 'Kiran Steel Industries',
      'amt': 48380,
      'time': '23 Sep',
      'status': 'ok',
    },
    <String, dynamic>{
      'id': 'a8',
      'kind': 'payment',
      'no': 'PAY-0003',
      'party': 'Kiran Steel Industries',
      'amt': 52000,
      'time': '22 Sep',
      'status': 'ok',
    },
    <String, dynamic>{
      'id': 'a9',
      'kind': 'sales',
      'no': 'Sales 9',
      'party': 'Shree Balaji Traders',
      'amt': 112100,
      'time': '21 Sep',
      'status': 'ok',
    },
    <String, dynamic>{
      'id': 'a10',
      'kind': 'contra',
      'no': 'CN-0002',
      'party': 'Cash → HDFC Bank',
      'amt': 50000,
      'time': '20 Sep',
      'status': 'ok',
    },
  ];

  // ------------------------------------------------------------------- team ---
  // TEAM (jsx:231-236)
  static const List<Map<String, dynamic>> team = <Map<String, dynamic>>[
    <String, dynamic>{
      'id': 't1',
      'name': 'workk72002',
      'email': 'workk72002@gmail.com',
      'role': 'Sales Rep · Mumbai',
      'st': 'active',
    },
    <String, dynamic>{
      'id': 't2',
      'name': 'Priya Shah',
      'email': 'priya.shah@example.com',
      'role': 'Sales Rep · Pune',
      'st': 'active',
    },
    <String, dynamic>{
      'id': 't3',
      'name': 'Sunita Rao',
      'email': 'sunita.rao@example.com',
      'role': 'Sales Rep',
      'st': 'pending',
    },
    <String, dynamic>{
      'id': 't4',
      'name': 'Amit Verma',
      'email': 'amit.verma@example.com',
      'role': 'Sales Rep · Jaipur',
      'st': 'off',
    },
  ];

  // -------------------------------------------------------------- workspaces ---
  // WS (jsx:237-241)
  static const List<Map<String, dynamic>> workspaces = <Map<String, dynamic>>[
    <String, dynamic>{
      'id': 'def',
      'name': 'Default Home',
      'builtin': true,
      'feats': <String>[
        'items',
        'party',
        'vouchers',
        'outstanding',
        'reports',
        'settings',
      ],
      'sums': <String>['toGet', 'toGive', 'mIn', 'mOut'],
    },
    <String, dynamic>{
      'id': 'sd',
      'name': 'Sales Desk',
      'feats': <String>[
        'sales',
        'moneyIn',
        'party',
        'vouchers',
        'outstanding',
        'reports',
      ],
      'sums': <String>['toGet', 'sales', 'mIn', 'cash'],
    },
    <String, dynamic>{
      'id': 'me',
      'name': 'Month-end Closing',
      'feats': <String>[
        'moneyOut',
        'purchase',
        'vouchers',
        'outstanding',
        'reports',
        'settings',
      ],
      'sums': <String>['cash', 'bank', 'toGive', 'mOut'],
    },
  ];

  /// Home page 1 for the `def` workspace - derived from WS[0].feats, matching
  /// the prototype's default page layout (jsx:753-757 newEntry + feats).
  static List<String> defaultPageOne() => <String>[
    'newEntry',
    ...(workspaces[0]['feats'] as List<String>),
  ];

  /// Everything that lands on page 2 for `def`.
  static List<String> defaultPageTwo() => const <String>['team', 'activity'];

  // ------------------------------------------------------------------- FAQs ---
  // FAQS (jsx:242-247)
  static const List<Map<String, String>> faqs = <Map<String, String>>[
    <String, String>{
      'q': 'What is TallyConnect?',
      'a':
          'TallyConnect is a mobile and web app that connects with your Tally ERP 9 / TallyPrime. Business owners, sales people and accountants can see reports, check party balances, look at stock and make entries from the phone.',
    },
    <String, String>{
      'q': 'How do entries reach Tally?',
      'a':
          'The TallyConnect app on your office computer sends new entries to Tally and brings back updates by itself, whenever Tally is open. You can see each entry in Activity.',
    },
    <String, String>{
      'q': 'Is my data safe?',
      'a':
          'Only people you add to your team can see your company data. [Add your security and data-storage details here.]',
    },
    <String, String>{
      'q': 'Can I use more than one company?',
      'a':
          'Yes. Tap the company name at the top of Home and pick another company.',
    },
  ];

  // ---------------------------------------------------------------- reports ---
  // REPORTS (jsx:248-257)
  static const List<Map<String, dynamic>> reports = <Map<String, dynamic>>[
    <String, dynamic>{
      'id': 'top',
      'cat': 'sales',
      't': 'Top customers',
      's': 'Top 5 by money owed',
      'ic': 'trophy',
      'c': 'acc',
    },
    <String, dynamic>{
      'id': 'exp',
      'cat': 'accounts',
      't': 'Expenses',
      's': 'Direct and indirect',
      'ic': 'pie',
      'c': 'payment',
    },
    <String, dynamic>{
      'id': 'inC',
      'cat': 'party',
      't': 'Quiet customers',
      's': 'No sale in 60 days',
      'ic': 'person',
      'c': 'party',
    },
    <String, dynamic>{
      'id': 'inI',
      'cat': 'stock',
      't': 'Items not moving',
      's': 'Finished or not sold',
      'ic': 'box',
      'c': 'items',
    },
    <String, dynamic>{
      'id': 'day',
      'cat': 'accounts',
      't': 'Day Book',
      's': 'Every entry, day by day',
      'ic': 'calendar',
      'c': 'navy',
    },
    <String, dynamic>{
      'id': 'sreg',
      'cat': 'sales',
      't': 'Sales list',
      's': 'All sales this month',
      'ic': 'bag',
      'c': 'sales',
    },
    <String, dynamic>{
      'id': 'preg',
      'cat': 'accounts',
      't': 'Purchase list',
      's': 'All purchases this month',
      'ic': 'cart',
      'c': 'purchase',
    },
    <String, dynamic>{
      'id': 'stock',
      'cat': 'stock',
      't': 'Stock summary',
      's': 'Value of all items',
      'ic': 'box',
      'c': 'items',
    },
  ];

  /// Receivables/Payables "soon" cards on the Dues hub (jsx:917).
  static List<Map<String, dynamic>> dueSoon() {
    final Map<String, dynamic>? r4 = receivables.length > 4
        ? receivables[4]
        : null;
    final Map<String, dynamic>? r5 = receivables.length > 5
        ? receivables[5]
        : null;
    final Map<String, dynamic>? p0 = payables.isNotEmpty ? payables[0] : null;
    final Map<String, dynamic>? p2 = payables.length > 2 ? payables[2] : null;
    return <Map<String, dynamic>>[
      if (r4 != null) <String, dynamic>{...r4, 'kind': 'recv'},
      if (p0 != null) <String, dynamic>{...p0, 'kind': 'pay'},
      if (p2 != null) <String, dynamic>{...p2, 'kind': 'pay'},
      if (r5 != null) <String, dynamic>{...r5, 'kind': 'recv'},
    ];
  }

  /// Dues-hub summary numbers (jsx:915-916).
  static const Map<String, dynamic> dueSummary = <String, dynamic>{
    'recv': <String, dynamic>{
      't': 'To get',
      's': 'Others owe you (Receivable)',
      'ic': 'in',
      'c': 'receipt',
      'v': 348690,
      'parties': '6 parties',
      'late': 113870,
      'lateTxt': 'late',
      'cls': 'amt big in',
    },
    'pay': <String, dynamic>{
      't': 'To give',
      's': 'You owe others (Payable)',
      'ic': 'out',
      'c': 'payment',
      'v': 126850,
      'parties': '5 parties',
      'late': 17700,
      'lateTxt': 'late',
      'cls': 'amt big out',
    },
  };
}
