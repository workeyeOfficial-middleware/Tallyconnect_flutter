// Typed notification + activity model. Wraps `NOTIFS` (jsx:211-218) and
// `ACTS` (jsx:219-230).
library;

/// Where tapping a notification navigates. The prototype's `go` is either a
/// bare screen key (`'activity'`) or `[screen, extra]` - this normalises both.
class TCNavTarget {
  const TCNavTarget(this.screen, [this.extra = const <String, String>{}]);

  final String screen;
  final Map<String, String> extra;

  factory TCNavTarget.parse(Object? raw) {
    if (raw is String) return TCNavTarget(raw);
    if (raw is List && raw.isNotEmpty) {
      final String s = raw.first.toString();
      final Object? e = raw.length > 1 ? raw[1] : null;
      if (e is Map) {
        return TCNavTarget(
          s,
          e.map((dynamic k, dynamic v) => MapEntry<String, String>(
            k.toString(),
            v.toString(),
          )),
        );
      }
    }
    return const TCNavTarget('');
  }
}

class TCNotification {
  const TCNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.time,
    this.icon = 'bell',
    this.colorKey = 'info',
    this.unread = false,
    this.target,
  });

  final String id;
  final String title;
  final String body;
  final String time;
  final String icon;

  /// A `tcSemantic` key: receipt / activity / team / payment / party / acc.
  final String colorKey;
  final bool unread;
  final TCNavTarget? target;

  TCNotification copyWith({bool? unread}) => TCNotification(
    id: id,
    title: title,
    body: body,
    time: time,
    icon: icon,
    colorKey: colorKey,
    unread: unread ?? this.unread,
    target: target,
  );

  factory TCNotification.fromMap(Map<String, dynamic> m) {
    final Object? go = m['go'];
    return TCNotification(
      id: (m['id'] ?? '') as String,
      title: (m['t'] ?? '') as String,
      body: (m['b'] ?? '') as String,
      time: (m['time'] ?? '') as String,
      icon: (m['ic'] ?? 'bell') as String,
      colorKey: (m['c'] ?? 'info') as String,
      unread: (m['unread'] ?? false) as bool,
      target: go == null ? null : TCNavTarget.parse(go),
    );
  }

  Map<String, dynamic> toMap() => <String, dynamic>{
    'id': id,
    't': title,
    'b': body,
    'time': time,
    'ic': icon,
    'c': colorKey,
    'unread': unread,
    if (target != null && target!.screen.isNotEmpty)
      'go': target!.extra.isEmpty
          ? target!.screen
          : <dynamic>[target!.screen, target!.extra],
  };
}

/// Sync/edit/invite timeline row for the Activity tab (jsx:2.15).
class TCActivity {
  const TCActivity({
    required this.id,
    required this.kind,
    required this.time,
    this.no = '',
    this.party = '',
    this.amt = 0,
    this.note = '',
    this.status = 'ok',
    this.target,
  });

  final String id;
  final String kind;
  final String no;
  final String party;
  final double amt;
  final String time;
  final String note;
  final String status;
  final TCNavTarget? target;

  String get title => no.isNotEmpty ? '${_pretty(kind)} $no' : _pretty(kind);

  String get body => party.isEmpty ? note : '$party${note.isEmpty ? '' : ' - $note'}';

  bool get isWaiting => status == 'wait';
  bool get isError => status == 'error';

  TCActivity copyWith({String? status, String? note}) => TCActivity(
    id: id,
    kind: kind,
    no: no,
    party: party,
    amt: amt,
    time: time,
    note: note ?? this.note,
    status: status ?? this.status,
    target: target,
  );

  factory TCActivity.fromMap(Map<String, dynamic> m) {
    final Object? go = m['go'];
    return TCActivity(
      id: (m['id'] ?? '') as String,
      kind: (m['kind'] ?? 'receipt') as String,
      no: (m['no'] ?? '') as String,
      party: (m['party'] ?? '') as String,
      amt: _num(m['amt']),
      time: (m['time'] ?? '') as String,
      note: (m['note'] ?? '') as String,
      status: (m['status'] ?? 'ok') as String,
      target: go == null ? null : TCNavTarget.parse(go),
    );
  }

  Map<String, dynamic> toMap() => <String, dynamic>{
    'id': id,
    'kind': kind,
    'no': no,
    'party': party,
    'amt': amt,
    'time': time,
    'note': note,
    'status': status,
    if (target != null && target!.screen.isNotEmpty)
      'go': target!.extra.isEmpty
          ? target!.screen
          : <dynamic>[target!.screen, target!.extra],
  };
}

String _pretty(String kind) {
  if (kind.isEmpty) return 'Entry';
  return kind[0].toUpperCase() + kind.substring(1);
}

double _num(Object? v) {
  if (v is num) return v.toDouble();
  if (v is String) return double.tryParse(v) ?? 0;
  return 0;
}