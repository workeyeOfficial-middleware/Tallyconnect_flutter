// Repository seam. Reads come from `TCMockData` (authoritative for the
// prototype's copy) with an sqflite overlay for user-created rows; writes go to
// both. This is the single file a real Tally REST bridge replaces.
library;

import 'package:sqflite/sqflite.dart';

import '../../core/storage/app_database.dart';
import '../mock/mock_data.dart';
import '../models/core_models.dart';
import '../models/notification_model.dart';
import '../models/voucher_model.dart';
import '../models/workspace_model.dart';

class TallyRepository {
  TallyRepository(this._db);

  final AppDatabase? _db;

  /// In-memory cache of user-created vouchers, so the wizard's save is visible
  /// immediately even before SQLite is consulted.
  final List<TCVoucher> _created = <TCVoucher>[];

  // ---- reference data (static in the prototype) ---------------------------

  List<TCParty> parties() => TCMockData.parties
      .map(TCParty.fromMap)
      .toList(growable: false);

  List<TCItem> items() =>
      TCMockData.items.map(TCItem.fromMap).toList(growable: false);

  List<TCCompany> companies() => TCMockData.companies
      .map(TCCompany.fromMap)
      .toList(growable: false);

  List<TCTeamMember> team() =>
      TCMockData.team.map(TCTeamMember.fromMap).toList(growable: false);

  List<TCAccount> accounts() =>
      TCMockData.accounts.map(TCAccount.fromMap).toList(growable: false);

  List<TCLedger> ledgers() =>
      TCMockData.ledgers.map(TCLedger.fromMap).toList(growable: false);

  List<TCSum> sums() =>
      TCMockData.sums.entries.map((MapEntry<String, Map<String, dynamic>> e) {
        final Map<String, dynamic> m = <String, dynamic>{
          ...e.value,
          'k': e.key,
        };
        return TCSum.fromMap(m);
      }).toList(growable: false);

  TCSum? sum(String key) {
    for (final TCSum s in sums()) {
      if (s.key == key) return s;
    }
    return null;
  }

  List<TCReport> reports() =>
      TCMockData.reports.map(TCReport.fromMap).toList(growable: false);

  List<TCFlowConfig> flowConfigs() => <TCFlowConfig>[
    for (final String type in TCKinds.all)
      if (TCMockData.flowTypes[type] != null)
        TCFlowConfig.fromMap(<String, dynamic>{
          'type': type,
          ...TCMockData.flowTypes[type]!,
        }),
  ];

  TCFlowConfig? flowConfig(String type) {
    for (final TCFlowConfig c in flowConfigs()) {
      if (c.type == type) return c;
    }
    return null;
  }

  List<TCSalesPoint> salesTrend() =>
      TCMockData.sales9Lines.map(TCSalesPoint.fromMap).toList(growable: false);

  Map<String, String> faqs() => <String, String>{
    for (final Map<String, String> m in TCMockData.faqs)
      if ((m['q'] ?? '').isNotEmpty) (m['q']!): (m['a'] ?? ''),
  };

  /// Outstanding rows: `RECV` when [kind] is recv, `PAYB` when pay.
  List<TCVoucherRow> outstanding(String kind) {
    final List<Map<String, dynamic>> src = kind == 'pay'
        ? TCMockData.payables
        : TCMockData.receivables;
    return src
        .map((Map<String, dynamic> m) => TCVoucherRow.fromMap(<String, dynamic>{
              ...m,
              'kind': kind == 'pay' ? TCKinds.payment : TCKinds.receipt,
            }))
        .toList(growable: false);
  }

  /// Derived "due soon" cards (TCMockData.dueSoon).
  List<TCVoucherRow> dueSoon() =>
      TCMockData.dueSoon().map(TCVoucherRow.fromMap).toList(growable: false);

  /// Receivable / payable roll-ups from TCMockData.dueSummary.
  Map<String, dynamic> dueSummary() => TCMockData.dueSummary;

  // ---- vouchers -----------------------------------------------------------

  /// Mock rows first, then anything the user saved this session.
  List<TCVoucher> vouchers() => <TCVoucher>[
    for (int i = 0; i < TCMockData.vouchers.length; i++)
      TCVoucher.fromMap(<String, dynamic>{
        ...TCMockData.vouchers[i],
        'id': 'v${i + 1}',
      }),
    ..._created,
  ];

  TCVoucher? voucher(String id) {
    for (final TCVoucher v in vouchers()) {
      if (v.id == id) return v;
    }
    return null;
  }

  /// Persists a wizard result as a `wait` entry - the prototype's "sent to Tally,
  /// syncing now" state (jsx:8.2).
  Future<TCVoucher> saveVoucher(TCVoucher v) async {
    _created.insert(0, v);
    final AppDatabase? d = _db;
    if (d != null) {
      await d.db.insert(
        AppDatabase.tVouchers,
        <String, dynamic>{
          'id': v.id,
          'kind': v.kind,
          'no': v.no,
          'party': v.party,
          'amt': v.amt,
          'date': v.date,
          'due': v.due,
          'status': v.status,
          'time': v.time,
          'note': v.note,
          'mode': v.mode,
          'acc': v.acc,
          'bank': v.bank,
          'paid': v.paid,
          'draft': v.draft ? 1 : 0,
          'json': v.toMap().toString(),
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
    return v;
  }

  /// Draft stays on the phone only - never pushed to the Tally mirror.
  Future<void> saveDraft(TCVoucher v) =>
      saveVoucher(v.copyWith(draft: true, status: TCKinds.statusOk));

  /// Simulated sync flip: `wait` -> `ok` (jsx:8.15).
  Future<void> markSynced(String id) async {
    final int i = _created.indexWhere((TCVoucher v) => v.id == id);
    if (i < 0) return;
    _created[i] = _created[i].copyWith(status: TCKinds.statusOk, fresh: false);
  }

  Future<void> retry(String id) async {
    final int i = _created.indexWhere((TCVoucher v) => v.id == id);
    if (i < 0) return;
    _created[i] = _created[i].copyWith(
      status: TCKinds.statusWait,
      note: 'Trying again…',
    );
    await Future<void>.delayed(const Duration(milliseconds: 1600));
    if (i < _created.length) {
      _created[i] = _created[i].copyWith(
        status: TCKinds.statusOk,
        note: '',
      );
    }
  }

  Future<void> deleteVoucher(String id) async {
    _created.removeWhere((TCVoucher v) => v.id == id);
    await _db?.db.delete(
      AppDatabase.tVouchers,
      where: 'id = ?',
      whereArgs: <Object?>[id],
    );
  }

  /// Vouchers filtered by kind / period, backing both the hub summary cards and
  /// `vList`.
  List<TCVoucher> vouchersWhere({
    List<String> kinds = const <String>[],
    String period = 'all',
    int limit = 0,
  }) {
    final List<TCVoucher> all = vouchers();
    final List<TCVoucher> out = all
        .where((TCVoucher v) => kinds.isEmpty || kinds.contains(v.kind))
        .toList();
    return limit > 0 && out.length > limit ? out.sublist(0, limit) : out;
  }

  // ---- notifications / activity -------------------------------------------

  List<TCNotification> notifications() =>
      TCMockData.notifications.map(TCNotification.fromMap).toList(growable: false);

  List<TCActivity> activities() =>
      TCMockData.activities.map(TCActivity.fromMap).toList(growable: false);

  // ---- workspaces ---------------------------------------------------------

  List<TCWorkspace> workspaces() =>
      TCMockData.workspaces.map(TCWorkspace.fromMap).toList(growable: false);

  List<String> defaultPageOne() => TCMockData.defaultPageOne();

  List<String> defaultPageTwo() => TCMockData.defaultPageTwo();
}