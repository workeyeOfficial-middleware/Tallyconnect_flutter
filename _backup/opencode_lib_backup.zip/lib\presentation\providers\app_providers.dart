// Overrides that bootstrap the app: SharedPreferences handle, optional SQLite
// mirror, and the repository. Every other provider reads from these.
library;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/storage/app_database.dart';
import '../../core/storage/local_storage.dart';
import '../../data/repositories/tally_repository.dart';

/// Null until `main()` finishes `LocalStorage.open()`.
final Provider<LocalStorage?> localStorageProvider = Provider<LocalStorage?>(
  (Ref ref) => null,
);

/// Null when sqflite is unavailable (e.g. a platform without the plugin) - the
/// app degrades to mock-only rather than failing to boot.
final Provider<AppDatabase?> appDatabaseProvider = Provider<AppDatabase?>(
  (Ref ref) => null,
);

final Provider<TallyRepository> repositoryProvider = Provider<TallyRepository>(
  (Ref ref) => TallyRepository(ref.watch(appDatabaseProvider)),
);