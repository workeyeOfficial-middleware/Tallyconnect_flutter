// sqflite schema + seeding. The prototype is a pure front-end mock, so this DB
// starts as a mirror of `TCMockData` and is the seam a real Tally bridge would
// replace later.
library;

import 'dart:convert';

import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../../data/mock/mock_data.dart';

/// Owns the SQLite handle. Seeding is idempotent: it only writes rows for
/// tables that are empty, so user edits survive relaunch.
class AppDatabase {
  AppDatabase._(this.db);

  final Database db;

  static const int _version = 1;

  static const String tCompanies = 'companies';
  static const String tParties = 'parties';
  static const String tItems = 'items';
  static const String tVouchers = 'vouchers';
  static const String tLedgers = 'ledgers';
  static const String tAccounts = 'accounts';
  static const String tActivities = 'activities';
  static const String tWorkspaces = 'workspaces';

  static Future<AppDatabase> open({String path = 'tallyconnect.db'}) async {
    final String dir = await getDatabasesPath();
    final Database db = await openDatabase(
      p.join(dir, path),
      version: _version,
      onCreate: (Database d, int v) async => _createSchema(d),
      onOpen: (Database d) async => seed(d),
    );
    return AppDatabase._(db);
  }

  static Future<void> _createSchema(Database d) async {
    final Batch b = d.batch();
    b.execute('''
      CREATE TABLE $tCompanies (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, trust TEXT, tan TEXT,
        pan TEXT, gstin TEXT, fy TEXT, json TEXT
      )''');
    b.execute('''
      CREATE TABLE $tParties (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, type TEXT, mobile TEXT,
        email TEXT, balGet REAL DEFAULT 0, balGive REAL DEFAULT 0,
        addr TEXT, gstin TEXT, json TEXT
      )''');
    b.execute('''
      CREATE TABLE $tItems (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, rate REAL DEFAULT 0,
        gst REAL DEFAULT 0, unit TEXT, stock REAL DEFAULT 0, json TEXT
      )''');
    b.execute('''
      CREATE TABLE $tVouchers (
        id TEXT PRIMARY KEY, kind TEXT NOT NULL, no TEXT, party TEXT,
        amt REAL DEFAULT 0, date TEXT, due TEXT, status TEXT DEFAULT 'ok',
        time TEXT, note TEXT, mode TEXT, acc TEXT, bank TEXT,
        paid REAL DEFAULT 0, draft INTEGER DEFAULT 0, json TEXT
      )''');
    b.execute('''
      CREATE TABLE $tLedgers (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, grp TEXT, type TEXT, json TEXT
      )''');
    b.execute('''
      CREATE TABLE $tAccounts (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, sub TEXT,
        isCash INTEGER DEFAULT 0, json TEXT
      )''');
    b.execute('''
      CREATE TABLE $tActivities (
        id TEXT PRIMARY KEY, kind TEXT, no TEXT, party TEXT, amt REAL DEFAULT 0,
        time TEXT, note TEXT, status TEXT DEFAULT 'ok', json TEXT
      )''');
    b.execute('''
      CREATE TABLE $tWorkspaces (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, builtin INTEGER DEFAULT 0,
        feats TEXT, sums TEXT, json TEXT
      )''');
    b.execute('CREATE INDEX ix_vouchers_kind ON $tVouchers(kind)');
    b.execute('CREATE INDEX ix_vouchers_status ON $tVouchers(status)');
    b.execute('CREATE INDEX ix_parties_name ON $tParties(name)');
    b.execute('CREATE INDEX ix_activities_time ON $tActivities(time)');
    await b.commit(noResult: true);
  }

  /// Inserts the mock rows for any table that is still empty.
  static Future<void> seed(Database d) async {
    Future<void> ifEmpty(
      String table,
      List<Map<String, dynamic>> rows,
    ) async {
      final int n = Sqflite.firstIntValue(
            await d.rawQuery('SELECT COUNT(*) FROM $table'),
          ) ??
          0;
      if (n > 0 || rows.isEmpty) return;
      final Batch b = d.batch();
      for (final Map<String, dynamic> r in rows) {
        b.insert(table, r, conflictAlgorithm: ConflictAlgorithm.replace);
      }
      await b.commit(noResult: true);
    }

    await ifEmpty(
      tCompanies,
      TCMockData.companies
          .map(
            (Map<String, String> m) => <String, dynamic>{
              'id': m['id'],
              'name': m['n'] ?? m['name'] ?? '',
              'trust': m['t'] ?? '',
              'tan': m['tan'] ?? '',
              'pan': m['pan'] ?? '',
              'gstin': m['gstin'] ?? '',
              'fy': m['fy'] ?? '',
              'json': jsonEncode(m),
            },
          )
          .toList(),
    );

    await ifEmpty(
      tParties,
      TCMockData.parties
          .map(
            (Map<String, dynamic> m) => <String, dynamic>{
              'id': m['id'] ?? '',
              'name': m['n'] ?? m['name'] ?? '',
              'type': m['t'] ?? 'both',
              'mobile': m['mob'] ?? m['mobile'] ?? '',
              'email': m['email'] ?? '',
              'balGet': m['balGet'] ?? 0,
              'balGive': m['balGive'] ?? 0,
              'addr': m['addr'] ?? '',
              'gstin': m['gstin'] ?? '',
              'json': jsonEncode(m),
            },
          )
          .toList(),
    );

    await ifEmpty(
      tItems,
      TCMockData.items
          .map(
            (Map<String, dynamic> m) => <String, dynamic>{
              'id': m['id'] ?? '',
              'name': m['n'] ?? m['name'] ?? '',
              'rate': m['r'] ?? m['rate'] ?? 0,
              'gst': m['gst'] ?? 0,
              'unit': m['unit'] ?? 'pc',
              'stock': m['stk'] ?? m['stock'] ?? 0,
              'json': jsonEncode(m),
            },
          )
          .toList(),
    );

    await ifEmpty(
      tLedgers,
      TCMockData.ledgers
          .map(
            (Map<String, String> m) => <String, dynamic>{
              'id': m['id'] ?? '',
              'name': m['n'] ?? m['name'] ?? '',
              'grp': m['g'] ?? m['group'] ?? '',
              'type': m['t'] ?? 'd',
              'json': jsonEncode(m),
            },
          )
          .toList(),
    );

    await ifEmpty(
      tAccounts,
      TCMockData.accounts
          .map(
            (Map<String, String> m) => <String, dynamic>{
              'id': m['id'] ?? '',
              'name': m['n'] ?? m['name'] ?? '',
              'sub': m['sub'] ?? '',
              'isCash': m['cash'] == 'true' ? 1 : 0,
              'json': jsonEncode(m),
            },
          )
          .toList(),
    );

    await ifEmpty(
      tWorkspaces,
      TCMockData.workspaces
          .map(
            (Map<String, dynamic> m) => <String, dynamic>{
              'id': m['id'] ?? '',
              'name': m['name'] ?? '',
              'builtin': (m['builtin'] ?? false) ? 1 : 0,
              'feats': jsonEncode(m['feats'] ?? const <String>[]),
              'sums': jsonEncode(m['sums'] ?? const <String>[]),
              'json': jsonEncode(m),
            },
          )
          .toList(),
    );

    await ifEmpty(
      tActivities,
      TCMockData.activities
          .map(
            (Map<String, dynamic> m) => <String, dynamic>{
              'id': m['id'] ?? '',
              'kind': m['kind'] ?? 'receipt',
              'no': m['no'] ?? '',
              'party': m['party'] ?? '',
              'amt': m['amt'] ?? 0,
              'time': m['time'] ?? '',
              'note': m['note'] ?? '',
              'status': m['status'] ?? 'ok',
              'json': jsonEncode(m),
            },
          )
          .toList(),
    );

    // Voucher mock rows have no stable id, so derive one.
    await ifEmpty(
      tVouchers,
      <Map<String, dynamic>>[
        for (int i = 0; i < TCMockData.vouchers.length; i++)
          <String, dynamic>{
            'id': 'v${i + 1}',
            'kind': TCMockData.vouchers[i]['kind'] ?? 'sales',
            'no': TCMockData.vouchers[i]['no'] ?? '',
            'party': TCMockData.vouchers[i]['party'] ?? '',
            'amt': TCMockData.vouchers[i]['amt'] ?? 0,
            'day': TCMockData.vouchers[i]['day'],
            'status': 'ok',
            'json': jsonEncode(TCMockData.vouchers[i]),
          },
      ],
    );
  }

  /// Wipes every table and re-seeds. Backs the Settings "Reset all" action.
  Future<void> reset() async {
    final Batch b = db.batch();
    for (final String t in <String>[
      tVouchers,
      tActivities,
      tParties,
      tItems,
      tLedgers,
      tAccounts,
      tCompanies,
      tWorkspaces,
    ]) {
      b.delete(t);
    }
    await b.commit(noResult: true);
    await seed(db);
  }

  Future<void> close() => db.close();
}