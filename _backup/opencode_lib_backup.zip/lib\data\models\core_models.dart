// Typed models for the remaining prototype datasets: PARTIES, ITEMS,
// COMPANIES, TEAM, ACCOUNTS, LEDGERS, SUMS, RECV/PAYB, REPORTS.
library;

/// `PARTIES` (jsx:152-167).
class TCParty {
  const TCParty({
    required this.id,
    required this.name,
    this.type = 'both',
    this.mobile = '',
    this.email = '',
    this.balGet = 0,
    this.balGive = 0,
    this.addr = '',
    this.gstin = '',
  });

  final String id;
  final String name;

  /// 'c' customer, 's' supplier, 'both'.
  final String type;
  final String mobile;
  final String email;
  final double balGet;
  final double balGive;
  final String addr;
  final String gstin;

  bool get isCustomer => type == 'c' || type == 'both';
  bool get isSupplier => type == 's' || type == 'both';
  bool get isSettled => balGet == 0 && balGive == 0;

  /// Net position: positive = you are owed, negative = you owe.
  double get net => balGet - balGive;

  /// One-letter initials, matching `tcInitials` in the design system.
  String get initial =>
      name.isEmpty ? '?' : name.substring(0, 1).toUpperCase();

  /// Balance cell text used on party rows.
  String get balanceLabel {
    if (balGet > 0) return 'To get';
    if (balGive > 0) return 'To give';
    return 'Settled';
  }

  factory TCParty.fromMap(Map<String, dynamic> m) => TCParty(
    id: (m['id'] ?? '') as String,
    name: (m['n'] ?? m['name'] ?? '') as String,
    type: (m['t'] ?? 'both') as String,
    mobile: (m['mob'] ?? m['mobile'] ?? '') as String,
    email: (m['email'] ?? '') as String,
    balGet: _num(m['balGet']),
    balGive: _num(m['balGive']),
    addr: (m['addr'] ?? '') as String,
    gstin: (m['gstin'] ?? '') as String,
  );

  Map<String, dynamic> toMap() => <String, dynamic>{
    'id': id,
    'n': name,
    't': type,
    'mob': mobile,
    'email': email,
    'balGet': balGet,
    'balGive': balGive,
    'addr': addr,
    'gstin': gstin,
  };
}

/// `ITEMS` (jsx:168-177).
class TCItem {
  const TCItem({
    required this.id,
    required this.name,
    this.rate = 0,
    this.gst = 0,
    this.unit = 'pc',
    this.stock = 0,
  });

  final String id;
  final String name;
  final double rate;
  final double gst;
  final String unit;
  final double stock;

  bool get isService => unit == 'svc';

  /// `4.5% GST` - hidden when zero so item rows stay quiet.
  String get gstLabel => gst == 0 ? '' : '${_trim(gst)}% GST';

  factory TCItem.fromMap(Map<String, dynamic> m) => TCItem(
    id: (m['id'] ?? '') as String,
    name: (m['n'] ?? m['name'] ?? '') as String,
    rate: _num(m['r'] ?? m['rate']),
    gst: _num(m['gst']),
    unit: (m['unit'] ?? 'pc') as String,
    stock: _num(m['stk'] ?? m['stock']),
  );

  Map<String, dynamic> toMap() => <String, dynamic>{
    'id': id,
    'n': name,
    'r': rate,
    'gst': gst,
    'unit': unit,
    'stk': stock,
  };
}

/// `COMPANIES` (jsx:188-192).
class TCCompany {
  const TCCompany({
    required this.id,
    required this.name,
    this.trust = '',
    this.tan = '',
    this.pan = '',
    this.gstin = '',
    this.fy = '',
  });

  final String id;
  final String name;
  final String trust;
  final String tan;
  final String pan;
  final String gstin;
  final String fy;

  /// `GI Apr 25-26` - the default company bar label (jsx:2.3).
  String get label => name;

  String get metaLine =>
      [if (trust.isNotEmpty) trust, if (fy.isNotEmpty) fy]
          .join(' · ');

  /// jsx:9.3 validation.
  bool get isValid =>
      name.trim().isNotEmpty &&
      gstin.length == 15 &&
      pan.length == 10 &&
      tan.length == 4;

  factory TCCompany.fromMap(Map<String, dynamic> m) => TCCompany(
    id: (m['id'] ?? '') as String,
    name: (m['n'] ?? m['name'] ?? '') as String,
    trust: (m['t'] ?? '') as String,
    tan: (m['tan'] ?? '') as String,
    pan: (m['pan'] ?? '') as String,
    gstin: (m['gstin'] ?? '') as String,
    fy: (m['fy'] ?? '') as String,
  );

  Map<String, dynamic> toMap() => <String, dynamic>{
    'id': id,
    'n': name,
    't': trust,
    'tan': tan,
    'pan': pan,
    'gstin': gstin,
    'fy': fy,
  };
}

/// `TEAM` (jsx:231-236).
class TCTeamMember {
  const TCTeamMember({
    required this.id,
    required this.name,
    required this.role,
    required this.status,
    this.initials = '',
    this.email = '',
  });

  final String id;
  final String name;
  final String role;

  /// 'active' | 'pending' | 'inactive'
  final String status;
  final String initials;
  final String email;

  bool get isPending => status == 'pending';
  bool get isActive => status == 'active';

  String get statusLabel => switch (status) {
    'active' => 'Active',
    'pending' => 'Invited',
    _ => 'Inactive',
  };

  /// 'ok' | 'warn' | 'info' - the `TCBadge` kind.
  String get statusKind => switch (status) {
    'active' => 'ok',
    'pending' => 'warn',
    _ => 'info',
  };

  factory TCTeamMember.fromMap(Map<String, dynamic> m) => TCTeamMember(
    id: (m['id'] ?? '') as String,
    name: (m['name'] ?? '') as String,
    role: (m['role'] ?? '') as String,
    status: (m['status'] ?? 'active') as String,
    initials: (m['initials'] ?? '') as String,
    email: (m['email'] ?? '') as String,
  );

  Map<String, dynamic> toMap() => <String, dynamic>{
    'id': id,
    'name': name,
    'role': role,
    'status': status,
    'initials': initials,
    'email': email,
  };
}

/// `ACCOUNTS` (jsx:187) - cash/bank targets for the payment step.
class TCAccount {
  const TCAccount({
    required this.id,
    required this.name,
    this.sub = '',
    this.isCash = false,
  });

  final String id;
  final String name;
  final String sub;
  final bool isCash;

  /// Default account id the wizard picks for Cash mode (jsx:FORM).
  static const String cashId = 'acct-cash';

  factory TCAccount.fromMap(Map<String, dynamic> m) => TCAccount(
    id: (m['id'] ?? '') as String,
    name: (m['n'] ?? m['name'] ?? '') as String,
    sub: (m['sub'] ?? '') as String,
    isCash: (m['cash'] ?? false) as bool,
  );

  Map<String, dynamic> toMap() => <String, dynamic>{
    'id': id,
    'n': name,
    'sub': sub,
    'cash': isCash,
  };
}

/// `LEDGERS` (jsx:183-186) - journal account picker.
class TCLedger {
  const TCLedger({
    required this.id,
    required this.name,
    required this.group,
    this.type = 'd',
  });

  final String id;
  final String name;
  final String group;

  /// 'c' capital, 'd' ... per the prototype's `t` field.
  final String type;

  factory TCLedger.fromMap(Map<String, dynamic> m) => TCLedger(
    id: (m['id'] ?? '') as String,
    name: (m['n'] ?? m['name'] ?? '') as String,
    group: (m['g'] ?? m['group'] ?? '') as String,
    type: (m['t'] ?? 'd') as String,
  );

  Map<String, dynamic> toMap() => <String, dynamic>{
    'id': id,
    'n': name,
    'g': group,
    't': type,
  };
}

/// `SUMS` (jsx:96-105) - the money summary cards.
class TCSum {
  const TCSum({
    required this.key,
    required this.title,
    required this.subtitle,
    required this.amount,
    required this.icon,
    required this.cls,
    this.target = '',
    this.targetExtra = const <String, String>{},
  });

  final String key;
  final String title;
  final String subtitle;
  final double amount;
  final String icon;

  /// Glass density class from the prototype (`g30`, `g40`, `g50`).
  final String cls;

  /// Screen key the card navigates to. Empty for cards the prototype leaves
  /// inert.
  final String target;
  final Map<String, String> targetExtra;

  int get level => int.tryParse(cls.replaceAll(RegExp(r'\D'), '')) ?? 60;

  /// `SUMBG` background per kind (jsx:3.1).
  int get bgArgb => switch (key) {
    'toGet' || 'toGive' => 0xFFF6E6EB,
    'mIn' || 'mOut' => 0xFFF1F5FF,
    'cash' || 'bank' => 0xFFF5F1FF,
    _ => 0xFFF6E8EE,
  };

  factory TCSum.fromMap(Map<String, dynamic> m) => TCSum(
    key: (m['k'] ?? '') as String,
    title: (m['t'] ?? '') as String,
    subtitle: (m['s'] ?? m['sub'] ?? '') as String,
    amount: _num(m['v'] ?? m['amt']),
    icon: (m['ic'] ?? 'rupee') as String,
    cls: (m['cls'] ?? 'g60') as String,
  );

  Map<String, dynamic> toMap() => <String, dynamic>{
    'k': key,
    't': title,
    's': subtitle,
    'v': amount,
    'ic': icon,
    'cls': cls,
  };
}

/// `REPORTS` (jsx:248-257) - report cards on the Reports tab.
class TCReport {
  const TCReport({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    this.screen = '',
  });

  final String id;
  final String title;
  final String subtitle;
  final String icon;

  /// Detail screen key. Empty means the prototype has no report detail view.
  final String screen;

  factory TCReport.fromMap(Map<String, dynamic> m) => TCReport(
    id: (m['id'] ?? '') as String,
    title: (m['t'] ?? m['title'] ?? '') as String,
    subtitle: (m['s'] ?? m['sub'] ?? '') as String,
    icon: (m['ic'] ?? 'chart') as String,
    screen: (m['go'] ?? '') as String,
  );

  Map<String, dynamic> toMap() => <String, dynamic>{
    'id': id,
    't': title,
    's': subtitle,
    'ic': icon,
    'go': screen,
  };
}

/// One chart point from `SALES9` (jsx:178-182).
class TCSalesPoint {
  const TCSalesPoint({
    required this.month,
    required this.value,
    required this.growth,
  });

  final String month;
  final double value;
  final double growth;

  factory TCSalesPoint.fromMap(Map<String, dynamic> m) => TCSalesPoint(
    month: (m['m'] ?? '') as String,
    value: _num(m['v']),
    growth: _num(m['g']),
  );
}

/// `FT` (jsx:193-199) - per-flow wizard config.
class TCFlowConfig {
  const TCFlowConfig({
    required this.type,
    required this.steps,
    required this.partyLabel,
    required this.partyList,
    this.items = false,
    this.contra = false,
    this.noLabel = '',
    this.amtLabel = '',
    this.balLabel = '',
    this.accLabel = '',
    this.draft = false,
    this.icon = 'bag',
    this.title = '',
    this.subtitle = '',
  });

  final String type;

  /// Step labels, e.g. `['Details', 'Items', 'Payment', 'Check']`.
  final List<String> steps;

  /// 'Customer', 'Supplier', 'Received from', ...
  final String partyLabel;

  /// 'c' or 's' - which side of the party pool to offer.
  final String partyList;
  final bool items;
  final bool contra;
  final String noLabel;
  final String amtLabel;
  final String balLabel;
  final String accLabel;

  /// Sales/purchase offer a Save-as-Draft at the check step.
  final bool draft;
  final String icon;
  final String title;
  final String subtitle;

  int get stepCount => steps.length;

  bool get hasParty => partyLabel.isNotEmpty;

  bool isStep(int i, String label) => i < steps.length && steps[i] == label;

  factory TCFlowConfig.fromMap(Map<String, dynamic> m) => TCFlowConfig(
    type: (m['type'] ?? '') as String,
    steps: ((m['steps'] as List<dynamic>?) ?? const <dynamic>[])
        .map((dynamic e) => e as String)
        .toList(growable: false),
    partyLabel: (m['partyLabel'] ?? '') as String,
    partyList: (m['list'] ?? 'c') as String,
    items: (m['items'] ?? false) as bool,
    contra: (m['contra'] ?? false) as bool,
    noLabel: (m['noLabel'] ?? '') as String,
    amtLabel: (m['amtLabel'] ?? '') as String,
    balLabel: (m['balLabel'] ?? '') as String,
    accLabel: (m['accLabel'] ?? '') as String,
    draft: (m['draft'] ?? false) as bool,
    icon: (m['ic'] ?? 'bag') as String,
    title: (m['t'] ?? '') as String,
    subtitle: (m['s'] ?? '') as String,
  );
}

double _num(Object? v) {
  if (v is num) return v.toDouble();
  if (v is String) return double.tryParse(v) ?? 0;
  return 0;
}

String _trim(double v) =>
    v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(2);