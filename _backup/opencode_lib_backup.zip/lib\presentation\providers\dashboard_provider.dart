// Dashboard state: the money summary roll-ups, activity feed, outstanding cards
// and reference lists the Home / Reports / Activity / Team tabs read.
library;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/mock/mock_data.dart';
import '../../data/models/core_models.dart';
import '../../data/models/notification_model.dart';
import '../../data/models/voucher_model.dart';
import '../../data/models/workspace_model.dart';
import 'app_providers.dart';
import 'workspace_provider.dart';

// ---- money summary (jsx:2.3 widget 2) ---------------------------------------

final Provider<List<TCSum>> sumsProvider = Provider<List<TCSum>>(
  (Ref ref) => ref.watch(repositoryProvider).sums(),
);

/// Sums the user picked for the active workspace, in `SUMBG` card order.
final Provider<List<TCSum>> workspaceSumsProvider = Provider<List<TCSum>>(
  (Ref ref) {
    final List<TCSum> all = ref.watch(sumsProvider);
    final Map<String, TCSum> byKey = <String, TCSum>{
      for (final TCSum s in all) s.key: s,
    };
    final List<String> keys = ref.watch(activeWorkspaceSumKeysProvider);
    return <TCSum>[for (final String k in keys) if (byKey[k] != null) byKey[k]!];
  },
);

/// Feature keys + sum keys for the active workspace - reads straight off
/// `WS` or the user's custom workspace.
final Provider<List<String>> activeWorkspaceSumKeysProvider =
    Provider<List<String>>((Ref ref) {
      final Object? active = ref.watch(activeWorkspaceProvider);
      if (active is TCWorkspace) return active.sums;
      return const <String>['toGet', 'toGive', 'mIn', 'mOut'];
    });

final Provider<TCWorkspace?> activeWorkspaceProvider =
    Provider<TCWorkspace?>((Ref ref) => ref.watch(workspaceProvider).active);

final Provider<List<TCWorkspace>> allWorkspacesProvider =
    Provider<List<TCWorkspace>>(
      (Ref ref) => ref.watch(workspaceProvider).custom.isEmpty
          ? ref.watch(repositoryProvider).workspaces()
          : <TCWorkspace>[
              ...ref.watch(repositoryProvider).workspaces(),
              ...ref.watch(workspaceProvider).custom,
            ],
    );

// ---- outstanding (jsx:2.13) --------------------------------------------------

final Provider<List<TCVoucherRow>> dueSoonProvider = Provider<List<TCVoucherRow>>(
  (Ref ref) => ref.watch(repositoryProvider).dueSoon(),
);

final Provider<List<TCVoucherRow>> receivablesProvider =
    Provider<List<TCVoucherRow>>(
      (Ref ref) => ref.watch(repositoryProvider).outstanding('recv'),
    );

final Provider<List<TCVoucherRow>> payablesProvider = Provider<List<TCVoucherRow>>(
  (Ref ref) => ref.watch(repositoryProvider).outstanding('pay'),
);

/// Total to get / to give, recomputed from the live voucher set so a newly
/// recorded sale moves the numbers.
final Provider<({double toGet, double toGive, double overdue, double nextDue})>
duesTotalsProvider =
    Provider<({double toGet, double toGive, double overdue, double nextDue})>((
      Ref ref,
    ) {
      final List<TCVoucherRow> rec = ref.watch(receivablesProvider);
      final List<TCVoucherRow> pay = ref.watch(payablesProvider);
      final double toGet = rec.fold<double>(
        0,
        (double a, TCVoucherRow r) => a + r.amt,
      );
      final double toGive = pay.fold<double>(
        0,
        (double a, TCVoucherRow r) => a + r.amt,
      );
      final DateTime now = DateTime(2026, 9, 26);
      double overdue = 0;
      for (final TCVoucherRow r in <TCVoucherRow>[...rec, ...pay]) {
        final DateTime? due = _parseDue(r.due);
        if (due != null && due.isBefore(now)) overdue += r.amt;
      }
      final List<double> dues = <double>[
        for (final TCVoucherRow r in <TCVoucherRow>[...rec, ...pay])
          if (_parseDue(r.due) != null && !_parseDue(r.due)!.isBefore(now))
            r.amt,
      ];
      return (
        toGet: toGet,
        toGive: toGive,
        overdue: overdue,
        nextDue: dues.isEmpty ? 0 : dues.reduce((double a, double b) => a < b ? a : b),
      );
    });

DateTime? _parseDue(String? raw) {
  if (raw == null || raw.trim().isEmpty) return null;
  final DateTime? d = DateTime.tryParse(raw.trim());
  if (d != null) return d;
  return DateTime.tryParse('2026-$raw');
}

// ---- activity (jsx:2.15) ----------------------------------------------------

final Provider<List<TCActivity>> activityFeedProvider = Provider<List<TCActivity>>(
  (Ref ref) => ref.watch(repositoryProvider).activities(),
);

enum ActivityFilter { all, syncs, edits, invites }

extension ActivityFilterX on ActivityFilter {
  String get label => switch (this) {
    ActivityFilter.all => 'All',
    ActivityFilter.syncs => 'Syncs',
    ActivityFilter.edits => 'Edits',
    ActivityFilter.invites => 'Invites',
  };
}

final NotifierProvider<ActivityFilterNotifier, ActivityFilter>
activityFilterProvider =
    NotifierProvider<ActivityFilterNotifier, ActivityFilter>(
      ActivityFilterNotifier.new,
    );

class ActivityFilterNotifier extends Notifier<ActivityFilter> {
  @override
  ActivityFilter build() => ActivityFilter.all;

  void set(ActivityFilter f) => state = f;
}

// ---- reference lists ---------------------------------------------------------

final Provider<List<TCParty>> partiesProvider = Provider<List<TCParty>>(
  (Ref ref) => ref.watch(repositoryProvider).parties(),
);

final Provider<List<TCTeamMember>> teamProvider = Provider<List<TCTeamMember>>(
  (Ref ref) => ref.watch(repositoryProvider).team(),
);

final Provider<List<TCReport>> reportsProvider = Provider<List<TCReport>>(
  (Ref ref) => ref.watch(repositoryProvider).reports(),
);

final Provider<List<TCSalesPoint>> salesTrendProvider =
    Provider<List<TCSalesPoint>>(
      (Ref ref) => ref.watch(repositoryProvider).salesTrend(),
    );

final Provider<Map<String, String>> faqsProvider = Provider<Map<String, String>>(
  (Ref ref) => ref.watch(repositoryProvider).faqs(),
);

/// Feature tiles for the active workspace, resolved from `T` (jsx:84-95).
final Provider<List<Map<String, String>>> activeFeaturesProvider =
    Provider<List<Map<String, String>>>((Ref ref) {
      final Map<String, Map<String, String>> byKey =
          TCMockData.features.map(
            (String k, Map<String, String> v) =>
                MapEntry<String, Map<String, String>>(k, v),
          );
      final TCWorkspace? ws = ref.watch(activeWorkspaceProvider);
      final List<String> keys =
          ws?.feats ??
          <String>[for (final String k in byKey.keys) k];
      return <Map<String, String>>[
        for (final String k in keys)
          if (byKey[k] != null) byKey[k]!,
      ];
    });