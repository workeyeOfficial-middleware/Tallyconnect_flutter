// Buttons, inputs, chips, badges, rows - port of the prototype UI primitives.
// Covers .btn/.btn-p/.btn-a/.btn-g (css:76-81), .chip/.chip.on (84-86),
// .seg (87-89), .inp/.iw (93-99), .fld/.lab (90-92), .badge (73-75),
// .row/.rt/.rs/.ra/.chev/.ell/.amt (62-72), .hrow/.sec/.h2 (55-57).
import 'package:flutter/material.dart';

import 'tc_colors.dart';
import 'tc_glass.dart';
import 'tc_icons.dart';
import 'tc_theme_engine.dart';
import 'tc_typography.dart';

/// Primary/Accent/Glass button variants.
enum TCButtonVariant { primary, accent, glass, plain }

class TCButton extends StatelessWidget {
  const TCButton({
    super.key,
    required this.label,
    this.variant = TCButtonVariant.accent,
    this.onTap,
    this.iconLeft,
    this.iconRight,
    this.fullWidth = false,
    this.enabled = true,
    this.padding,
    this.radius = 18,
  });

  final String label;
  final TCButtonVariant variant;
  final VoidCallback? onTap;
  final String? iconLeft;
  final String? iconRight;
  final bool fullWidth;
  final bool enabled;
  final EdgeInsetsGeometry? padding;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final TCTheme t = TCScope.of(context);
    final VoidCallback? tap = enabled ? onTap : null;

    Widget inner = Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        if (iconLeft != null) ...<Widget>[
          TCIconSized(k: iconLeft!, sz: TCIconSize.m, color: _fg(context)),
          const SizedBox(width: 8),
        ],
        Flexible(
          child: Text(
            label,
            style: context.tct.btn.copyWith(color: _fg(context)),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        if (iconRight != null) ...<Widget>[
          const SizedBox(width: 8),
          TCIconSized(k: iconRight!, sz: TCIconSize.m, color: _fg(context)),
        ],
      ],
    );

    if (padding != null) inner = Padding(padding: padding!, child: inner);

    BoxDecoration? dec;
    switch (variant) {
      case TCButtonVariant.accent:
        dec = BoxDecoration(
          borderRadius: BorderRadius.circular(radius),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: <Color>[t.acc2, t.acc3],
          ),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: const Color(0xFFFFFFFF).withValues(alpha: .28),
              blurRadius: 0,
              offset: const Offset(0, -1),
            ),
            BoxShadow(
              color: t.acc3.withValues(alpha: .65),
              blurRadius: 26,
              offset: const Offset(0, 14),
              spreadRadius: -12,
            ),
          ],
        );
        break;
      case TCButtonVariant.primary:
        dec = BoxDecoration(
          borderRadius: BorderRadius.circular(radius),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: <Color>[t.navy2, t.navy3],
          ),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: const Color(0xFFFFFFFF).withValues(alpha: .28),
              blurRadius: 0,
              offset: const Offset(0, -1),
            ),
            BoxShadow(
              color: t.navy3.withValues(alpha: .70),
              blurRadius: 26,
              offset: const Offset(0, 14),
              spreadRadius: -12,
            ),
          ],
        );
        break;
      case TCButtonVariant.glass:
        // .btn-g (css:80) - glass. Built here rather than returned so
        // `enabled` and `fullWidth` still apply.
        Widget g = TCGlass(
          style: TCGlassStyle.standard,
          radius: radius,
          padding: EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          onTap: tap,
          child: inner,
        );
        if (!enabled) g = Opacity(opacity: .42, child: g);
        if (fullWidth) g = SizedBox(width: double.infinity, child: g);
        return g;
      case TCButtonVariant.plain:
        dec = BoxDecoration(borderRadius: BorderRadius.circular(radius));
        break;
    }

    Widget btn = Container(
      height: 56,
      decoration: dec,
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: inner,
    );
    if (!enabled) btn = Opacity(opacity: .42, child: btn);
    if (fullWidth) btn = SizedBox(width: double.infinity, child: btn);
    if (tap != null) {
      btn = _Tap(tap: tap, radius: radius, child: btn);
    }
    return btn;
  }

  Color _fg(BuildContext context) {
    switch (variant) {
      case TCButtonVariant.accent:
      case TCButtonVariant.primary:
        return Colors.white;
      case TCButtonVariant.glass:
      case TCButtonVariant.plain:
        return TCScope.of(context).ink;
    }
  }
}

class _Tap extends StatelessWidget {
  const _Tap({required this.tap, required this.child, required this.radius});
  final VoidCallback tap;
  final Widget child;
  final double radius;
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: tap,
    borderRadius: BorderRadius.circular(radius),
    child: child,
  );
}

/// Chip (.chip / .chip.on)
class TCChip extends StatelessWidget {
  const TCChip({
    super.key,
    required this.label,
    this.on = false,
    this.icon,
    this.onTap,
    this.selected = false,
  });

  final String label;
  final bool on;
  final String? icon;
  final VoidCallback? onTap;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final TCTheme t = TCScope.of(context);
    final bool sel = on || selected;
    return TCGlass(
      style: TCGlassStyle.standard,
      radius: 21,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      elevated: sel,
      onTap: onTap,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          if (icon != null) ...<Widget>[
            TCIconSized(
              k: icon!,
              sz: TCIconSize.s,
              color: sel ? Colors.white : t.ink2,
            ),
            const SizedBox(width: 7),
          ],
          Text(
            label,
            style: context.tct.chip.copyWith(
              color: sel ? Colors.white : t.ink2,
            ),
          ),
        ],
      ),
    );
  }
}

/// Segmented control (.seg)
class TCSegmented extends StatelessWidget {
  const TCSegmented({
    super.key,
    required this.items,
    required this.index,
    required this.onChanged,
  });

  final List<String> items;
  final int index;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    final TCTheme t = TCScope.of(context);
    return TCGlass(
      style: TCGlassStyle.standard,
      radius: 17,
      padding: const EdgeInsets.all(4),
      child: Row(
        children: <Widget>[
          for (int i = 0; i < items.length; i++)
            Expanded(
              child: GestureDetector(
                onTap: () => onChanged(i),
                child: Container(
                  height: 42,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(13),
                    color: i == index ? Colors.white : Colors.transparent,
                    boxShadow: i == index
                        ? <BoxShadow>[
                            BoxShadow(
                              color: tcNavyAlpha(.14),
                              blurRadius: 10,
                              offset: const Offset(0, 3),
                            ),
                          ]
                        : null,
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    items[i],
                    style: context.tct.seg.copyWith(
                      color: i == index ? t.ink : t.ink2,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Input field (.fld/.inp/.iw)
class TCField extends StatelessWidget {
  const TCField({
    super.key,
    required this.label,
    this.hint,
    this.icon,
    this.controller,
    this.obscure = false,
    this.toggleObscure,
    this.keyboardType,
    this.onChanged,
    this.required = false,
    this.error,
  });

  final String label;
  final String? hint;
  final String? icon;
  final TextEditingController? controller;
  final bool obscure;
  final VoidCallback? toggleObscure;
  final TextInputType? keyboardType;
  final ValueChanged<String>? onChanged;
  final bool required;
  final String? error;

  @override
  Widget build(BuildContext context) {
    final TCTheme t = TCScope.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            children: <Widget>[
              Text(label, style: context.tct.lab),
              if (required)
                Text(' *', style: context.tct.lab.copyWith(color: t.neg)),
            ],
          ),
        ),
        const SizedBox(height: 7),
        TCGlass(
          style: TCGlassStyle.standard,
          radius: 16,
          padding: EdgeInsets.zero,
          child: Stack(
            children: <Widget>[
              if (icon != null)
                Positioned(
                  left: 16,
                  top: 0,
                  bottom: 0,
                  child: Center(
                    child: TCIconSized(
                      k: icon!,
                      sz: TCIconSize.m,
                      color: t.ink3,
                    ),
                  ),
                ),
              TextField(
                controller: controller,
                obscureText: obscure,
                keyboardType: keyboardType,
                onChanged: onChanged,
                style: context.tct.inp,
                decoration: InputDecoration(
                  hintText: hint,
                  hintStyle: context.tct.inp.copyWith(color: t.ink3),
                  contentPadding: EdgeInsets.only(
                    left: icon != null ? 48 : 16,
                    right: toggleObscure != null ? 56 : 16,
                    top: 18,
                    bottom: 18,
                  ),
                  border: InputBorder.none,
                  filled: false,
                ),
              ),
              if (toggleObscure != null)
                Positioned(
                  right: 6,
                  top: 6,
                  child: GestureDetector(
                    onTap: toggleObscure,
                    child: TCGlass(
                      radius: 14,
                      padding: const EdgeInsets.all(10),
                      child: TCIconSized(
                        k: obscure ? 'eyeOff' : 'eye',
                        sz: TCIconSize.s,
                        color: t.ink3,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
        if (error != null) ...<Widget>[
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text(error!, style: context.tct.rs.copyWith(color: t.neg)),
          ),
        ],
      ],
    );
  }
}

/// Badge (.badge + variants)
class TCBadge extends StatelessWidget {
  const TCBadge({super.key, required this.text, this.kind = 'info'});

  final String text;
  final String kind;

  @override
  Widget build(BuildContext context) {
    final TCTheme t = TCScope.of(context);
    Color bg;
    Color fg;
    switch (kind) {
      case 'ok':
        bg = t.pos.withValues(alpha: .12);
        fg = t.pos;
      case 'warn':
        bg = t.warn.withValues(alpha: .12);
        fg = t.warn;
      case 'bad':
        bg = t.neg.withValues(alpha: .12);
        fg = t.neg;
      case 'acc':
        bg = t.acc.withValues(alpha: .10);
        fg = t.acc;
      case 'info':
      default:
        bg = tcNavyAlpha(.08);
        fg = t.navy;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(99),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(color: fg, shape: BoxShape.circle),
          ),
          const SizedBox(width: 5),
          Text(text, style: context.tct.badge.copyWith(color: fg)),
        ],
      ),
    );
  }
}

/// List row (.row) - supports avatar, icon chip, chev.
class TCRow extends StatelessWidget {
  const TCRow({
    super.key,
    this.iconKey,
    this.avatar,
    this.title,
    this.subtitle,
    this.amount,
    this.amountColor,
    this.trailing,
    this.chev = false,
    this.onTap,
    this.padding,
  });

  final String? iconKey;
  final Widget? avatar;
  final String? title;
  final String? subtitle;
  final String? amount;
  final Color? amountColor;
  final Widget? trailing;
  final bool chev;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry? padding;

  @override
  Widget build(BuildContext context) {
    final TCTheme t = TCScope.of(context);
    Widget left = const SizedBox();
    if (avatar != null) {
      left = avatar!;
    } else if (iconKey != null) {
      left = TCIconChip(
        color: t.acc,
        child: TCIconSized(k: iconKey!, sz: TCIconSize.m, color: t.acc),
      );
    }
    final Widget row = Row(
      children: <Widget>[
        left,
        if (left != const SizedBox()) const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              if (title != null)
                Text(
                  title!,
                  style: context.tct.rt,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              if (subtitle != null) ...<Widget>[
                const SizedBox(height: 2),
                Text(
                  subtitle!,
                  style: context.tct.rs,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ],
          ),
        ),
        if (amount != null) ...<Widget>[
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Text(
                amount!,
                style: context.tct.amtTab.copyWith(color: amountColor ?? t.ink),
              ),
              if (trailing != null) ?trailing,
            ],
          ),
        ] else if (trailing != null) ...<Widget>[
          const SizedBox(width: 8),
          trailing!,
        ],
        if (chev) ...<Widget>[
          const SizedBox(width: 8),
          TCIconSized(k: 'chevR', sz: TCIconSize.s, color: t.ink3),
        ],
      ],
    );
    final Widget padded = Container(
      padding:
          padding ?? const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      constraints: const BoxConstraints(minHeight: 66),
      child: row,
    );
    if (onTap != null) return GestureDetector(onTap: onTap, child: padded);
    return padded;
  }
}

/// Section header (.hrow/.sec/.h2)
class TCSection extends StatelessWidget {
  const TCSection({
    super.key,
    required this.title,
    this.action,
    this.marginTop = 22,
  });

  final String title;
  final Widget? action;
  final double marginTop;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.fromLTRB(4, marginTop, 4, 12),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(title, style: context.tct.h2)),
          ?action,
        ],
      ),
    );
  }
}

class TCSectionLabel extends StatelessWidget {
  const TCSectionLabel({super.key, required this.text, this.marginTop = 22});

  final String text;
  final double marginTop;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.fromLTRB(8, marginTop, 8, 8),
      child: Text(text.toUpperCase(), style: context.tct.sec),
    );
  }
}
