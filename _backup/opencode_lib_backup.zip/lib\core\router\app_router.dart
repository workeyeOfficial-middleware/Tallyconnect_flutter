// Navigation. The prototype keeps a manual `history` array plus a `dir` flag
// ('fwd' | 'bk') instead of named routes (inventory 1.4), and derives the tab
// bar from `NO_TAB` / `TITLES`. This mirrors that model exactly.
//
// go_router is declared in pubspec but deliberately unused: its imperative
// `go()` cannot express a JS-style history stack with direction-aware
// transitions without fighting the framework.
library;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/mock/mock_data.dart';
import '../../presentation/providers/app_providers.dart';
import '../../presentation/providers/auth_provider.dart';

/// Screen keys. These mirror the prototype's `s` values exactly (NO_TAB /
///// FLOWLIKE / TITLES, jsx:79-82) so the port stays 1:1.
class TCScreens {
  TCScreens._();

  // ---- tabs
  static const String home = 'home';
  static const String outHub = 'outHub';
  static const String team = 'team';
  static const String activity = 'activity';
  static const String reports = 'reports';

  // ---- full-screen (NO_TAB)
  static const String login = 'login';
  static const String forgot = 'forgot';

  // ---- flow-like (FLOWLIKE)
  static const String flow = 'flow';
  static const String createWs = 'createWs';
  static const String manageWs = 'manageWs';
  static const String billDetail = 'billDetail';
  static const String partyDetail = 'partyDetail';
  static const String entryDetail = 'entryDetail';

  // ---- stackable, tab-visible
  static const String notifs = 'notifs';
  static const String newEntry = 'newEntry';
  static const String vHub = 'vHub';
  static const String vList = 'vList';
  static const String outList = 'outList';
  static const String items = 'items';
  static const String party = 'party';
  static const String settings = 'settings';
  static const String companies = 'companies';
  static const String billing = 'billing';
  static const String refer = 'refer';
  static const String help = 'help';
  static const String report = 'report';

  /// Every key the prototype's `switch` handles.
  static const List<String> all = <String>[
    home,
    notifs,
    createWs,
    manageWs,
    newEntry,
    flow,
    vHub,
    vList,
    entryDetail,
    outHub,
    outList,
    billDetail,
    items,
    party,
    partyDetail,
    reports,
    report,
    activity,
    team,
    settings,
    companies,
    billing,
    refer,
    help,
    login,
    forgot,
  ];

  /// Tab keys in display order (TABS, jsx:79).
  static const List<String> tabs = <String>[
    home,
    outHub,
    team,
    activity,
    reports,
  ];

  static bool isTab(String k) => tabs.contains(k);

  static bool showsTabBar(String k) => !TCMockData.noTab.contains(k);

  static bool isFlowLike(String k) => TCMockData.flowLike.contains(k);

  static String title(String k) =>
      (TCMockData.titles[k] ?? '').isEmpty ? k : TCMockData.titles[k]!;
}

class NavState {
  const NavState({
    this.screen = TCScreens.home,
    this.tab = 0,
    this.tabOrder = const <int>[0, 1, 2, 3, 4],
    this.dir = 'fwd',
    this.history = const <String>[],
    this.extra = const <String, String>{},
  });

  /// Current screen key.
  final String screen;

  /// Selected tab index into [TCScreens.tabs] (pre-reorder).
  final int tab;

  /// Tab display order after drag-reorder (js x:1.5).
  final List<int> tabOrder;

  /// 'fwd' | 'bk' - which way the slide animation runs (jsx:1.4).
  final String dir;

  final List<String> history;

  /// Nav params from `go(s, extra)`, e.g. `vFilter`, `outKind`, `entryId`.
  final Map<String, String> extra;

  bool get isForward => dir == 'fwd';
  bool get canGoBack => history.isNotEmpty;
  bool get showsTabBar => TCScreens.showsTabBar(screen);
  bool get isFlowLike => TCScreens.isFlowLike(screen);
  String get title => TCScreens.title(screen);
  String get backLabel => history.isEmpty
      ? 'Home'
      : TCScreens.title(history.last);

  NavState copyWith({
    String? screen,
    int? tab,
    List<int>? tabOrder,
    String? dir,
    List<String>? history,
    Map<String, String>? extra,
  }) => NavState(
    screen: screen ?? this.screen,
    tab: tab ?? this.tab,
    tabOrder: tabOrder ?? this.tabOrder,
    dir: dir ?? this.dir,
    history: history ?? this.history,
    extra: extra ?? this.extra,
  );
}

class NavNotifier extends Notifier<NavState> {
  @override
  NavState build() => NavState(
    tabOrder: ref.watch(tabOrderProvider),
    screen: ref.watch(isLoggedInProvider) ? TCScreens.home : TCScreens.login,
  );

  /// jsx:1.4 `go` - push current onto history, animate forward.
  void go(String screen, [Map<String, String> extra = const <String, String>{}]) {
    final List<String> h = <String>[...state.history, state.screen];
    // Tapping a tab screen clears the stack above the tab root.
    final int ti = TCScreens.tabs.indexOf(screen);
    if (ti >= 0) {
      state = state.copyWith(
        screen: screen,
        tab: ti,
        history: <String>[],
        dir: 'fwd',
        extra: extra,
      );
      return;
    }
    state = state.copyWith(
      screen: screen,
      history: h,
      dir: 'fwd',
      extra: extra,
    );
  }

  /// jsx:1.4 `back` - pop. Empty stack falls back to home; `forgot` returns to
  /// login specifically.
  void back() {
    if (state.screen == TCScreens.forgot) {
      state = state.copyWith(
        screen: TCScreens.login,
        dir: 'bk',
        history: const <String>[],
        extra: const <String, String>{},
      );
      return;
    }
    if (state.history.isEmpty) {
      state = state.copyWith(
        screen: TCScreens.home,
        tab: 0,
        dir: 'bk',
        extra: const <String, String>{},
      );
      return;
    }
    final List<String> h = List<String>.of(state.history);
    final String prev = h.removeLast();
    final int ti = TCScreens.tabs.indexOf(prev);
    state = state.copyWith(
      screen: prev,
      history: h,
      dir: 'bk',
      tab: ti >= 0 ? ti : state.tab,
      extra: const <String, String>{},
    );
  }

  /// jsx:1.4 `jump` - start at a screen without animating a push.
  void jump(String screen, {Map<String, String> extra = const <String, String>{}}) {
    final int ti = TCScreens.tabs.indexOf(screen);
    state = state.copyWith(
      screen: screen,
      tab: ti >= 0 ? ti : 0,
      history: const <String>[],
      dir: 'bk',
      extra: extra,
    );
  }

  /// jsx:1.4 `selectTab` - switch tabs, keeping tab-rooted history.
  void selectTab(int i) {
    if (i < 0 || i >= TCScreens.tabs.length) return;
    state = state.copyWith(
      screen: TCScreens.tabs[i],
      tab: i,
      history: const <String>[],
      dir: 'fwd',
      extra: const <String, String>{},
    );
  }

  /// jsx:8.5 - tab drag-reorder, persisted to `tc-liquid-tabs`.
  void reorderTabs(int oldIndex, int newIndex) {
    final List<int> order = List<int>.of(state.tabOrder);
    if (oldIndex < 0 || oldIndex >= order.length) return;
    int target = newIndex;
    if (target > oldIndex) target -= 1;
    target = target.clamp(0, order.length - 1);
    final int moved = order.removeAt(oldIndex);
    order.insert(target, moved);
    state = state.copyWith(tabOrder: order);
    ref.read(tabOrderProvider.notifier).set(order);
  }

  /// Replaces the current stack entry's extra - used after a save returns home.
  void setExtra(Map<String, String> extra) =>
      state = state.copyWith(extra: extra);

  void clear() => state = state.copyWith(
    history: const <String>[],
    extra: const <String, String>{},
  );

  /// Logged-out landing.
  void toLogin() => state = state.copyWith(
    screen: TCScreens.login,
    history: const <String>[],
    tab: 0,
    dir: 'fwd',
    extra: const <String, String>{},
  );
}

final NotifierProvider<NavNotifier, NavState> navProvider =
    NotifierProvider<NavNotifier, NavState>(NavNotifier.new);

/// Reorders tabs and persists them.
class TabOrderNotifier extends Notifier<List<int>> {
  @override
  List<int> build() =>
      ref.watch(localStorageProvider)?.tabOrder(TCScreens.tabs.length) ??
      const <int>[0, 1, 2, 3, 4];

  void set(List<int> order) {
    state = order;
    ref.read(localStorageProvider)?.writeTabOrder(order);
  }
}

final NotifierProvider<TabOrderNotifier, List<int>> tabOrderProvider =
    NotifierProvider<TabOrderNotifier, List<int>>(TabOrderNotifier.new);

/// Rebuilds [navProvider] when auth flips, so logging in lands on Home and
/// logging out drops the whole stack.
final Provider<bool> isLoggedInProvider = Provider<bool>(
  (Ref ref) => ref.watch(authProvider).loggedIn,
);

/// 30px slide with the prototype's cubic-bezier(.2,.85,.2,1) (jsx:6.2).
class TCSlidePage {
  const TCSlidePage._();

  static const Curve _ease = Cubic(0.2, 0.85, 0.2, 1);

  /// `forward` true slides in from the right, false from the left.
  static PageRouteBuilder<void> route({
    required Widget child,
    required bool forward,
  }) => PageRouteBuilder<void>(
    transitionDuration: const Duration(milliseconds: 420),
    reverseTransitionDuration: const Duration(milliseconds: 420),
    pageBuilder:
        (BuildContext _, Animation<double> a, Animation<double> _) => child,
    transitionsBuilder:
        (BuildContext _, Animation<double> a, Animation<double> s, Widget c) {
          final Animation<Offset> slide = Tween<Offset>(
            begin: Offset(forward ? 30 / 390 : -30 / 390, 0),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: a, curve: _ease));
          return SlideTransition(position: slide, child: c);
        },
  );
}

/// `.root` scroll container: 28px top, 16px sides, 36px bottom (jsx:7.4),
/// hidden scrollbars, plus the 100px bottom pad on tab screens.
class TCScreenBody extends StatelessWidget {
  const TCScreenBody({
    super.key,
    required this.child,
    this.hasTabBar = false,
    this.padding,
    this.controller,
  });

  final Widget child;
  final bool hasTabBar;
  final EdgeInsetsGeometry? padding;
  final ScrollController? controller;

  @override
  Widget build(BuildContext context) {
    final MediaQueryData mq = MediaQuery.of(context);
    return SingleChildScrollView(
      controller: controller,
      physics: const BouncingScrollPhysics(
        parent: AlwaysScrollableScrollPhysics(),
      ),
      padding:
          padding ??
          EdgeInsets.only(
            top: mq.padding.top + 28,
            left: 16,
            right: 16,
            bottom: hasTabBar ? 100 + mq.padding.bottom : 36 + mq.padding.bottom,
          ),
      child: child,
    );
  }
}