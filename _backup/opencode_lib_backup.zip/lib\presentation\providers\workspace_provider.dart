// Active workspace + its home page layout, and the active company / company bar
// status. Together these back the whole Home tab (jsx:2.3).
library;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/models/core_models.dart';
import '../../data/models/workspace_model.dart';
import 'app_providers.dart';

// ------------------------------------------------------------------ company ---

class CompanyState {
  const CompanyState({
    this.companyId = '',
    this.syncLabel = 'Synced 2 min ago',
    this.connected = true,
  });

  final String companyId;

  /// `Synced 2 min ago` under the company name (jsx:2.3).
  final String syncLabel;
  final bool connected;

  CompanyState copyWith({String? companyId, String? syncLabel, bool? connected}) =>
      CompanyState(
        companyId: companyId ?? this.companyId,
        syncLabel: syncLabel ?? this.syncLabel,
        connected: connected ?? this.connected,
      );
}

class CompanyNotifier extends Notifier<CompanyState> {
  @override
  CompanyState build() {
    final List<TCCompany> all = ref.watch(repositoryProvider).companies();
    final String saved = ref.watch(localStorageProvider)?.activeCompany ?? '';
    final bool ok = all.any((TCCompany c) => c.id == saved);
    return CompanyState(companyId: ok ? saved : (all.isEmpty ? '' : all.first.id));
  }

  void select(String id) {
    state = state.copyWith(companyId: id, syncLabel: 'Synced just now');
    ref.read(localStorageProvider)?.activeCompany = id;
  }

  /// Simulated re-sync tick (jsx:8.15).
  Future<void> syncNow() async {
    state = state.copyWith(connected: true, syncLabel: 'Syncing…');
    await Future<void>.delayed(const Duration(milliseconds: 1200));
    state = state.copyWith(syncLabel: 'Synced just now');
  }
}

final NotifierProvider<CompanyNotifier, CompanyState> companyProvider =
    NotifierProvider<CompanyNotifier, CompanyState>(CompanyNotifier.new);

final Provider<List<TCCompany>> companiesProvider = Provider<List<TCCompany>>(
  (Ref ref) => ref.watch(repositoryProvider).companies(),
);

/// The company shown in the company bar. Falls back to the first so the bar
/// never renders empty.
final Provider<TCCompany?> activeCompanyProvider = Provider<TCCompany?>(
  (Ref ref) {
    final List<TCCompany> all = ref.watch(companiesProvider);
    final String id = ref.watch(companyProvider).companyId;
    for (final TCCompany c in all) {
      if (c.id == id) return c;
    }
    return all.isEmpty ? null : all.first;
  },
);

// ---------------------------------------------------------------- workspace ---

class WorkspaceState {
  WorkspaceState({
    required this.activeId,
    required this.custom,
    required this.layouts,
    required this.editing,
  });

  final String activeId;

  /// User-created workspaces, merged after the three builtins.
  final List<TCWorkspace> custom;

  /// Page layout per workspace id.
  final Map<String, TCPageLayout> layouts;

  /// Home edit mode - widgets lift and gain +/− badges (jsx:8.3).
  final bool editing;

  TCWorkspace? get active {
    for (final TCWorkspace w in custom) {
      if (w.id == activeId) return w;
    }
    return null;
  }

  TCPageLayout get layout => layouts[activeId] ?? TCPageLayout(pages: <TCHomePage>[TCHomePage()]);

  WorkspaceState copyWith({
    String? activeId,
    List<TCWorkspace>? custom,
    Map<String, TCPageLayout>? layouts,
    bool? editing,
  }) => WorkspaceState(
    activeId: activeId ?? this.activeId,
    custom: custom ?? this.custom,
    layouts: layouts ?? this.layouts,
    editing: editing ?? this.editing,
  );
}

class WorkspaceNotifier extends Notifier<WorkspaceState> {
  @override
  WorkspaceState build() {
    final storage = ref.watch(localStorageProvider);
    final String savedId = storage?.activeWorkspace ?? 'def';
    final List<TCWorkspace> builtin = ref.watch(repositoryProvider).workspaces();
    final Map<String, TCPageLayout> layouts = <String, TCPageLayout>{};
    for (final TCWorkspace w in builtin) {
      layouts[w.id] = _loadLayout(w.id);
    }
    if (!layouts.containsKey(savedId)) layouts[savedId] = _loadLayout(savedId);
    return WorkspaceState(
      activeId: savedId,
      custom: const <TCWorkspace>[],
      layouts: layouts,
      editing: false,
    );
  }

  TCPageLayout _loadLayout(String wsId) {
    final storage = ref.watch(localStorageProvider);
    if (storage != null) return storage.readPages(wsId);
    return tcDefaultLayout(
      pageOne: ref.read(repositoryProvider).defaultPageOne(),
      pageTwo: ref.read(repositoryProvider).defaultPageTwo(),
    );
  }

  void _persist(String wsId) {
    final storage = ref.read(localStorageProvider);
    storage?.writePages(wsId, state.layouts[wsId] ?? TCPageLayout(pages: <TCHomePage>[TCHomePage()]));
  }

  void _update(WorkspaceState next) => state = next;

  /// Builtins + user-created, in that order (jsx:2.6).
  List<TCWorkspace> allWorkspaces() => <TCWorkspace>[
    ...ref.read(repositoryProvider).workspaces(),
    ...state.custom,
  ];

  void select(String id) {
    _update(state.copyWith(activeId: id, editing: false));
    ref.read(localStorageProvider)?.activeWorkspace = id;
  }

  // ---- edit mode ----------------------------------------------------------

  void enterEdit() => _update(state.copyWith(editing: true));
  void doneEdit() => _update(state.copyWith(editing: false));
  void cancelEdit() {
    // Drop unsaved layout changes by reloading from storage.
    final String wsId = state.activeId;
    final Map<String, TCPageLayout> l = Map<String, TCPageLayout>.of(state.layouts);
    l[wsId] = _loadLayout(wsId);
    _update(state.copyWith(editing: false, layouts: l));
  }

  // ---- layout mutation ----------------------------------------------------

  TCPageLayout get _lay => state.layout;

  void setPage(int i) {
    final TCPageLayout l = _lay;
    l.pageIdx = i;
    _persist(state.activeId);
    _update(state.copyWith(layouts: <String, TCPageLayout>{...state.layouts, state.activeId: l}));
  }

  void addPage() {
    final TCPageLayout l = _lay;
    l.addPage();
    _persist(state.activeId);
    _update(state.copyWith(layouts: <String, TCPageLayout>{...state.layouts, state.activeId: l}));
  }

  void removePage(int i) {
    final TCPageLayout l = _lay;
    if (!l.removePage(i)) return;
    _persist(state.activeId);
    _update(state.copyWith(layouts: <String, TCPageLayout>{...state.layouts, state.activeId: l}));
  }

  void pin(String key, int page) {
    final TCPageLayout l = _lay;
    if (page >= l.pages.length) return;
    l.pages[0].pin(key);
    l.pages[page].hide(key);
    l.pages[page].restore(key);
    _persist(state.activeId);
    _update(state.copyWith(layouts: <String, TCPageLayout>{...state.layouts, state.activeId: l}));
  }

  void unpin(String key, int page) {
    final TCPageLayout l = _lay;
    if (page >= l.pages.length) return;
    l.pages[0].unpin(key);
    _persist(state.activeId);
    _update(state.copyWith(layouts: <String, TCPageLayout>{...state.layouts, state.activeId: l}));
  }

  void hide(String key, int page) {
    final TCPageLayout l = _lay;
    if (page >= l.pages.length) return;
    l.pages[page].hide(key);
    _persist(state.activeId);
    _update(state.copyWith(layouts: <String, TCPageLayout>{...state.layouts, state.activeId: l}));
  }

  void restore(String key, int page) {
    final TCPageLayout l = _lay;
    if (page >= l.pages.length) return;
    l.pages[page].restore(key);
    _persist(state.activeId);
    _update(state.copyWith(layouts: <String, TCPageLayout>{...state.layouts, state.activeId: l}));
  }

  /// Drag-and-drop landing: move [key] to [toPage] at [index].
  void moveWidget(String key, int fromPage, int toPage, int index) {
    final TCPageLayout l = _lay;
    if (fromPage < 0 || fromPage >= l.pages.length) return;
    if (toPage < 0 || toPage >= l.pages.length) return;
    l.pages[fromPage].widgets.remove(key);
    l.pages[fromPage].hidden.remove(key);
    final List<String> dest = l.pages[toPage].widgets;
    final int i = index.clamp(0, dest.length);
    dest.insert(i, key);
    _persist(state.activeId);
    _update(state.copyWith(layouts: <String, TCPageLayout>{...state.layouts, state.activeId: l}));
  }

  /// Moves the widget one slot up / down inside its page (drag fallback).
  void nudge(String key, int page, int delta) {
    final TCPageLayout l = _lay;
    if (page < 0 || page >= l.pages.length) return;
    final List<String> w = l.pages[page].widgets;
    final int i = w.indexOf(key);
    final int j = i + delta;
    if (i < 0 || j < 0 || j >= w.length) return;
    w.insert(j, w.removeAt(i));
    _persist(state.activeId);
    _update(state.copyWith(layouts: <String, TCPageLayout>{...state.layouts, state.activeId: l}));
  }

  int hiddenCount() => _lay.allHidden.length;

  // ---- create / edit workspace (jsx:2.5) ----------------------------------

  /// Returns null on success, or the validation message.
  String? saveWorkspace({
    required String id,
    required String name,
    required List<String> feats,
    required List<String> sums,
  }) {
    if (name.trim().isEmpty) return 'Give the workspace a name';
    if (sums.isEmpty) return 'Pick at least one money card';
    final TCWorkspace ws = TCWorkspace(
      id: id,
      name: name.trim(),
      builtin: false,
      feats: feats,
      sums: sums,
    );
    final List<TCWorkspace> next = List<TCWorkspace>.of(state.custom);
    final int i = next.indexWhere((TCWorkspace w) => w.id == id);
    if (i >= 0) {
      next[i] = ws;
    } else {
      next.add(ws);
    }
    final Map<String, TCPageLayout> layouts = <String, TCPageLayout>{
      ...state.layouts,
      id: tcDefaultLayout(
        pageOne: <String>['newEntry', ...feats],
        pageTwo: const <String>['team', 'activity'],
      ),
    };
    _update(
      state.copyWith(custom: next, layouts: layouts, activeId: id),
    );
    ref.read(localStorageProvider)?.activeWorkspace = id;
    return null;
  }

  void deleteWorkspace(String id) {
    final TCWorkspace? w = state.custom
        .where((TCWorkspace x) => x.id == id)
        .firstOrNull;
    if (w == null || w.builtin) return;
    final List<TCWorkspace> next =
        state.custom.where((TCWorkspace x) => x.id != id).toList();
    final Map<String, TCPageLayout> layouts =
        Map<String, TCPageLayout>.of(state.layouts)..remove(id);
    _update(
      state.copyWith(
        custom: next,
        layouts: layouts,
        activeId: state.activeId == id ? 'def' : state.activeId,
      ),
    );
  }
}

final NotifierProvider<WorkspaceNotifier, WorkspaceState> workspaceProvider =
    NotifierProvider<WorkspaceNotifier, WorkspaceState>(WorkspaceNotifier.new);

/// Feature keys a workspace offers, for the create/edit workspace sheet.
final Provider<List<TCFlowConfig>> flowConfigsProvider =
    Provider<List<TCFlowConfig>>(
      (Ref ref) => ref.watch(repositoryProvider).flowConfigs(),
    );