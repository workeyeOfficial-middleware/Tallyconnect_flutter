// Liquid Glass surfaces - exact port of .glass (css:26-27), .tabbar.glass
// (css:365-366), .cmenu.glass (css:360-361), .sheet/.drawer (css:170,174),
// .hpanel (css:415-416), .hero (css:116,439-440), .tap (css:28-31),
// .pill (css:130-131), .ico (css:40-43).
//
// Every surface keeps the wallpaper visible: real BackdropFilter blur +
// saturate, a translucent --gt fill, a 155deg sheen, and the prototype's
// inset highlights + navy shadows.
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'tc_colors.dart';
import 'tc_icons.dart';
import 'tc_theme_engine.dart';

/// Glass density presets matching `.g20` ... `.g100` (css:7).
enum TCGlassLevel {
  g20(20),
  g30(30),
  g40(40),
  g50(50),
  g60(60),
  g70(70),
  g80(80),
  g90(90),
  g100(100);

  const TCGlassLevel(this.g);
  final int g;

  static TCGlassLevel fromInt(int v) => TCGlassLevel.values.firstWhere(
    (TCGlassLevel e) => e.g == v,
    orElse: () => TCGlassLevel.g60,
  );
}

/// Which prototype surface to imitate. Each variant carries its own blur,
/// fill and border recipe.
enum TCGlassStyle {
  /// `.glass` - blur(26px) saturate(185%), 22px radius.
  standard,

  /// `.tabbar.glass` - blur(6px) saturate(210%) brightness(1.06).
  bar,

  /// `.cmenu.glass` - blur(7px) saturate(230%) brightness(1.08) contrast(1.03).
  menu,

  /// `.sheet.hpanel` - blur(10px) saturate(220%) brightness(1.06).
  panel,

  /// `.hero` - blur(22px) saturate(180%) over an accent wash.
  hero,
}

/// The core Liquid Glass surface.
class TCGlass extends StatelessWidget {
  const TCGlass({
    super.key,
    required this.child,
    this.style = TCGlassStyle.standard,
    this.level,
    this.radius = 22,
    this.padding,
    this.margin,
    this.gb = 0,
    this.opacity = 1,
    this.onTap,
    this.onLongPress,
    this.width,
    this.height,
    this.elevated = true,
    this.gradient,
    this.borderOverride,
  });

  final Widget child;
  final TCGlassStyle style;

  /// Overrides the theme's `--g` (css:7).
  final int? level;
  final double radius;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;

  /// `.glass` `--gb` extra tint (css:26).
  final double gb;
  final double opacity;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final double? width;
  final double? height;

  /// false drops the outer drop shadow (used for stacked/nested glass).
  final bool elevated;

  /// Replaces the sheen ::before (used by `.tabbar` and `.cmenu`).
  final Gradient? gradient;
  final Border? borderOverride;

  @override
  Widget build(BuildContext context) {
    final TCTheme t = TCScope.of(context);
    final double g = (level ?? t.glass).toDouble();
    final Color gt = t.gtColor;

    // .glass: rgba(var(--gt), calc(var(--g) * .9 + .06 + var(--gb,0)))
    final double fillAlpha = g * .9 + .06 + gb;

    final BorderRadius br = BorderRadius.circular(radius);
    final Color acc = t.acc;

    Widget surface;
    switch (style) {
      case TCGlassStyle.standard:
        surface = Container(
          decoration: BoxDecoration(
            color: gt.withValues(alpha: fillAlpha),
            borderRadius: br,
            border: Border.all(
              color: const Color(0xFFFFFFFF).withValues(alpha: .8),
              width: 1,
            ),
            boxShadow: <BoxShadow>[
              if (elevated) ...<BoxShadow>[
                BoxShadow(
                  color: tcNavyAlpha(.24),
                  blurRadius: 34,
                  offset: const Offset(0, 14),
                  spreadRadius: -16,
                ),
                BoxShadow(
                  color: tcNavyAlpha(.05),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
              // inset 0 -1px 0 rgba(27,45,91,.05)
              const BoxShadow(
                color: Color(0x0D1B2D5B),
                blurRadius: 0,
                offset: Offset(0, 1),
              ),
              // inset 0 1px 0 rgba(255,255,255,.95)
              const BoxShadow(
                color: Color(0xF2FFFFFF),
                blurRadius: 0,
                offset: Offset(0, -1),
              ),
            ],
          ),
          child: child,
        );
      case TCGlassStyle.bar:
        surface = Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: <Color>[
                const Color(0xFFFFFFFF).withValues(alpha: .18),
                const Color(0xFFFFFFFF).withValues(alpha: .04),
              ],
            ),
            borderRadius: br,
            border: Border.all(
              color: const Color(0xFFFFFFFF).withValues(alpha: .58),
              width: 1,
            ),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: const Color(0xFFFFFFFF).withValues(alpha: .9),
                blurRadius: 0,
                offset: const Offset(0, -1),
              ),
              BoxShadow(
                color: const Color(0xFFFFFFFF).withValues(alpha: .28),
                blurRadius: 0,
                offset: const Offset(0, 1),
              ),
              BoxShadow(
                color: const Color(0xFFFFFFFF).withValues(alpha: .6),
                blurRadius: 18,
                offset: const Offset(0, 10),
                spreadRadius: -12,
              ),
              BoxShadow(
                color: tcNavyAlpha(.18),
                blurRadius: 18,
                offset: const Offset(0, -12),
                spreadRadius: -14,
              ),
              if (elevated)
                BoxShadow(
                  color: tcNavyAlpha(.35),
                  blurRadius: 30,
                  offset: const Offset(0, 16),
                  spreadRadius: -18,
                ),
            ],
          ),
          child: child,
        );
      case TCGlassStyle.menu:
        surface = Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: <Color>[
                Color(0x4DFFFFFF),
                Color(0x0FFFFFFF),
                Color(0x24FFFFFF),
              ],
              stops: <double>[0, .45, 1],
            ),
            borderRadius: br,
            border: Border.all(
              color: const Color(0xFFFFFFFF).withValues(alpha: .62),
              width: 1,
            ),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Color(0xFFFFFFFF).withValues(alpha: .95),
                blurRadius: 0,
                offset: Offset(0, -1),
              ),
              BoxShadow(
                color: Color(0xFFFFFFFF).withValues(alpha: .35),
                blurRadius: 0,
                offset: Offset(0, 1),
              ),
              BoxShadow(
                color: const Color(0xFFFFFFFF).withValues(alpha: .7),
                blurRadius: 22,
                offset: const Offset(0, 14),
                spreadRadius: -14,
              ),
              BoxShadow(
                color: tcNavyAlpha(.22),
                blurRadius: 24,
                offset: const Offset(0, -16),
                spreadRadius: -16,
              ),
              if (elevated)
                BoxShadow(
                  color: tcNavyAlpha(.45),
                  blurRadius: 44,
                  offset: const Offset(0, 24),
                  spreadRadius: -18,
                ),
            ],
          ),
          child: child,
        );
      case TCGlassStyle.panel:
        surface = Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: <Color>[
                Color(0x57FFFFFF),
                Color(0x1AFFFFFF),
                Color(0x33FFFFFF),
              ],
              stops: <double>[0, .45, 1],
            ),
            borderRadius: br,
            border: Border.all(
              color: const Color(0xFFFFFFFF).withValues(alpha: .62),
              width: 1,
            ),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Color(0xFFFFFFFF).withValues(alpha: .95),
                blurRadius: 0,
                offset: Offset(0, -1),
              ),
              BoxShadow(
                color: const Color(0xFFFFFFFF).withValues(alpha: .7),
                blurRadius: 22,
                offset: const Offset(0, 14),
                spreadRadius: -14,
              ),
              if (elevated)
                BoxShadow(
                  color: tcNavyAlpha(.45),
                  blurRadius: 44,
                  offset: const Offset(0, 24),
                  spreadRadius: -18,
                ),
            ],
          ),
          child: child,
        );
      case TCGlassStyle.hero:
        surface = Container(
          decoration: BoxDecoration(
            // .hero (css:439) - accent wash, not solid.
            gradient:
                gradient ??
                LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[
                    Color.alphaBlend(
                      acc.withValues(alpha: .20),
                      const Color(0xFFFFFFFF).withValues(alpha: .60),
                    ),
                    Color.alphaBlend(
                      acc.withValues(alpha: .11),
                      const Color(0xFFFFFFFF).withValues(alpha: .38),
                    ),
                  ],
                ),
            borderRadius: br,
            border: Border.all(
              color: const Color(0xFFFFFFFF).withValues(alpha: .82),
              width: 1,
            ),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Color(0xFFFFFFFF).withValues(alpha: .95),
                blurRadius: 0,
                offset: Offset(0, -1),
              ),
              BoxShadow(
                color: acc.withValues(alpha: .34),
                blurRadius: 26,
                offset: const Offset(0, -12),
                spreadRadius: -16,
              ),
              if (elevated)
                BoxShadow(
                  color: acc.withValues(alpha: .42),
                  blurRadius: 38,
                  offset: const Offset(0, 20),
                  spreadRadius: -20,
                ),
            ],
          ),
          child: child,
        );
    }

    Widget out = surface;

    // The 155deg sheen ::before (css:27 / 366 / 361 / 440 / 131).
    final Gradient sheen =
        gradient ??
        _standardSheen(
          const Color(0xFFFFFFFF).withValues(alpha: .65),
          const Color(0xFFC4D0F6).withValues(alpha: .22),
        );

    out = Stack(
      children: <Widget>[
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(borderRadius: br, gradient: sheen),
          ),
        ),
        out,
      ],
    );

    out = ClipRRect(
      borderRadius: br,
      child: BackdropFilter(
        filter: _blurFilter(style),
        child: _colorGrade(_sat(style), _bri(style), _con(style), out),
      ),
    );

    if (padding != null) out = Padding(padding: padding!, child: out);
    if (onTap != null || onLongPress != null) out = _tapWrap(br, out);
    if (width != null || height != null) {
      out = SizedBox(width: width, height: height, child: out);
    }
    if (margin != null) out = Padding(padding: margin!, child: out);
    if (opacity != 1) out = Opacity(opacity: opacity, child: out);
    return out;
  }

  static ui.ImageFilter _blurFilter(TCGlassStyle style) =>
      ui.ImageFilter.blur(sigmaX: _sigma(style), sigmaY: _sigma(style));

  static double _sigma(TCGlassStyle style) {
    switch (style) {
      case TCGlassStyle.standard:
        return 26;
      case TCGlassStyle.bar:
        return 6;
      case TCGlassStyle.menu:
        return 7;
      case TCGlassStyle.panel:
        return 10;
      case TCGlassStyle.hero:
        return 22;
    }
  }

  static double _sat(TCGlassStyle style) {
    switch (style) {
      case TCGlassStyle.standard:
        return 1.85;
      case TCGlassStyle.bar:
        return 2.10;
      case TCGlassStyle.menu:
        return 2.30;
      case TCGlassStyle.panel:
        return 2.20;
      case TCGlassStyle.hero:
        return 1.80;
    }
  }

  static double _bri(TCGlassStyle style) {
    switch (style) {
      case TCGlassStyle.standard:
        return 1;
      case TCGlassStyle.bar:
        return 1.06;
      case TCGlassStyle.menu:
        return 1.08;
      case TCGlassStyle.panel:
        return 1.06;
      case TCGlassStyle.hero:
        return 1;
    }
  }

  static double _con(TCGlassStyle style) {
    switch (style) {
      case TCGlassStyle.menu:
        return 1.03;
      default:
        return 1;
    }
  }

  static Gradient _standardSheen(Color a, Color b) => LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: <Color>[a, const Color(0x00000000), const Color(0x00000000), b],
    stops: const <double>[0, .36, .72, 1],
  );

  /// CSS `saturate() brightness() contrast()` as a colour matrix layered over
  /// the blurred backdrop - the `backdrop-filter` shorthand chain.
  static Widget _colorGrade(double sat, double bri, double con, Widget child) {
    if (sat == 1 && bri == 1 && con == 1) return child;
    final double gain = con * bri;
    final double off = (1 - con) / 2 * bri;
    return ColorFiltered(
      colorFilter: ui.ColorFilter.matrix(<double>[
        // saturate(s) from the CSS/SVG filter spec
        (0.213 + 0.787 * sat) * gain,
        (0.715 - 0.715 * sat) * gain,
        (0.072 - 0.072 * sat) * gain,
        0,
        off,
        (0.213 - 0.213 * sat) * gain,
        (0.715 + 0.285 * sat) * gain,
        (0.072 - 0.072 * sat) * gain,
        0,
        off,
        (0.213 - 0.213 * sat) * gain,
        (0.715 - 0.715 * sat) * gain,
        (0.072 + 0.928 * sat) * gain,
        0,
        off,
        0, 0, 0, 1, 0,
      ]),
      child: child,
    );
  }

  Widget _tapWrap(BorderRadius br, Widget child) => _TapFeedback(
    borderRadius: br,
    onTap: onTap,
    onLongPress: onLongPress,
    child: child,
  );
}

/// Pressable wrapper reproducing `.tap:active` (scale .955 + a white sheen
/// fading in via ::after).
class _TapFeedback extends StatefulWidget {
  const _TapFeedback({
    required this.child,
    required this.borderRadius,
    this.onTap,
    this.onLongPress,
  });

  final Widget child;
  final BorderRadius borderRadius;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;

  @override
  State<_TapFeedback> createState() => _TapFeedbackState();
}

class _TapFeedbackState extends State<_TapFeedback> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: widget.onTap == null
          ? null
          : (_) => setState(() => _down = true),
      onTapUp: widget.onTap == null
          ? null
          : (_) => setState(() => _down = false),
      onTapCancel: widget.onTap == null
          ? null
          : () => setState(() => _down = false),
      onTap: widget.onTap,
      onLongPress: widget.onLongPress,
      child: AnimatedScale(
        scale: _down ? .955 : 1,
        duration: Duration(milliseconds: _down ? 120 : 380),
        curve: _down ? Curves.easeOut : const Cubic(0.3, 1.45, 0.5, 1),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 280),
          decoration: BoxDecoration(
            borderRadius: widget.borderRadius,
            gradient: _down
                ? const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: <Color>[
                      Color(0x8CFFFFFF),
                      Color(0x1FFFFFFF),
                      Color(0x42FFFFFF),
                    ],
                    stops: <double>[0, .45, 1],
                  )
                : null,
            boxShadow: _down
                ? <BoxShadow>[
                    BoxShadow(
                      color: const Color(0xFFFFFFFF).withValues(alpha: .85),
                      blurRadius: 0,
                      offset: const Offset(0, -1),
                    ),
                    BoxShadow(
                      color: const Color(0xFFFFFFFF).withValues(alpha: .8),
                      blurRadius: 0,
                      offset: const Offset(0, 1),
                    ),
                    BoxShadow(
                      color: tcNavyAlpha(.2),
                      blurRadius: 16,
                      offset: const Offset(0, -8),
                      spreadRadius: -10,
                    ),
                  ]
                : null,
          ),
          child: widget.child,
        ),
      ),
    );
  }
}

/// The active-tab pill (`.pill`, css:130-131).
class TCPill extends StatelessWidget {
  const TCPill({
    super.key,
    required this.width,
    this.height = 56,
    this.radius = 28,
  });

  final double width;
  final double height;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final TCTheme t = TCScope.of(context);
    final Color acc = t.acc;
    final BorderRadius br = BorderRadius.circular(radius);
    return BackdropFilter(
      filter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10),
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          borderRadius: br,
          gradient: const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: <Color>[
              Color(0x75FFFFFF),
              Color(0x1FFFFFFF),
              Color(0x38FFFFFF),
            ],
            stops: <double>[0, .6, 1],
          ),
          border: Border.all(
            color: const Color(0xFFFFFFFF).withValues(alpha: .95),
            width: 1,
          ),
          boxShadow: <BoxShadow>[
            const BoxShadow(
              color: Color(0xFFFFFFFF),
              blurRadius: 0,
              offset: Offset(0, -1),
            ),
            BoxShadow(
              color: acc.withValues(alpha: .16),
              blurRadius: 14,
              offset: const Offset(0, -8),
              spreadRadius: -8,
            ),
            BoxShadow(
              color: acc.withValues(alpha: .14),
              blurRadius: 1,
              offset: Offset.zero,
              spreadRadius: .5,
            ),
            BoxShadow(
              color: tcNavyAlpha(.3),
              blurRadius: 18,
              offset: const Offset(0, 8),
              spreadRadius: -8,
            ),
            // ::after top highlight (css:131)
            const BoxShadow(color: Color(0x00FFFFFF), blurRadius: 0),
          ],
        ),
        child: DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: br,
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: <Color>[Color(0xE6FFFFFF), Color(0x00FFFFFF)],
              stops: <double>[0, 1],
            ),
          ),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: width * .14),
            child: Align(
              alignment: Alignment.topCenter,
              child: FractionallySizedBox(
                heightFactor: .4,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    gradient: const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: <Color>[Color(0xE6FFFFFF), Color(0x00FFFFFF)],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// The 56x56 rounded icon chip (`.ico`, css:40-43).
class TCIconChip extends StatelessWidget {
  const TCIconChip({
    super.key,
    required this.color,
    required this.child,
    this.size = 56,
    this.margin = 7,
    this.radius = 18,
  });

  final Color color;
  final Widget child;
  final double size;
  final double margin;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[Color(0xFAFFFFFF), Color(0xA8FFFFFF)],
        ),
        border: Border.all(
          color: const Color(0xFFFFFFFF).withValues(alpha: .95),
          width: 1,
        ),
        boxShadow: <BoxShadow>[
          const BoxShadow(
            color: Color(0xFFFFFFFF),
            blurRadius: 0,
            offset: Offset(0, -1),
          ),
          BoxShadow(
            color: tcNavyAlpha(.32),
            blurRadius: 18,
            offset: const Offset(0, 8),
            spreadRadius: -9,
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(margin),
        child: Center(child: child),
      ),
    );
  }
}

/// [TCIconSize] is re-exported from `tc_icons.dart` so this file can size
/// icons without duplicating the ladder.

/// `.av` - the gradient circle avatar (css:101-103).
class TCAvatar extends StatelessWidget {
  const TCAvatar({super.key, required this.label, this.size = TCAvatarSize.md});

  final String label;
  final TCAvatarSize size;

  @override
  Widget build(BuildContext context) {
    final TCTheme t = TCScope.of(context);
    return Container(
      width: size.px,
      height: size.px,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[t.navy2, t.navy],
        ),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: const Color(0xFFFFFFFF).withValues(alpha: .3),
            blurRadius: 0,
            offset: const Offset(0, -1),
          ),
        ],
      ),
      alignment: Alignment.center,
      child: Text(label, style: size.style),
    );
  }
}

enum TCAvatarSize {
  sm(34, 14),
  md(40, 16),
  lg(58, 22);

  const TCAvatarSize(this.px, this.fs);
  final double px;
  final double fs;

  TextStyle get style => TextStyle(
    fontSize: fs,
    fontWeight: FontWeight.w800,
    color: Colors.white,
    fontFamilyFallback: const <String>['Figtree'],
    height: 1,
  );
}

/// Repaints on theme change; cheap stand-in for CSS `currentColor` inheritance.
Color tcSemantic(BuildContext context, String key) {
  final TCTheme t = TCScope.of(context);
  switch (key) {
    case 'sales':
      return t.cSales;
    case 'purchase':
      return t.cPurchase;
    case 'receipt':
      return t.cReceipt;
    case 'payment':
      return t.cPayment;
    case 'journal':
      return t.cJournal;
    case 'contra':
      return t.cContra;
    case 'items':
      return t.cItems;
    case 'party':
      return t.cParty;
    case 'vouchers':
      return t.cVouchers;
    case 'outstanding':
      return t.cOutstanding;
    case 'reports':
      return t.cReports;
    case 'settings':
      return t.cSettings;
    case 'team':
      return t.cTeam;
    case 'activity':
      return t.cActivity;
    case 'navy':
      return t.navy;
    case 'acc':
    default:
      return t.acc;
  }
}
