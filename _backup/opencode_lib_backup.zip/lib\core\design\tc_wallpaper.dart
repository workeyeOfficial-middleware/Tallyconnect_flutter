// Wallpaper - renders the CSS `--wall` layers with the exact radial/conic
// streaks and the `drift 16s ease-in-out infinite alternate` orbs (css:9,330-338).
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'tc_colors.dart';
import 'tc_theme_engine.dart';

/// `.orb` - blur(36px), opacity .7, drift 16s (css:9).
class TCOrb extends StatelessWidget {
  const TCOrb({
    super.key,
    required this.color,
    required this.size,
    this.left,
    this.top,
    this.right,
    this.bottom,
    this.delay = 0,
  });

  final Color color;
  final double size;
  final double? left;
  final double? top;
  final double? right;
  final double? bottom;
  final double delay;

  @override
  Widget build(BuildContext context) {
    final Widget orb = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 36, sigmaY: 36),
        child: const SizedBox.expand(),
      ),
    );
    return Positioned(
      left: left,
      top: top,
      right: right,
      bottom: bottom,
      child: _Drift(
        delay: delay,
        child: Opacity(opacity: .7, child: orb),
      ),
    );
  }
}

class _Drift extends StatefulWidget {
  const _Drift({required this.child, this.delay = 0});
  final Widget child;
  final double delay;

  @override
  State<_Drift> createState() => _DriftState();
}

class _DriftState extends State<_Drift> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 16),
  )..repeat(reverse: true);
  late final Animation<Offset> _o = Tween<Offset>(
    begin: Offset.zero,
    end: const Offset(26 / 500, 38 / 500),
  ).animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  late final Animation<double> _s = Tween<double>(
    begin: 1,
    end: 1.14,
  ).animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));

  @override
  void initState() {
    super.initState();
    if (widget.delay != 0) {
      Future<void>.delayed(
        Duration(milliseconds: (widget.delay * 1000).round()),
        () {
          if (mounted) _c.repeat(reverse: true);
        },
      );
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => SlideTransition(
    position: _o,
    child: ScaleTransition(scale: _s, child: widget.child),
  );
}

/// Wallpaper painter - renders all layers of [TCWallSpec].
class TCWallpaperPainter extends CustomPainter {
  const TCWallpaperPainter(this.t);
  final TCTheme t;

  @override
  void paint(Canvas canvas, Size size) {
    final Rect r = Offset.zero & size;
    final TCWallSpec w = t.wall;

    // linear-gradient base (css: --wall last layer order)
    if (w.linear != null) {
      final Alignment a1 = _angle(w.linear!.angleDeg, true);
      final Alignment a2 = _angle(w.linear!.angleDeg, false);
      canvas.drawRect(
        r,
        Paint()
          ..shader = LinearGradient(
            begin: a1,
            end: a2,
            colors: <Color>[w.linear!.color1, w.linear!.color2],
          ).createShader(r),
      );
    }

    // conic
    if (w.conic != null) {
      final Offset c = Offset(
        r.left + r.width * w.conic!.cx,
        r.top + r.height * w.conic!.cy,
      );
      final SweepGradient sg = SweepGradient(
        startAngle: math.pi / 180 * (w.conic!.fromDeg),
        endAngle: math.pi / 180 * (w.conic!.fromDeg + 360),
        colors: w.conic!.colors.length == 1
            ? <Color>[w.conic!.colors.first, w.conic!.colors.first]
            : w.conic!.colors,
      );
      // SweepGradient.createShader pivots on the rect centre, so grow a rect
      // centred on `c` that still covers the whole canvas.
      final Rect sr = Rect.fromLTRB(
        math.min(0, 2 * c.dx),
        math.min(0, 2 * c.dy),
        math.max(r.width, 2 * c.dx),
        math.max(r.height, 2 * c.dy),
      );
      canvas.drawRect(sr, Paint()..shader = sg.createShader(sr));
    }

    // radials - CSS order is top-to-bottom; paint in that order (earlier covers).
    for (final TCWallLayer l in w.radials) {
      final Rect lr = Rect.fromCenter(
        center: Offset(r.width * l.cx, r.height * l.cy),
        width: r.width * l.rx * 2,
        height: r.height * l.ry * 2,
      );
      final List<Color> cols = <Color>[];
      final List<double> st = <double>[];
      for (int i = 0; i < l.stops.length; i++) {
        cols.add(l.color.withValues(alpha: i == 0 ? 1 : 0));
        st.add(l.stops[i]);
        if (i < l.stops.length - 1) {
          // fade to transparent
          cols.add(l.color.withValues(alpha: 0));
          st.add(l.stops[i + 1] - .0001);
        }
      }
      canvas.drawOval(
        lr,
        Paint()
          ..shader = RadialGradient(
            center: Alignment.center,
            radius: .5,
            colors: cols,
            stops: st,
          ).createShader(lr),
      );
    }

    // streaks: repeating-linear-gradient -> simple stripes (low frequency)
    for (final TCWallStreak s in w.streaks) {
      canvas.save();
      canvas.translate(size.width / 2, size.height / 2);
      canvas.rotate(math.pi / 180 * s.angleDeg);
      final double wStripe = math.max(size.width, size.height) * (s.size / 100);
      final Rect sr = Rect.fromCenter(
        center: Offset.zero,
        width: wStripe * 10,
        height: wStripe * 10,
      );
      final List<Color> c = <Color>[];
      final List<double> st = <double>[];
      for (final TCStreakStop sp in s.stops) {
        c.add(sp.color);
        st.add(sp.start / 100);
      }
      canvas.drawRect(
        sr,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment(-1, 0),
            end: Alignment(1, 0),
            colors: c,
            stops: st,
          ).createShader(sr),
      );
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant TCWallpaperPainter oldDelegate) =>
      oldDelegate.t != t;

  static Alignment _angle(double deg, bool start) {
    final double d = ((deg % 360) + 360) % 360;
    final Offset v = Offset(
      math.cos(math.pi / 180 * d),
      math.sin(math.pi / 180 * d),
    );
    if (start) return Alignment(-v.dx, -v.dy);
    return Alignment(v.dx, v.dy);
  }
}

/// Background: the CSS `--wall` fill plus the three `.orb`s.
class TCWallpaper extends StatelessWidget {
  const TCWallpaper({super.key, required this.child, this.showOrbs = true});

  final Widget child;
  final bool showOrbs;

  @override
  Widget build(BuildContext context) {
    final TCTheme t = TCScope.of(context);
    return Stack(
      children: <Widget>[
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(color: const Color(0xFFE9EDF7)),
          ),
        ),
        Positioned.fill(child: CustomPaint(painter: TCWallpaperPainter(t))),
        if (showOrbs) ...<Widget>[
          TCOrb(color: t.o1, size: 420, left: -120, top: -80),
          TCOrb(color: t.o2, size: 460, right: -140, top: -60, delay: .4),
          TCOrb(color: t.o3, size: 400, left: 40, bottom: -160, delay: .8),
        ],
        child,
      ],
    );
  }
}
