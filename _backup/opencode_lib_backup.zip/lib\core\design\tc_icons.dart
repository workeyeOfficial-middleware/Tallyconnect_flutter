// Icons - renders the SVG paths from the prototype (`IC` object, jsx:2-70)
// using `flutter_svg`. The style matches `.i` (stroke 1.9, round/round).
// The `.ico` chip is `TCIconChip` in tc_glass.dart.
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'tc_icon_paths.dart';
import 'tc_theme_engine.dart';

/// `.i` size ladder (css:37-39). Lives here so `tc_glass` and `tc_buttons`
/// can both use it without a circular import.
enum TCIconSize {
  /// `.i.s` - 18
  s(18, 2.2),

  /// `.i.xs` - 15
  xs(15, 2.2),

  /// `.i` - 22
  m(22, 1.9),

  /// `.i.l` - 28
  l(28, 1.8),

  /// `.i.xl` - 34
  xl(34, 1.7);

  const TCIconSize(this.px, this.stroke);
  final double px;
  final double stroke;
}

/// Available icon keys (the exact set in the prototype IC object).
const Set<String> tcIconKeys = <String>{
  'home',
  'rupeeC',
  'team',
  'activity',
  'chart',
  'bag',
  'cart',
  'person',
  'box',
  'gear',
  'receipt',
  'in',
  'out',
  'book',
  'swap',
  'plus',
  'minus',
  'chevR',
  'chevL',
  'chevD',
  'chevU',
  'arrow',
  'menu',
  'search',
  'bell',
  'close',
  'check',
  'building',
  'sync',
  'trash',
  'lock',
  'mail',
  'eye',
  'eyeOff',
  'key',
  'help',
  'phone',
  'cash',
  'bank',
  'upi',
  'cheque',
  'more',
  'dots',
  'calendar',
  'file',
  'share',
  'download',
  'gift',
  'card',
  'grid',
  'sort',
  'edit',
  'send',
  'chat',
  'trophy',
  'pie',
  'userPlus',
  'scan',
  'info',
  'logout',
  'note',
  'laptop',
  'hash',
  'star',
  'clock',
  'shield',
  'xCircle',
  'pin',
  'move',
  'open',
  'drop',
  'upload',
};

/// Renders a single prototype icon at a given size and color.
/// Falls back to a question mark if the key is unknown.
class TCICon extends StatelessWidget {
  const TCICon({
    super.key,
    required this.k,
    this.size = 22,
    this.color,
    this.strokeWidth = 1.9,
    this.mirrored = false,
    this.fat = false,
  });

  final String k;
  final double size;
  final Color? color;
  final double strokeWidth;
  final bool mirrored;
  final bool fat;

  @override
  Widget build(BuildContext context) {
    final TCTheme t = TCScope.of(context);
    final Color c = color ?? t.ink;
    final String? path = tcIconPaths[k];
    if (path == null) {
      return SizedBox(
        width: size,
        height: size,
        child: Icon(Icons.help_outline, size: size * .8, color: c),
      );
    }
    Widget svg = SvgPicture.string(
      '<svg width="$size" height="$size" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="$path" fill="none" stroke="#000" stroke-width="${fat ? 3.2 : strokeWidth}" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      width: size,
      height: size,
      colorFilter: ColorFilter.mode(c, BlendMode.srcIn),
    );
    if (mirrored) svg = Transform.flip(flipX: true, child: svg);
    return svg;
  }
}

/// Icon with the `.i` size enum from the CSS.
class TCIconSized extends StatelessWidget {
  const TCIconSized({
    super.key,
    required this.k,
    this.sz = TCIconSize.m,
    this.color,
    this.fat = false,
  });

  final String k;
  final TCIconSize sz;
  final Color? color;
  final bool fat;

  @override
  Widget build(BuildContext context) =>
      TCICon(k: k, size: sz.px, color: color, strokeWidth: sz.stroke, fat: fat);
}
