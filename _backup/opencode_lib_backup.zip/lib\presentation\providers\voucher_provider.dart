// Vouchers hub + list + entry detail state, including the simulated sync flip
// (jsx:8.15) and the retry flow (jsx:8.2).
library;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/models/voucher_model.dart';
import 'app_providers.dart';

final Provider<List<TCVoucher>> allVouchersProvider = Provider<List<TCVoucher>>(
  (Ref ref) => ref.watch(repositoryProvider).vouchers(),
);

/// `vList` params (jsx:2.9): which kinds, which period.
class VoucherListState {
  const VoucherListState({
    this.kinds = const <String>[],
    this.period = 'all',
    this.limit = 0,
    this.selectedId = '',
  });

  final List<String> kinds;
  final String period;
  final int limit;
  final String selectedId;

  String get title => switch (kinds.length) {
    1 => switch (kinds.first) {
      TCKinds.receipt => 'Receipts',
      TCKinds.payment => 'Payments',
      TCKinds.sales => 'Sales',
      TCKinds.purchase => 'Purchases',
      TCKinds.journal => 'Adjustments',
      _ => 'Vouchers',
    },
    _ => 'Vouchers',
  };

  VoucherListState copyWith({
    List<String>? kinds,
    String? period,
    int? limit,
    String? selectedId,
  }) => VoucherListState(
    kinds: kinds ?? this.kinds,
    period: period ?? this.period,
    limit: limit ?? this.limit,
    selectedId: selectedId ?? this.selectedId,
  );
}

class VoucherListNotifier extends Notifier<VoucherListState> {
  @override
  VoucherListState build() => const VoucherListState();

  /// Entry point for `go('vList', {...})` - `mode` is one of
  /// recent / receipt / payment / sales / purchase / journal / all.
  void open(String? mode, Map<String, String> extra) {
    final List<String> kinds = switch (mode) {
      'receipt' => <String>[TCKinds.receipt],
      'payment' => <String>[TCKinds.payment],
      'sales' => <String>[TCKinds.sales],
      'purchase' => <String>[TCKinds.purchase],
      'journal' || 'adjust' => <String>[TCKinds.journal],
      _ => <String>[],
    };
    final String filter = extra['vFilter'] ?? '';
    state = VoucherListState(
      kinds: kinds.isNotEmpty ? kinds : <String>[if (filter.isNotEmpty) filter],
      period: extra['vPeriod'] ?? 'all',
    );
  }

  void setPeriod(String p) => state = state.copyWith(period: p);
  void select(String id) => state = state.copyWith(selectedId: id);

  List<TCVoucher> filtered() {
    final List<TCVoucher> all = ref.read(allVouchersProvider);
    List<TCVoucher> out = all
        .where(
          (TCVoucher v) => state.kinds.isEmpty || state.kinds.contains(v.kind),
        )
        .toList();
    if (state.limit > 0 && out.length > state.limit) {
      out = out.sublist(0, state.limit);
    }
    return out;
  }
}

final NotifierProvider<VoucherListNotifier, VoucherListState>
voucherListProvider =
    NotifierProvider<VoucherListNotifier, VoucherListState>(
      VoucherListNotifier.new,
    );

/// Mutable voucher operations. Separate from [voucherListProvider] so a save
/// does not clobber the list's own filter state.
class VoucherNotifier extends Notifier<List<TCVoucher>> {
  @override
  List<TCVoucher> build() => ref.watch(allVouchersProvider);

  TCVoucher? byId(String id) {
    for (final TCVoucher v in state) {
      if (v.id == id) return v;
    }
    return null;
  }

  /// jsx:8.2 - save as a `wait` entry, then flip to `ok` after 5s.
  Future<void> save(TCVoucher v) async {
    await ref.read(repositoryProvider).saveVoucher(v);
    _refresh();
    if (v.id.isEmpty) return;
    Future<void>.delayed(const Duration(seconds: 5), () async {
      await ref.read(repositoryProvider).markSynced(v.id);
      _refresh();
    });
  }

  Future<void> saveDraft(TCVoucher v) async {
    await ref.read(repositoryProvider).saveDraft(v);
    _refresh();
  }

  Future<void> retry(String id) async {
    final List<TCVoucher> next = <TCVoucher>[
      for (final TCVoucher v in state)
        if (v.id == id)
          v.copyWith(status: TCKinds.statusWait, fresh: true)
        else
          v,
    ];
    _set(next);
    await ref.read(repositoryProvider).retry(id);
    _refresh();
  }

  Future<void> remove(String id) async {
    await ref.read(repositoryProvider).deleteVoucher(id);
    _refresh();
  }

  void _set(List<TCVoucher> next) => state = next;

  void _refresh() => state = <TCVoucher>[...ref.read(allVouchersProvider)];
}

final NotifierProvider<VoucherNotifier, List<TCVoucher>> voucherProvider =
    NotifierProvider<VoucherNotifier, List<TCVoucher>>(VoucherNotifier.new);

/// Single entry for `entryDetail`.
final ProviderFamily<TCVoucher?, String> voucherByIdProvider =
    Provider.family<TCVoucher?, String>(
      (Ref ref, String id) => ref.watch(voucherProvider).firstWhere(
        (TCVoucher v) => v.id == id,
        orElse: () => const TCVoucher(id: '', kind: TCKinds.sales),
      ),
    );

/// Recent slice for the hub's "Recent entries" section (jsx:2.9).
final Provider<List<TCVoucher>> recentVouchersProvider = Provider<List<TCVoucher>>(
  (Ref ref) {
    final List<TCVoucher> all = ref.watch(voucherProvider);
    return all.length <= 6 ? all : all.sublist(0, 6);
  },
);

/// Summed amount per kind - backs the three hub summary cards.
final Provider<Map<String, double>> voucherTotalsProvider =
    Provider<Map<String, double>>((Ref ref) {
      final Map<String, double> out = <String, double>{};
      for (final TCVoucher v in ref.watch(voucherProvider)) {
        out[v.kind] = (out[v.kind] ?? 0) + v.amt;
      }
      return out;
    });