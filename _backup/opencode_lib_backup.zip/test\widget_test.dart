// Smoke tests for the foundation layer: models, storage keys and the router's
// history/direction rules.
library;

import 'package:flutter_test/flutter_test.dart';
import 'package:tallyconnect_ui/core/router/app_router.dart';
import 'package:tallyconnect_ui/core/storage/local_storage.dart';
import 'package:tallyconnect_ui/data/models/core_models.dart';
import 'package:tallyconnect_ui/data/models/notification_model.dart';
import 'package:tallyconnect_ui/data/models/voucher_model.dart';
import 'package:tallyconnect_ui/data/models/workspace_model.dart';
import 'package:tallyconnect_ui/data/mock/mock_data.dart';

void main() {
  group('TCVoucher', () {
    test('reads a mock row shape', () {
      final TCVoucher v = TCVoucher.fromMap(<String, dynamic>{
        'id': 'v1',
        'kind': 'sales',
        'party': 'Mehta Electricals',
        'no': 'BILL-0104',
        'amt': 42640,
        'day': 24,
      });
      expect(v.kind, TCKinds.sales);
      expect(v.amt, 42640);
      expect(v.dateLabel, 'day 24');
      expect(v.isSynced, isTrue);
      expect(v.isMoneyIn, isTrue);
    });

    test('item totals add GST', () {
      final TCVoucher v = TCVoucher.fromMap(<String, dynamic>{
        'id': 'x',
        'kind': 'sales',
        'amt': 0,
        'items': <Map<String, dynamic>>[
          <String, dynamic>{'id': 'i1', 'n': 'LED', 'rate': 100, 'qty': 2, 'gst': 18},
        ],
      });
      expect(v.subtotal, 200);
      expect(v.gstTotal, 36);
    });

    test('journal balance requires equal non-zero sides', () {
      const TCVoucher balanced = TCVoucher(
        id: 'j1',
        kind: TCKinds.journal,
        lines: <TCJournalLine>[
          TCJournalLine(
            ledgerId: 'l1',
            name: 'Rent',
            group: 'Indirect',
            amount: 500,
          ),
          TCJournalLine(
            ledgerId: 'l2',
            name: 'Cash',
            group: 'Cash',
            amount: 500,
            side: 'cr',
          ),
        ],
      );
      expect(balanced.balanced, isTrue);
      expect(const TCVoucher(id: 'j2', kind: TCKinds.journal).balanced, isFalse);
    });
  });

  group('TCWorkspace', () {
    test('save is blocked without sums', () {
      const TCWorkspace bad = TCWorkspace(id: 'x', name: 'X');
      expect(bad.isValid, isFalse);
      const TCWorkspace ok = TCWorkspace(
        id: 'y',
        name: 'Y',
        sums: <String>['toGet'],
      );
      expect(ok.isValid, isTrue);
    });

    test('hidden widget is not double counted and restores', () {
      final TCHomePage p = TCHomePage(
        widgets: <String>['a', 'b'],
        hidden: <String>[],
      );
      p.hide('a');
      expect(p.widgets, <String>['b']);
      expect(p.hidden, <String>['a']);
      p.restore('a');
      expect(p.widgets, <String>['b', 'a']);
      expect(p.hidden, isEmpty);
    });

    test('layout refuses to drop the last page', () {
      final TCPageLayout l = TCPageLayout(
        pages: <TCHomePage>[TCHomePage()],
      );
      expect(l.removePage(0), isFalse);
      expect(l.pages.length, 1);
    });
  });

  group('TCNotification', () {
    test('parses both go shapes', () {
      expect(TCNavTarget.parse('team').screen, 'team');
      final TCNavTarget t = TCNavTarget.parse(<dynamic>[
        'vList',
        <String, String>{'vFilter': 'receipt'},
      ]);
      expect(t.screen, 'vList');
      expect(t.extra['vFilter'], 'receipt');
    });

    test('marking read clears unread', () {
      final TCNotification n = TCNotification.fromMap(
        TCMockData.notifications.first,
      );
      expect(n.unread, isTrue);
      expect(n.copyWith(unread: false).unread, isFalse);
    });
  });

  group('TCScreen keys', () {
    test('match the prototype NO_TAB / FLOWLIKE sets', () {
      expect(TCScreens.showsTabBar(TCScreens.login), isFalse);
      expect(TCScreens.showsTabBar(TCScreens.flow), isFalse);
      expect(TCScreens.showsTabBar(TCScreens.home), isTrue);
      expect(TCScreens.isFlowLike(TCScreens.entryDetail), isTrue);
      expect(TCScreens.isFlowLike(TCScreens.home), isFalse);
    });

    test('every tab key is in the all list', () {
      for (final String t in TCScreens.tabs) {
        expect(TCScreens.all.contains(t), isTrue);
        expect(TCScreens.isTab(t), isTrue);
      }
    });
  });

  group('TCLocalStorage keys', () {
    test('are namespaced and workspace-scoped', () {
      expect(LocalStorage.kPages('def'), startsWith('tc-liquid-pages-v2-'));
      expect(LocalStorage.kPages('sd'), isNot(LocalStorage.kPages('def')));
      expect(LocalStorage.kTabOrder, 'tc-liquid-tabs');
      expect(LocalStorage.kCompany, 'tc-company');
      expect(LocalStorage.kWs, 'tc-ws');
    });
  });

  group('TCSum', () {
    test('resolves level and background from the key', () {
      final TCSum s = TCSum.fromMap(<String, dynamic>{
        'k': 'toGet',
        't': 'To get',
        'v': 124530,
        'ic': 'rupee',
        'cls': 'g30',
      });
      expect(s.level, 30);
      expect(s.bgArgb, 0xFFF6E6EB);
    });
  });
}