// Currency formatting - exact port of inr()/inr2() from
// prototype/TallyConnect_App_Source.jsx:73-74.
library;

import 'dart:math' as math;

/// Indian digit grouping with the U+2212 MINUS SIGN used by the prototype.
String inr(num n) {
  n = _toNum(n);
  final bool neg = n < 0;
  final int v = math.max(0, n.abs()).round();
  final String s = v.toString();
  final String last3 = s.length > 3 ? s.substring(s.length - 3) : s;
  final String rest0 = s.length > 3 ? s.substring(0, s.length - 3) : '';
  final String rest = rest0.isEmpty ? '' : _group(rest0);
  return '${neg ? '−' : ''}₹${rest.isEmpty ? last3 : '$rest,$last3'}';
}

/// `inr(528.57)` -> `₹528.57`
String inr2(num n) {
  final String f = _toNum(n).toStringAsFixed(2);
  final List<String> p = f.split('.');
  return '${inr(num.parse(p[0]))}.${p[1]}';
}

/// Two decimals, no grouping - used by "Sold for"/"Still to get" chips.
/// [toAbsolute] drops the minus sign; the default keeps it as U+2212.
String inr2raw(num n, {bool toAbsolute = false}) {
  final double v = toAbsolute ? _toNum(n).abs() : _toNum(n);
  final String f = v.toStringAsFixed(2);
  final List<String> p = f.split('.');
  final bool neg = p[0].startsWith('-');
  final String whole = _group(p[0].replaceFirst('-', ''));
  return '${neg ? '−' : ''}$whole.${p[1]}';
}

/// Compact form used by tight list rows: drops the decimals when whole.
String inrShort(num n) {
  n = _toNum(n);
  final bool whole = (n - n.roundToDouble()).abs() < 0.005;
  return whole ? inr(n) : inr2(n);
}

/// `1234` -> `1,234` (JS \B(?=(\d{2})+(?!\d)) behaviour).
String _group(String digits) {
  final StringBuffer sb = StringBuffer();
  for (int i = 0; i < digits.length; i++) {
    if (i > 0) {
      final int remaining = digits.length - i;
      // insert a comma every 2 digits, but never right after index 0
      if (remaining % 2 == 0) sb.write(',');
    }
    sb.write(digits[i]);
  }
  return sb.toString();
}

double _toNum(Object? v) {
  if (v is num) return v.toDouble();
  if (v is String) return double.tryParse(v) ?? 0;
  return 0;
}

/// Signed variant used by the +/- metric rows.
String inrSigned(num n, {required bool positive}) =>
    positive ? '+${inr(_toNum(n).abs())}' : '−${inr(_toNum(n).abs())}';
