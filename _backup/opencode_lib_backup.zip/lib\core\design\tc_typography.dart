// Typography - exact port of the Figtree type scale in
// prototype/app_styles.css (body:1, .brand:50-52, .h1:53, .sub:54, .h2:55,
// .sec:57, .rt:64, .rs:65, .amt:68-69, .badge:73, .btn:76, .chip:84,
// .seg button:88, .lab:91, .inp:93, .av:101, .tab:132, .pbtn:49).
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'tc_theme_engine.dart';

/// Figtree everywhere - the prototype sets `font-family:'Figtree'`.
TextStyle _f(
  double size,
  double weight, {
  double? height,
  double? ls,
  Color? color,
}) {
  return GoogleFonts.figtree(
    fontSize: size,
    fontWeight: _wt(weight),
    height: height,
    letterSpacing: ls,
    color: color,
    // fontWeight on the style wins; keep the numeric weight for fallbacks.
  ).copyWith(fontWeight: _wt(weight), shadows: <Shadow>[]);
}

FontWeight _wt(double w) {
  if (w >= 800) return FontWeight.w800;
  if (w >= 700) return FontWeight.w700;
  if (w >= 600) return FontWeight.w600;
  if (w >= 500) return FontWeight.w500;
  return FontWeight.w400;
}

/// The complete type scale. Every style is colour-agnostic except where the
/// prototype hard-codes one (`--ink2`, `--ink3`), which resolves from the theme.
class TCTypography {
  TCTypography._(this.t);

  final TCTheme t;

  Color get ink => t.ink;
  Color get ink2 => t.ink2;
  Color get ink3 => t.ink3;

  // body default: 16px / 400, color var(--ink) (css:1,6)
  TextStyle get body => _f(16, 400, height: 1.4, color: ink);

  TextStyle get bodyBold => _f(16, 700, height: 1.4, color: ink);

  // .brand (css:50)
  TextStyle get brand => _f(22, 800, ls: -.02, color: ink);
  TextStyle get brandBig => _f(34, 800, ls: -.025, color: ink);

  // .h1 (css:53)
  TextStyle get h1 => _f(34, 800, height: 1.08, ls: -.025, color: ink);

  // .sub (css:54)
  TextStyle get sub => _f(15.5, 400, height: 1.4, color: ink2);

  // .h2 (css:55)
  TextStyle get h2 => _f(20, 800, ls: -.01, color: ink);

  // .sec (css:57)
  TextStyle get sec =>
      _f(12.5, 800, ls: .07, color: ink3).copyWith(letterSpacing: .07);

  // .rt / .rs (css:64-65)
  TextStyle get rt => _f(16, 700, height: 1.25, color: ink);
  TextStyle get rs => _f(13.5, 400, height: 1.3, color: ink3);

  // .amt (css:68-69) - tabular figures, right aligned
  TextStyle get amt => _f(16, 800, color: ink);
  TextStyle get amtBig => _f(32, 800, ls: -.02, color: ink);

  // .badge (css:73)
  TextStyle get badge => _f(12, 700, color: ink);

  // .btn (css:76)
  TextStyle get btn => _f(16.5, 700, color: ink);

  // .chip (css:84)
  TextStyle get chip => _f(15, 700, color: ink2);

  // .seg button (css:88)
  TextStyle get seg => _f(15, 700, color: ink2);

  // .lab (css:91)
  TextStyle get lab => _f(14.5, 700, color: ink2);

  // .inp (css:93)
  TextStyle get inp => _f(17, 400, color: ink);
  TextStyle get inpBold => _f(17, 700, color: ink);

  // .av (css:101)
  TextStyle get av => _f(16, 800, color: Colors.white);
  TextStyle get avSm => _f(14, 800, color: Colors.white);
  TextStyle get avLg => _f(22, 800, color: Colors.white);

  // .tab (css:132)
  TextStyle get tab => _f(11.5, 700, color: const Color(0xFF3C4763));

  // .pbtn (css:49)
  TextStyle get pbtn => _f(16, 700, color: t.acc);

  // .link (css:82)
  TextStyle get link => _f(15, 700, color: t.acc);

  // .kv (css:157-158)
  TextStyle get kvK => _f(15, 400, color: ink3);
  TextStyle get kvV => _f(15, 700, color: ink);
  TextStyle get kvStrongK => _f(17, 800, color: ink);
  TextStyle get kvStrongV => _f(17, 800, color: ink);

  /// Tabular-nums variant for money - prototype sets `font-variant-numeric`.
  static const List<FontFeature> tabular = <FontFeature>[
    FontFeature.tabularFigures(),
  ];

  TextStyle get amtTab => amt.copyWith(fontFeatures: tabular);
  TextStyle get amtBigTab => amtBig.copyWith(fontFeatures: tabular);
}

/// Convenience: `TCTypography.of(context)`.
extension TCTypographyX on BuildContext {
  TCTypography get tct => TCTypography._(TCScope.of(this));
}
