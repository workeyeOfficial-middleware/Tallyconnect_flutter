// TallyConnect Liquid Glass - theme engine.
// Direct port of prototype/TallyConnect_App_Source.jsx lines 259-303:
// clampN, hsl2rgb, rgb2hex, hslx, hex2rgb, rgb2hsl, hsv2hex, hex2hsv,
// lumOf, contrastOf, readable, makeTheme, COMBOS, THEME_KEYS, okAccent.
import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'tc_colors.dart';

// ------------------------------------------------------------------ colour math

double clampN(num x, num a, num b) => math.max(a.toDouble(), math.min(b.toDouble(), x.toDouble()));

/// hsl2rgb (jsx:271). h in degrees, s/l in 0..100.
List<double> hsl2rgb(double h, double s, double l) {
  h = ((h % 360) + 360) % 360;
  s /= 100;
  l /= 100;
  final double c = (1 - (2 * l - 1).abs()) * s;
  final double x = c * (1 - ((h / 60) % 2 - 1).abs());
  final double m = l - c / 2;
  double r = 0;
  double g = 0;
  double b = 0;
  if (h < 60) {
    r = c;
    g = x;
  } else if (h < 120) {
    r = x;
    g = c;
  } else if (h < 180) {
    g = c;
    b = x;
  } else if (h < 240) {
    g = x;
    b = c;
  } else if (h < 300) {
    r = x;
    b = c;
  } else {
    r = c;
    b = x;
  }
  return <double>[(r + m) * 255, (g + m) * 255, (b + m) * 255];
}

/// rgb2hex (jsx:274) - uppercase, 2 digits per channel.
String rgb2hex(List<double> a) {
  final StringBuffer sb = StringBuffer('#');
  for (final double v in a) {
    sb.write((clampN(v, 0, 255).round()).toRadixString(16).padLeft(2, '0').toUpperCase());
  }
  return sb.toString();
}

/// hslx (jsx:275)
Color hslx(double h, double s, double l) {
  final List<double> rgb = hsl2rgb(h, s, l);
  return Color.fromARGB(
    255,
    clampN(rgb[0], 0, 255).round(),
    clampN(rgb[1], 0, 255).round(),
    clampN(rgb[2], 0, 255).round(),
  );
}

/// hex2rgb (jsx:276)
List<int> hex2rgb(String h) {
  String s = h.replaceAll('#', '');
  if (s.length == 3) s = s.split('').map((String c) => '$c$c').join();
  final int n = int.tryParse(s, radix: 16) ?? 0;
  return <int>[(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

/// hex2rgb as a Flutter Color (alpha forced opaque, matching the JS which
/// ignores any alpha channel).
Color hexColor(String h) {
  final List<int> v = hex2rgb(h);
  return Color.fromARGB(255, v[0], v[1], v[2]);
}

/// rgb2hsl (jsx:277) -> [h 0..360, s 0..100, l 0..100]
List<double> rgb2hsl(List<double> a) {
  final double r = a[0] / 255;
  final double g = a[1] / 255;
  final double b = a[2] / 255;
  final double mx = math.max(r, math.max(g, b));
  final double mn = math.min(r, math.min(g, b));
  final double l = (mx + mn) / 2;
  double h = 0;
  double s = 0;
  final double d = mx - mn;
  if (d != 0) {
    s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn);
    h = mx == r ? ((g - b) / d + (g < b ? 6 : 0)) : (mx == g ? (b - r) / d + 2 : (r - g) / d + 4);
    h *= 60;
  }
  return <double>[h, s * 100, l * 100];
}

/// hsv2hex (jsx:280)
String hsv2hex(num h, num s, num v) {
  final double sd = s / 100;
  final double vd = v / 100;
  double f(num n) {
    final double k = ((n + h / 60) % 6).toDouble();
    return vd - vd * sd * math.max(0.0, math.min(math.min(k, 4 - k), 1.0));
  }

  return rgb2hex(<double>[f(5) * 255, f(3) * 255, f(1) * 255]);
}

/// hex2hsv (jsx:281) -> [h, s, v] all rounded.
List<int> hex2hsv(String hx) {
  final List<int> a = hex2rgb(hx);
  final double r = a[0] / 255;
  final double g = a[1] / 255;
  final double b = a[2] / 255;
  final double mx = math.max(r, math.max(g, b));
  final double mn = math.min(r, math.min(g, b));
  final double d = mx - mn;
  double h = 0;
  if (d != 0) {
    h = mx == r ? ((g - b) / d) % 6 : (mx == g ? (b - r) / d + 2 : (r - g) / d + 4);
    h *= 60;
    if (h < 0) h += 360;
  }
  return <int>[h.round(), (mx != 0 ? d / mx * 100 : 0).round(), (mx * 100).round()];
}

/// lumOf (jsx:284) - WCAG relative luminance.
double lumOf(List<double> a) {
  final List<double> c = a.map((double v) {
    final double x = v / 255;
    return x <= .03928 ? x / 12.92 : math.pow((x + .055) / 1.055, 2.4).toDouble();
  }).toList();
  return .2126 * c[0] + .7152 * c[1] + .0722 * c[2];
}

/// contrastOf (jsx:285)
double contrastOf(String h1, String h2) {
  final double a = lumOf(hex2rgb(h1).map((int e) => e.toDouble()).toList());
  final double b = lumOf(hex2rgb(h2).map((int e) => e.toDouble()).toList());
  return (math.max(a, b) + .05) / (math.min(a, b) + .05);
}

/// readable (jsx:287) - darken lightness in steps of 2 until contrast passes.
class TCReadable {
  const TCReadable(this.c, this.l);
  final Color c;
  final double l;
}

TCReadable readable(double h, double s, double L, String bg, double min) {
  Color c = hslx(h, s, L);
  double l = L;
  while (contrastOf(rgb2hex(<double>[c.r * 255, c.g * 255, c.b * 255]), bg) < min && l > 6) {
    l -= 2;
    c = hslx(h, s, l);
  }
  return TCReadable(c, l);
}

// ---------------------------------------------------------------- combos

/// COMBOS (jsx:286)
class TCCombo {
  const TCCombo(this.t, this.s, this.sh, this.cap);
  final String t;
  final String s;
  final double sh;
  final double cap;
}

const List<TCCombo> tcCombos = <TCCombo>[
  TCCombo('Tonal', 'One calm colour family', 0, 42),
  TCCombo('Harmony', 'Neighbour shades', 32, 40),
  TCCombo('Contrast', 'Opposite colour accents', 180, 34),
  TCCombo('Balanced', 'Three-way colour mix', 120, 30),
  TCCombo('Business', 'Quiet neutral greys', 0, 8),
];

// ---------------------------------------------------------------- resolved theme

/// The 14 generated CSS custom properties (THEME_KEYS, jsx:301).
class TCGenerated {
  const TCGenerated({
    required this.acc,
    required this.acc2,
    required this.acc3,
    required this.navy,
    required this.navy2,
    required this.navy3,
    required this.ink,
    required this.ink2,
    required this.ink3,
    required this.gt,
    required this.wall,
    required this.o1,
    required this.o2,
    required this.o3,
  });

  final Color acc;
  final Color acc2;
  final Color acc3;
  final Color navy;
  final Color navy2;
  final Color navy3;
  final Color ink;
  final Color ink2;
  final Color ink3;
  final String gt;
  final TCWallSpec wall;
  final Color o1;
  final Color o2;
  final Color o3;
}

/// makeTheme (jsx:288-300)
TCGenerated makeTheme(String hex, int ci) {
  final List<double> hs = rgb2hsl(hex2rgb(hex).map((int e) => e.toDouble()).toList());
  final double h = hs[0];
  final bool grey = hs[1] < 10;
  final double sa = grey ? hs[1] : clampN(hs[1], 38, 82);
  final TCCombo cb = ci < tcCombos.length ? tcCombos[ci] : tcCombos.first;
  const String bgHex = '#F2F4FA';

  final TCReadable a = readable(h, sa, 46, bgHex, 4.8);
  final Color acc = a.c;
  final Color acc2 = hslx(h, sa, math.min(a.l + 11, 62));
  final Color acc3 = hslx(h, sa, math.max(a.l - 10, 8));

  final double h2 = h + cb.sh;
  final double ss = grey ? hs[1] : math.min(sa, cb.cap);

  final Color ink3 = readable(h2, math.min(ss, 18), 42, bgHex, 4.8).c;
  final String gtr = hsl2rgb(h, grey ? 0 : 55, 98.4).map((double e) => e.round().toString()).join(',');

  final double t2 = cb.sh == 0 ? h + 18 : h2;
  final double t3 = cb.sh == 0 ? h - 18 : (h + h2) / 2 + (cb.sh == 180 ? 90 : 0);

  final Color b1 = hslx(h, grey ? 6 : 66, 87);
  final Color b2 = hslx(t2, grey ? 6 : 56, 89);
  final Color b3 = hslx(t3, grey ? 4 : 46, 91);
  final Color top = hslx(h, grey ? 5 : 40, 96.6);
  final Color bot = hslx(h2, grey ? 5 : 30, 93.6);

  return TCGenerated(
    acc: acc,
    acc2: acc2,
    acc3: acc3,
    navy: hslx(h2, ss, 20),
    navy2: hslx(h2, ss, 32),
    navy3: hslx(h2, ss, 14),
    ink: hslx(h2, math.min(ss, 28), 12),
    ink2: hslx(h2, math.min(ss, 22), 30),
    ink3: ink3,
    gt: gtr,
    o1: hslx(h, grey ? 6 : 60, 82),
    o2: hslx(t2, grey ? 6 : 50, 85),
    o3: hslx(t3, grey ? 4 : 44, 87),
    wall: TCWallSpec(
      radials: <TCWallLayer>[
        TCWallLayer(color: b1, cx: .12, cy: .06, rx: .60, ry: .38, stops: const <double>[0, .70]),
        TCWallLayer(color: b2, cx: .95, cy: .24, rx: .55, ry: .34, stops: const <double>[0, .70]),
        TCWallLayer(color: b3, cx: .80, cy: .96, rx: .70, ry: .40, stops: const <double>[0, .70]),
      ],
      linear: TCWallLinear(color1: top, color2: bot),
    ),
  );
}

// ---------------------------------------------------------------- resolved app theme

/// How the accent palette is sourced (root class string, jsx:1142):
/// `ps-<preset>` always, plus `ac-<accent>` when accent != 'look'.
enum TCLookMode { look, custom }

/// A fully resolved theme: base look + optional accent override + optional
/// wallpaper override. This is the single source of truth every widget reads.
class TCTheme {
  TCTheme({
    required this.mode,
    required this.preset,
    required this.accent,
    required this.wallK,
    required this.glass,
    this.custom,
    this.combo = 0,
    this.iconMatch = true,
  });

  factory TCTheme.initial() => TCTheme(
    mode: TCLookMode.look,
    preset: 'aurora',
    accent: 'look',
    wallK: 'theme',
    glass: 60,
  );

  final TCLookMode mode;
  final String preset;

  /// 'look' or an accent key
  final String accent;

  /// 'theme' (match) or a wallpaper key
  final String wallK;

  /// --g as a percent, 0..100 (rounded to nearest 10 in the prototype)
  final int glass;

  /// base hex when [mode] == custom
  final String? custom;
  final int combo;

  /// prototype `iconMode`: true = all icons take --acc
  final bool iconMatch;

  /// True when an accent override is selected and valid for this look.
  bool get accentIsCustom => accent != 'look' && TCColors.okAccent(preset, accent);

  // ---- resolved palette ----------------------------------------------------

  TCLook get look => TCColors.look(preset);
  TCAccent? get accentDef => accent == 'look' ? null : TCColors.accentDef(accent);

  Color get acc =>
      mode == TCLookMode.custom ? TCGeneratedAccent(custom ?? '#8C1D3F', combo).acc : look.acc;
  Color get acc2 =>
      mode == TCLookMode.custom ? TCGeneratedAccent(custom ?? '#8C1D3F', combo).acc2 : look.acc2;
  Color get acc3 =>
      mode == TCLookMode.custom ? TCGeneratedAccent(custom ?? '#8C1D3F', combo).acc3 : look.acc3;
  Color get navy =>
      mode == TCLookMode.custom ? TCGeneratedAccent(custom ?? '#8C1D3F', combo).navy : look.navy;
  Color get navy2 =>
      mode == TCLookMode.custom ? TCGeneratedAccent(custom ?? '#8C1D3F', combo).navy2 : look.navy2;
  Color get navy3 =>
      mode == TCLookMode.custom ? TCGeneratedAccent(custom ?? '#8C1D3F', combo).navy3 : look.navy3;
  Color get ink =>
      mode == TCLookMode.custom ? TCGeneratedAccent(custom ?? '#8C1D3F', combo).ink : look.ink;
  Color get ink2 =>
      mode == TCLookMode.custom ? TCGeneratedAccent(custom ?? '#8C1D3F', combo).ink2 : look.ink2;
  Color get ink3 =>
      mode == TCLookMode.custom ? TCGeneratedAccent(custom ?? '#8C1D3F', combo).ink3 : look.ink3;
  Color get o1 =>
      mode == TCLookMode.custom ? TCGeneratedAccent(custom ?? '#8C1D3F', combo).o1 : look.o1;
  Color get o2 =>
      mode == TCLookMode.custom ? TCGeneratedAccent(custom ?? '#8C1D3F', combo).o2 : look.o2;
  Color get o3 =>
      mode == TCLookMode.custom ? TCGeneratedAccent(custom ?? '#8C1D3F', combo).o3 : look.o3;

  /// `--gt` glass tint as "r,g,b"
  String get gt =>
      mode == TCLookMode.custom ? TCGeneratedAccent(custom ?? '#8C1D3F', combo).gt : look.gt;

  /// resolved wallpaper spec
  TCWallSpec get wall {
    if (mode == TCLookMode.custom) return TCGeneratedAccent(custom ?? '#8C1D3F', combo).wall;
    if (wallK != 'theme') return TCColors.wallSpec(wallK);
    return look.wall;
  }

  // ---- semantics -----------------------------------------------------------

  Color get pos => look.pos ?? TCColors.basePos;
  Color get neg => look.neg ?? TCColors.baseNeg;
  Color get warn => look.warn ?? TCColors.baseWarn;

  /// `--c-*` semantic feature palette; receipt + the `acc` alias follow --acc.
  Color get cSales => iconMatch ? acc : TCColors.cSales;
  Color get cPurchase => iconMatch ? acc : TCColors.cPurchase;
  Color get cReceipt => acc;
  Color get cPayment => iconMatch ? acc : TCColors.cPayment;
  Color get cJournal => iconMatch ? acc : TCColors.cJournal;
  Color get cContra => iconMatch ? acc : TCColors.cContra;
  Color get cItems => iconMatch ? acc : TCColors.cItems;
  Color get cParty => iconMatch ? acc : TCColors.cParty;
  Color get cVouchers => iconMatch ? acc : TCColors.cVouchers;
  Color get cOutstanding => iconMatch ? acc : TCColors.cOutstanding;
  Color get cReports => iconMatch ? acc : TCColors.cReports;
  Color get cSettings => iconMatch ? acc : TCColors.cSettings;
  Color get cTeam => iconMatch ? acc : TCColors.cTeam;
  Color get cActivity => iconMatch ? acc : TCColors.cActivity;

  // ---- glass ---------------------------------------------------------------

  /// `.root{--g}` -> glass base alpha: `rgba(gt, g * .9 + .06)`
  double get glassAlpha => glass / 100 * .9 + .06;

  /// `.sheet` / `.drawer`: `rgba(gt, g * .45 + .5)`
  double get sheetAlpha => glass / 100 * .45 + .5;

  /// parse `gt` into a Color
  Color get gtColor {
    final List<String> p = gt.split(',');
    if (p.length < 3) return Colors.white;
    return Color.fromARGB(255, int.parse(p[0]), int.parse(p[1]), int.parse(p[2]));
  }

  TCTheme copyWith({
    TCLookMode? mode,
    String? preset,
    String? accent,
    String? wallK,
    int? glass,
    String? custom,
    int? combo,
    bool? iconMatch,
  }) {
    return TCTheme(
      mode: mode ?? this.mode,
      preset: preset ?? this.preset,
      accent: accent ?? this.accent,
      wallK: wallK ?? this.wallK,
      glass: glass ?? this.glass,
      custom: custom ?? this.custom,
      combo: combo ?? this.combo,
      iconMatch: iconMatch ?? this.iconMatch,
    );
  }

  @override
  bool operator ==(Object other) =>
      other is TCTheme &&
      other.mode == mode &&
      other.preset == preset &&
      other.accent == accent &&
      other.wallK == wallK &&
      other.glass == glass &&
      other.custom == custom &&
      other.combo == combo &&
      other.iconMatch == iconMatch;

  @override
  int get hashCode => Object.hash(mode, preset, accent, wallK, glass, custom, combo, iconMatch);
}

/// Lazy accessor so [TCTheme] getters don't rebuild the palette 8 times per
/// frame. Pure function of (hex, combo).
class TCGeneratedAccent {
  TCGeneratedAccent(this.hex, this.combo) : g = makeTheme(hex, combo);
  final String hex;
  final int combo;
  final TCGenerated g;
  Color get acc => g.acc;
  Color get acc2 => g.acc2;
  Color get acc3 => g.acc3;
  Color get navy => g.navy;
  Color get navy2 => g.navy2;
  Color get navy3 => g.navy3;
  Color get ink => g.ink;
  Color get ink2 => g.ink2;
  Color get ink3 => g.ink3;
  String get gt => g.gt;
  TCWallSpec get wall => g.wall;
  Color get o1 => g.o1;
  Color get o2 => g.o2;
  Color get o3 => g.o3;
}

/// Resolved theme for widgets - use [TCScope.of(context)].
class TCScope extends InheritedWidget {
  const TCScope({super.key, required this.theme, required super.child});

  final TCTheme theme;

  static TCTheme of(BuildContext context) {
    final TCScope? s = context.dependOnInheritedWidgetOfExactType<TCScope>();
    return s?.theme ?? TCTheme.initial();
  }

  @override
  bool updateShouldNotify(TCScope oldWidget) => oldWidget.theme != theme;
}